import { Router } from 'express';
// We'll import controllers and middlewares later

const router = Router();

// Placeholder route
router.get('/', (req, res) => {
    res.send('Course routes are working!');
});

export default router;