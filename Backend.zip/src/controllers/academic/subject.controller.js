// src/controllers/academic/subject.controller.js
import asyncHandler from '../../utils/asyncHandler.utils.js'; // Adjust path
import { ApiResponse, ApiError } from '../../utils/apiResponse.utils.js'; // Adjust path
import { subjectService } from '../../services/subject/subject.service.js'; // Adjust path
import {
    decryptAesKeyWithRsa,
    decryptPayloadWithAesGcm,
    encryptPayloadWithAesGcm // For encrypted responses
} from '../../utils/crypto.utils.js'; // Adjust path
import cryptoNode from 'crypto';

export const subjectController = {
    
    createSubject: asyncHandler(async (req, res) => {
        const { encryptedAesKeyB64, encryptedPayloadB64 } = req.body;

        if (!encryptedAesKeyB64 || !encryptedPayloadB64) {
            throw new ApiError(400, 'Encrypted AES key and payload are required for creating a subject.');
        }

        const aesKeyBuffer = decryptAesKeyWithRsa(encryptedAesKeyB64);
        const decryptedFrontendData = decryptPayloadWithAesGcm(encryptedPayloadB64, aesKeyBuffer);

        console.log('[SubjectController] Decrypted data from frontend:', JSON.stringify(decryptedFrontendData, null, 2));

        // Map frontend field names and include assignedCourseIds
        const subjectInputDataForService = {
            SubjectName: decryptedFrontendData.name,
            SubjectDescription: decryptedFrontendData.description,
            SubjectCredits: decryptedFrontendData.credits,
            SubjectLevel: decryptedFrontendData.level,
            SubjectType: decryptedFrontendData.type,
            assignedCourseIds: decryptedFrontendData.assignedCourseIds || [] // Pass this to the service
        };

        if (!subjectInputDataForService.SubjectName) {
            throw new ApiError(400, 'Decrypted payload for subject creation is missing required field: name (which maps to SubjectName).');
        }

        const adminUserId = req.user.id;
        const newSubject = await subjectService.createSubject(subjectInputDataForService, adminUserId);

        // The newSubject returned from the service will now have AssociatedCourses populated
        res.status(201).json(new ApiResponse(201, newSubject, 'Subject created successfully and associated with specified courses.'));
    }),


    getAllSubjects: asyncHandler(async (req, res) => {
        const subjects = await subjectService.getAllSubjects();
        console.log(subjects)
        if (!subjects || subjects.length === 0) {
            const emptyAesKey = cryptoNode.randomBytes(32);
            const encryptedEmpty = encryptPayloadWithAesGcm([], emptyAesKey);
            return res.status(200).json(new ApiResponse(200, {
                responseAesKeyB64: emptyAesKey.toString('base64'),
                encryptedData: encryptedEmpty
            }, 'No subjects found.'));
        }

        const responseAesKeyBuffer = cryptoNode.randomBytes(32);
        const encryptedSubjectsDataB64 = encryptPayloadWithAesGcm(subjects, responseAesKeyBuffer);

        const responsePayload = {
            responseAesKeyB64: responseAesKeyBuffer.toString('base64'),
            encryptedData: encryptedSubjectsDataB64
        };

        res.status(200).json(new ApiResponse(200, responsePayload, 'Subjects retrieved and encrypted.'));
    }),

    getSubjectById: asyncHandler(async (req, res) => {
        const { subjectId } = req.params;

        const subjectWithDetails = await subjectService.getSubjectByIdWithDetails(subjectId);
        // subjectWithDetails is ALREADY a plain JavaScript object here

        console.log("[SubjectController] Subject with details fetched for encryption:", JSON.stringify(subjectWithDetails, null, 2)); // For debugging

        // Encrypt the response
        const responseAesKeyBuffer = cryptoNode.randomBytes(32);
        // Pass subjectWithDetails directly as it's already a plain object
        const encryptedSubjectDataB64 = encryptPayloadWithAesGcm(subjectWithDetails, responseAesKeyBuffer); 

        const responsePayload = {
            responseAesKeyB64: responseAesKeyBuffer.toString('base64'),
            encryptedData: encryptedSubjectDataB64
        };

        res.status(200).json(new ApiResponse(200, responsePayload, 'Subject details retrieved successfully.'));
    }),

    updateSubject: asyncHandler(async (req, res) => {
        const { subjectId } = req.params;
        const { encryptedAesKeyB64, encryptedPayloadB64 } = req.body;

        if (!encryptedAesKeyB64 || !encryptedPayloadB64) {
            throw new ApiError(400, 'Encrypted AES key and payload are required for updating a subject.');
        }

        const aesKeyBuffer = decryptAesKeyWithRsa(encryptedAesKeyB64);
        const decryptedUpdateData = decryptPayloadWithAesGcm(encryptedPayloadB64, aesKeyBuffer);

        console.log('[SubjectController] Decrypted update data from frontend:', JSON.stringify(decryptedUpdateData, null, 2));

        // Map frontend field names if necessary
        const updateDataForService = {
            SubjectName: decryptedUpdateData.name,
            SubjectDescription: decryptedUpdateData.description,
            SubjectCredits: decryptedUpdateData.credits,
            SubjectLevel: decryptedUpdateData.level,
            SubjectType: decryptedUpdateData.type,
            is_active: decryptedUpdateData.is_active, // Ensure frontend can send this
            assignedCourseIds: decryptedUpdateData.assignedCourseIds // Expects array of course ID strings
            // Map other editable fields
        };

        // Remove undefined fields so they don't overwrite existing values with null if not provided
        Object.keys(updateDataForService).forEach(key => {
            if (updateDataForService[key] === undefined) {
                delete updateDataForService[key];
            }
        });
        // 'assignedCourseIds' should be an empty array if all associations are to be removed,
        // or not present in payload if associations are not to be changed.
        // The service logic handles `typeof assignedCourseIds !== 'undefined'`

        if (Object.keys(updateDataForService).length === 0) {
            throw new ApiError(400, "No update data provided.");
        }

        const adminUserId = req.user.id;
        const updatedSubject = await subjectService.updateSubject(subjectId, updateDataForService, adminUserId);

        // Response is typically the updated resource (plaintext for CUD operations is common)
        res.status(200).json(new ApiResponse(200, updatedSubject, 'Subject updated successfully.'));
    }),

    addModulesAndTopics: asyncHandler(async (req, res) => {
        const { subjectId } = req.params;
        const { encryptedAesKeyB64, encryptedPayloadB64 } = req.body;

        if (!subjectId) {
            throw new ApiError(400, 'Subject ID is required in the URL path.');
        }
        if (!encryptedAesKeyB64 || !encryptedPayloadB64) {
            throw new ApiError(400, 'Encrypted AES key and payload are required.');
        }

        const aesKeyBuffer = decryptAesKeyWithRsa(encryptedAesKeyB64);
        const decryptedModulesArrayFromFrontend = decryptPayloadWithAesGcm(encryptedPayloadB64, aesKeyBuffer);
        // decryptedModulesArrayFromFrontend is now expected to be an array like:
        // [ { moduleName, moduleDescription, initialTopics: [ { topicName } ] }, ... ]

        console.log('[SubjectController] addModulesAndTopics - Decrypted data (should be an array):', JSON.stringify(decryptedModulesArrayFromFrontend, null, 2));

        if (!Array.isArray(decryptedModulesArrayFromFrontend) || decryptedModulesArrayFromFrontend.length === 0) {
            throw new ApiError(400, 'Decrypted payload must be a non-empty array of modules.');
        }

        // Map the frontend field names to what the service expects for each module and its topics
        const modulesDataForService = decryptedModulesArrayFromFrontend.map(frontendModule => {
            if (!frontendModule.moduleName) { // Basic validation for each module
                throw new ApiError(400, 'Each module object must have a "moduleName".');
            }
            return {
                ModuleName: frontendModule.moduleName,
                ModuleDescription: frontendModule.moduleDescription,
                // ModuleCredits: frontendModule.moduleCredits, // Add if frontend sends these
                // sequence_order: frontendModule.sequenceOrder, // Add if frontend sends these
                // appliesToCourseIds is not directly part of the Module schema,
                // it might be used for other logic or logging if needed.

                // Map topics for this module
                topics: (frontendModule.initialTopics || []).map(frontendTopic => {
                    if (!frontendTopic.topicName) { // Basic validation for each topic
                        throw new ApiError(400, 'Each topic object must have a "topicName".');
                    }
                    return {
                        TopicName: frontendTopic.topicName,
                        // TopicContent: frontendTopic.topicContent, // Add if frontend sends
                        // TopicVideos: frontendTopic.topicVideos,   // Add if frontend sends
                        // sequence_order: frontendTopic.sequenceOrder, // Add if frontend sends
                    };
                })
            };
        });

        const adminUserId = req.user.id;
        const result = await subjectService.addModulesAndTopicsToSubject(
            subjectId,
            modulesDataForService, // Pass the mapped array of modules
            adminUserId
        );

        res.status(201).json(new ApiResponse(201, result, result.message));
    }),
    
};