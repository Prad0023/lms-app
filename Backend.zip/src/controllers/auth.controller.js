// src/controllers/auth.controller.js
import { authService } from '../services/auth.service.js';
import asyncHandler from '../utils/asyncHandler.utils.js';
import { ApiResponse } from '../utils/apiResponse.utils.js';
import {
    getServerRsaPublicKeyPem,
    decryptAesKeyWithRsa,
    decryptPayloadWithAesGcm
} from '../utils/crypto.utils.js';
import { ROLES } from '../services/seed.service.js';

export const authController = {


    getPublicKey: asyncHandler(async (req, res) => {
        const publicKeyPem = getServerRsaPublicKeyPem(); // Throws ApiError if not available
        res.status(200).json(new ApiResponse(200, { publicKey: publicKeyPem }));
    }),

    // registerFirstAdmin: asyncHandler(async (req, res) => {
    //     const { email, mobile_number, full_name, password } = req.body;
    //     const ipAddress = req.ip;
    //     const userAgent = req.headers['user-agent'];

    //     const result = await authService.registerFirstAdmin(
    //         { email, mobile_number, full_name, password },
    //         ipAddress,
    //         userAgent
    //     );
    //     res.status(201).json(new ApiResponse(201, result.user, result.message));
    // }),
    registerFirstAdmin: asyncHandler(async (req, res) => {
        // For this specific "first admin" scenario, we assume direct plaintext input.
        // If you wanted to encrypt this payload too, you'd follow the login pattern.
        const { email, mobile_number, full_name, password } = req.body;

        if (!email || !full_name || !password) {
            throw new ApiError(400, "Email, full name, and password are required for admin registration.");
        }

        const ipAddress = req.ip;
        const userAgent = req.headers['user-agent'];

        const result = await authService.registerFirstAdmin(
            { email, mobile_number, full_name, password },
            ipAddress,
            userAgent
        );
        res.status(201).json(new ApiResponse(201, result.user, result.message));
    }),

    login: asyncHandler(async (req, res) => {
        const { encryptedAesKeyB64, encryptedPayloadB64 } = req.body;

        if (!encryptedAesKeyB64 || !encryptedPayloadB64) {
            throw new ApiError(400, 'Encrypted AES key and payload are required.');
        }

        // 1. Decrypt the AES key (which was RSA encrypted)
        const aesKeyBuffer = decryptAesKeyWithRsa(encryptedAesKeyB64);

        // 2. Decrypt the actual payload using the AES key
        const decryptedCredentials = decryptPayloadWithAesGcm(encryptedPayloadB64, aesKeyBuffer); // Returns { email, password }

        if (!decryptedCredentials.email || !decryptedCredentials.password) {
            throw new ApiError(400, 'Decrypted payload must contain email and password.');
        }

        const ipAddress = req.ip;
        const userAgent = req.headers['user-agent'];

        // 3. Call the auth service with plaintext credentials
        const result = await authService.loginUser(
            { email: decryptedCredentials.email, password: decryptedCredentials.password },
            ipAddress,
            userAgent
        );

        // 4. Send JWT and user info in response
        res.status(200).json(new ApiResponse(200, {
            token: result.token,
            user: result.user, // User object without sensitive details
            expiresIn: result.expiresIn
        }, result.message));
    }),



    // login: asyncHandler(async (req, res) => {
    //     const { email, password } = req.body;
    //     const ipAddress = req.ip;
    //     const userAgent = req.headers['user-agent'];

    //     const result = await authService.loginUser({ email, password }, ipAddress, userAgent);

    //     // It's common to send the token in a cookie for web apps, or in the response body for APIs.
    //     // HttpOnly cookie is more secure against XSS.
    //     // For now, sending in response body.
    //     res.status(200).json(new ApiResponse(200, {
    //         token: result.token,
    //         user: result.user, // Contains user details without sensitive info
    //         expiresIn: result.expiresIn
    //     }, result.message));
    // }),

    // Add other auth-related controllers here (logout, refreshToken, etc.)
};