// src/utils/crypto.utils.js
import forge from 'node-forge';
import cryptoNode from 'crypto'; // Renamed to avoid conflict if 'crypto' is used as a var name
import fs from 'fs';
import config from '../config/env.config.js';
import { ApiError } from './apiResponse.utils.js';

const AES_ALGORITHM = 'aes-256-gcm';
const AES_KEY_BYTE_LENGTH = 32; // 256 bits
const IV_BYTE_LENGTH = 12;    // 96 bits for GCM
const AUTH_TAG_BYTE_LENGTH = 16; // 128 bits for GCM

let rsaPrivateKeyInstance;
let rsaPublicKeyPemContent;

try {
    if (config.rsaPrivateKeyPath) {
        const pem = fs.readFileSync(config.rsaPrivateKeyPath, 'utf8');
        rsaPrivateKeyInstance = forge.pki.privateKeyFromPem(pem);
    } else {
        console.error('FATAL: RSA_PRIVATE_KEY_PATH is not configured. Server cannot decrypt payloads.');
        // Consider process.exit(1) if this is absolutely critical for server operation
    }

    if (config.rsaPublicKeyPath) {
        rsaPublicKeyPemContent = fs.readFileSync(config.rsaPublicKeyPath, 'utf8');
    } else {
        console.warn('RSA_PUBLIC_KEY_PATH is not configured. Server cannot provide public key to clients.');
    }
} catch (error) {
    console.error('Error loading RSA keys:', error.message);
    rsaPrivateKeyInstance = null;
    rsaPublicKeyPemContent = null;
}

/**
 * Provides the server's public RSA key in PEM format.
 * @returns {string | null} PEM encoded public key or null if not available.
 */
export const getServerRsaPublicKeyPem = () => {
    if (!rsaPublicKeyPemContent) {
        throw new ApiError(503, 'Server encryption service (public key) is currently unavailable.');
    }
    return rsaPublicKeyPemContent;
};

/**
 * Decrypts an RSA-OAEP encrypted AES key.
 * The client is expected to Base64 encode the AES key, then RSA encrypt that Base64 string.
 * @param {string} rsaEncryptedBase64AesKeyB64 - Base64 encoded, RSA encrypted (Base64 representation of the AES key).
 * @returns {Buffer} The decrypted AES key as a Buffer.
 */
export const decryptAesKeyWithRsa = (rsaEncryptedBase64AesKeyB64) => {
    if (!rsaPrivateKeyInstance) {
        throw new ApiError(500, 'Server decryption (RSA private key) service not configured.');
    }
    try {
        const encryptedBytes = forge.util.decode64(rsaEncryptedBase64AesKeyB64);
        const decryptedAesKeyAsBase64Bytes = rsaPrivateKeyInstance.decrypt(encryptedBytes, 'RSA-OAEP', {
            md: forge.md.sha256.create(),
            mgf1: { md: forge.md.sha1.create() }
        });
        // The decrypted content is the Base64 string of the AES key
        const aesKeyBase64 = forge.util.decodeUtf8(decryptedAesKeyAsBase64Bytes);
        const aesKeyBuffer = Buffer.from(aesKeyBase64, 'base64');

        if (aesKeyBuffer.length !== AES_KEY_BYTE_LENGTH) {
            throw new Error(`Decrypted AES key has incorrect length: ${aesKeyBuffer.length}. Expected ${AES_KEY_BYTE_LENGTH}.`);
        }
        return aesKeyBuffer;
    } catch (error) {
        console.error('RSA Decryption of AES key failed:', error);
        throw new ApiError(400, 'Failed to decrypt AES key. Ensure it was correctly RSA encrypted.');
    }
};

/**
 * Decrypts a payload using AES-256-GCM.
 * Expects input as Base64 string: IV (12 bytes) + Ciphertext + AuthTag (16 bytes).
 * @param {string} aesEncryptedPayloadB64 - Base64 encoded (IV + Ciphertext + AuthTag).
 * @param {Buffer} aesKeyBuffer - The 32-byte AES key.
 * @returns {object} The decrypted JSON object.
 */
export const decryptPayloadWithAesGcm = (aesEncryptedPayloadB64, aesKeyBuffer) => {
    try {
        const combinedBuffer = Buffer.from(aesEncryptedPayloadB64, 'base64');

        const iv = combinedBuffer.subarray(0, IV_BYTE_LENGTH);
        const authTag = combinedBuffer.subarray(combinedBuffer.length - AUTH_TAG_BYTE_LENGTH);
        const ciphertext = combinedBuffer.subarray(IV_BYTE_LENGTH, combinedBuffer.length - AUTH_TAG_BYTE_LENGTH);

        if (iv.length !== IV_BYTE_LENGTH) throw new Error('Invalid IV length.');
        if (authTag.length !== AUTH_TAG_BYTE_LENGTH) throw new Error('Invalid AuthTag length.');

        const decipher = cryptoNode.createDecipheriv(AES_ALGORITHM, aesKeyBuffer, iv);
        decipher.setAuthTag(authTag);

        let decryptedJsonString = decipher.update(ciphertext, null, 'utf8');
        decryptedJsonString += decipher.final('utf8');

        return JSON.parse(decryptedJsonString);
    } catch (error) {
        console.error('AES Payload Decryption failed:', error);
        if (error.message.includes('Unsupported state') || error.message.includes('authentication tag')) {
             throw new ApiError(400, 'AES payload decryption failed: authentication failed (tampered or incorrect key/IV).');
        }
        throw new ApiError(400, 'Failed to decrypt or parse AES payload.');
    }
};