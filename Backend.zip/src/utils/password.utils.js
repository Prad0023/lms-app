import bcrypt from 'bcryptjs';
import crypto from 'crypto'; 

export const hashPassword = async (password) => {
    const salt = await bcrypt.genSalt(10);
    return await bcrypt.hash(password, salt);
};

export const comparePassword = async (enteredPassword, hashedPassword) => {
    return await bcrypt.compare(enteredPassword, hashedPassword);
};

export const generateTemporaryPassword = (length = 12) => {
    const plainPassword = crypto.randomBytes(Math.ceil(length / 2)).toString('hex').slice(0, length);
    // In a real scenario, you might want to ensure it meets complexity requirements
    // For this flow, the user will set their own password in the next step.
    // We are only storing the hash, the User model pre-save hook will hash this plainPassword.
    return {
        plain: plainPassword,
        // hash: await hashPassword(plainPassword) // No need to pre-hash if model hook does it
    };
};