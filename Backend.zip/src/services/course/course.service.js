// src/services/course/course.service.js
import Course from '../../models/course.model.js';
import Subject from '../../models/subject.model.js'; // For populating subject names
import { ApiError } from '../../utils/apiResponse.utils.js';
import { logAuditEvent } from '../common/audit.service.js'; // Assuming path

export const courseService = {
    createCourse: async (courseData, adminUserId) => {
        const {
            CourseName,
            CourseDescription,
            course_code, // optional, could be auto-generated
            Credits,
            CourseLevel,
            CourseType,
            subjectIds, // Expecting an array of Subject ObjectIds from admin
            // ... other fields from your extensive schema like CourseDuration, StartDate, etc.
        } = courseData;

        // Validate if subjectIds are valid ObjectIds and exist (optional stricter validation)
        if (subjectIds && subjectIds.length > 0) {
            const validSubjects = await Subject.find({ '_id': { $in: subjectIds } }).select('_id');
            if (validSubjects.length !== subjectIds.length) {
                throw new ApiError(400, 'One or more provided subject IDs are invalid or do not exist.');
            }
        }
        
        // Check if course with the same name or code already exists
        if (CourseName) {
            const existingCourseByName = await Course.findOne({ CourseName });
            if (existingCourseByName) {
                throw new ApiError(409, `Course with name '${CourseName}' already exists.`);
            }
        }
        if (course_code) {
            const existingCourseByCode = await Course.findOne({ course_code });
            if (existingCourseByCode) {
                throw new ApiError(409, `Course with code '${course_code}' already exists.`);
            }
        }


        const newCourse = new Course({
            CourseName,
            CourseDescription,
            course_code,
            Credits,
            CourseLevel,
            CourseType,
            CourseSubjects: subjectIds || [], // Store array of ObjectIds
            created_by: adminUserId,
            is_published: false, // Default
            // ... assign other fields from courseData
        });

        await newCourse.save();

        // Populate subject details for the response
        await newCourse.populate({
            path: 'CourseSubjects',
            select: 'SubjectName SubjectDescription' // Or just SubjectName for brevity
        });
        await newCourse.populate({ path: 'created_by', select: 'full_name email' });


        await logAuditEvent({
            userId: adminUserId,
            event_type: 'course_management',
            resource: 'courses',
            resource_id: newCourse._id,
            action: 'create',
            status: 'success',
            details: { course_name: newCourse.CourseName }
        });

        return newCourse;
    },

    getAllCourses: async () => {
        const courses = await Course.find({})
            .populate({
                path: 'CourseSubjects', // Populate actual subject documents
                select: 'SubjectName SubjectDescription _id' // Select specific fields from Subject
            })
            .populate({
                path: 'CourseInstructor', // Populate instructor details
                select: 'full_name email _id' // Select specific fields from User (Teacher)
            })
            .populate({
                path: 'created_by',
                select: 'full_name email _id'
            })
            .sort({ CreatedAt: -1 });
        return courses;
    },

    // getCourseById: async (courseId) => { ... }
    // updateCourse: async (courseId, updateData, adminUserId) => { ... }
    // deleteCourse: async (courseId, adminUserId) => { ... }
    // addSubjectToCourse: async (courseId, subjectId, adminUserId) => { ... }
    // removeSubjectFromCourse: async (courseId, subjectId, adminUserId) => { ... }
};