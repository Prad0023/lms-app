// src/services/auth.service.js
import bcrypt from 'bcryptjs';
import crypto from 'crypto'; // For hashing tokens if needed, or generating random strings
import User from '../models/user.model.js';
import Role from '../models/role.model.js';
import Session from '../models/session.model.js';
import { ApiError } from '../utils/apiResponse.utils.js';
import { generateToken } from '../utils/jwt.utils.js';
import { logAuditEvent } from './audit.service.js';
import { ROLES } from './seed.service.js'; // To get 'admin' role name
import config from '../config/env.config.js';
import mongoose from 'mongoose';


const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_TIME_MINUTES = 30;

export const authService = {
    /**
     * Registers the first administrator for the system.
     * This should ideally be a one-time setup.
     */
    registerFirstAdmin: async (userData, ipAddress, userAgent) => {
        const { email, mobile_number, full_name, password } = userData;

        const adminRole = await Role.findOne({ name: ROLES.ADMIN });
        if (!adminRole) {
            throw new ApiError(500, 'Admin role not configured. Please seed roles.');
        }

        // Check if an admin user already exists
        const existingAdmin = await User.findOne({ roles: { $elemMatch: { role_id: adminRole._id } } });
        if (existingAdmin) {
            throw new ApiError(409, 'An administrator account already exists. This action is for initial setup.');
        }

        // Validate password strength (basic example)
        if (!password || password.length < 8) {
            throw new ApiError(400, 'Password must be at least 8 characters long.');
        }

        const newUser = new User({
            email,
            mobile_number,
            full_name,
            email_verified: true, // As per story for first admin
            mobile_verified: true, // As per story for first admin
            is_active: true,
            credentials: { // Password will be hashed by pre-save hook
                password_hash: password,
            },
            roles: [{
                role_id: adminRole._id,
                granted_at: new Date(),
                granted_by: null, // First admin has no grantor
            }]
        });

        const savedUser = await newUser.save();

        // Log audit event for registration
        await logAuditEvent({
            userId: savedUser._id,
            event_type: 'registration',
            resource: 'users',
            action: 'create_first_admin',
            status: 'success',
            ip_address: ipAddress,
            user_agent: userAgent,
            details: { email: savedUser.email, role: ROLES.ADMIN }
        });

        // Exclude sensitive data from return
        const userToReturn = savedUser.toObject();
        delete userToReturn.credentials;
        delete userToReturn.roles; // Or transform roles to show names if needed

        return { user: userToReturn, message: "Admin registered successfully. Please log in." };
    },

    /**
     * Logs in a user.
     */
    loginUser: async (credentials, ipAddress, userAgent) => {
        const { email, password } = credentials;

        if (!email || !password) {
            throw new ApiError(400, 'Email and password are required.');
        }

        const user = await User.findOne({ email }).select('+credentials'); // Explicitly select credentials

        if (!user) {
            throw new ApiError(401, 'Invalid email or password.');
        }

        if (!user.is_active) {
            throw new ApiError(403, 'Account is inactive. Please contact support.');
        }
        
        if (user.credentials.lockout_until && user.credentials.lockout_until > new Date()) {
            await logAuditEvent({ // Log failed attempt due to lockout
                userId: user._id,
                event_type: 'login_attempt',
                resource: 'session',
                action: 'attempt',
                status: 'failure',
                ip_address: ipAddress,
                user_agent: userAgent,
                details: { email: user.email, reason: 'account_locked', lockout_until: user.credentials.lockout_until }
            });
            throw new ApiError(403, `Account locked due to too many failed login attempts. Try again after ${user.credentials.lockout_until.toLocaleTimeString()}.`);
        }
        
        const isMatch = await user.comparePassword(password);

        if (!isMatch) {
            user.credentials.failed_login_attempts = (user.credentials.failed_login_attempts || 0) + 1;
            if (user.credentials.failed_login_attempts >= MAX_LOGIN_ATTEMPTS) {
                user.credentials.lockout_until = new Date(Date.now() + LOCKOUT_TIME_MINUTES * 60 * 1000);
            }
            await user.save();

            await logAuditEvent({
                userId: user._id,
                event_type: 'login_attempt',
                resource: 'session',
                action: 'attempt',
                status: 'failure',
                ip_address: ipAddress,
                user_agent: userAgent,
                details: { email: user.email, reason: 'invalid_credentials', attempts: user.credentials.failed_login_attempts }
            });
            throw new ApiError(401, 'Invalid email or password.');
        }

        // Successful login: reset failed attempts and lockout
        user.credentials.failed_login_attempts = 0;
        user.credentials.lockout_until = null;
        await user.save();
        
        const userRoles = await Role.find({ _id: { $in: user.roles.map(r => r.role_id) } }).select('name');
        const roleNames = userRoles.map(r => r.name);

        const token = generateToken(user._id.toString(), roleNames);

        // Hash the token for storage in the session document as per the original document
        // Note: bcrypt is for passwords. For JWTs, a simple SHA256 might be more appropriate if just for tracking.
        // Or store a unique session ID (e.g., from JWT's jti claim if you add one)
        // For simplicity, let's hash the token with SHA256.
        const tokenHash = crypto.createHash('sha256').update(token).digest('hex');

        const sessionExpiresAt = new Date(Date.now() + ms(config.jwtExpiresIn)); // ms library can parse "4h"

        const newSession = await Session.create({
            user_id: user._id,
            token_hash: tokenHash, // Storing hash of JWT
            created_at: new Date(),
            expires_at: sessionExpiresAt,
            ip_address: ipAddress,
            user_agent: userAgent,
            is_active: true,
        });

        // Log audit event for successful login
        await logAuditEvent({
            userId: user._id,
            event_type: 'login',
            resource: 'session',
            action: 'create',
            status: 'success',
            ip_address: ipAddress,
            user_agent: userAgent,
            details: { session_id: newSession._id, user_agent: userAgent }
        });

        const userToReturn = user.toObject();
        delete userToReturn.credentials;
        // Populate role names for the response
        userToReturn.roles = roleNames;


        return {
            token,
            user: userToReturn,
            expiresIn: config.jwtExpiresIn, // e.g., "4h"
            message: 'Login successful.'
        };
    },
};

// Helper to convert time string like "4h" to milliseconds
// You might need to install the `ms` package: npm install ms
import ms from 'ms';