// src/middlewares/role.middleware.js
import { ApiError } from '../utils/apiResponse.utils.js'; // Ensure this path is correct

/**
 * Middleware to authorize based on roles.
 * @param {string[]} allowedRoles - Array of role names allowed to access the route.
 */
// NAMED EXPORT for authorize
export const authorize = (allowedRoles = []) => {
    return (req, res, next) => {
        if (!req.user || !req.user.roles || req.user.roles.length === 0) {
            return next(new ApiError(403, 'Forbidden: User has no assigned roles.'));
        }

        const userRoleObjects = req.user.roles; // This is already an array of role objects from 'protect' middleware
        // Example userRoleObjects if populated correctly: [{ role_id: { name: 'admin', ... } }, ...]
        
        const userRoleNames = userRoleObjects
            .map(userRole => userRole.role_id && userRole.role_id.name)
            .filter(name => name); // Filter out any undefined names if role_id wasn't populated

        const hasRequiredRole = allowedRoles.some(role => userRoleNames.includes(role));

        if (!hasRequiredRole) {
            return next(new ApiError(403, `Forbidden: Route requires one of these roles: ${allowedRoles.join(', ')}.`));
        }
        next();
    };
};

/**
 * Middleware to authorize based on specific permissions.
 * @param {string} resource - The resource being accessed (e.g., 'user', 'course').
 * @param {string} action - The action being performed (e.g., 'create', 'read_all').
 */
// NAMED EXPORT for authorizePermission
export const authorizePermission = (resource, action) => {
    return (req, res, next) => {
        if (!req.user || !req.user.roles || req.user.roles.length === 0) {
            return next(new ApiError(403, 'Forbidden: User has no assigned roles for permission check.'));
        }

        let hasPermission = false;
        // req.user.roles should be populated by 'protect' middleware like:
        // [{ role_id: { name: 'admin', permissions: [{ resource: 'user', action: 'create'}, ...] } }, ...]
        for (const userRole of req.user.roles) {
            // Ensure role_id and its permissions are populated and exist
            if (userRole.role_id && userRole.role_id.permissions) {
                const foundPermission = userRole.role_id.permissions.find(
                    p => p.resource === resource && p.action === action
                );
                if (foundPermission) {
                    hasPermission = true;
                    break; // Found permission, no need to check other roles
                }
            }
        }

        if (!hasPermission) {
            return next(new ApiError(403, `Forbidden: User does not have permission '${action}' on resource '${resource}'.`));
        }
        next();
    };
};