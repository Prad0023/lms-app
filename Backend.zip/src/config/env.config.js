import dotenv from 'dotenv';
dotenv.config(); // Load .env file

const config = {
    rsaPublicKeyPath: process.env.RSA_PUBLIC_KEY_PATH,
    rsaPrivateKeyPath: process.env.RSA_PRIVATE_KEY_PATH,
    nodeEnv: process.env.NODE_ENV || 'development',
    port: process.env.PORT || 5000,
    mongoURI: process.env.MONGO_URI,
    jwtSecret: process.env.JWT_SECRET,
    jwtExpiresIn: process.env.JWT_EXPIRES_IN,
    passwordResetTokenExpiresInMinutes: parseInt(process.env.PASSWORD_RESET_TOKEN_EXPIRES_IN_MINUTES, 10) || 60,
    // initialAdmin: { // Optional: for seeding
    //     email: process.env.INITIAL_ADMIN_EMAIL,
    //     password: process.env.INITIAL_ADMIN_PASSWORD,
    //     fullName: process.env.INITIAL_ADMIN_FULL_NAME,
    //     mobileNumber: process.env.INITIAL_ADMIN_MOBILE_NUMBER,
    // }
};

// Basic validation for critical env variables
if (!config.mongoURI) {
    console.error('FATAL ERROR: MONGO_URI is not defined.');
    process.exit(1);
}
if (!config.jwtSecret) {
    console.error('FATAL ERROR: JWT_SECRET is not defined.');
    process.exit(1);
}

if (!config.rsaPrivateKeyPath || !config.rsaPublicKeyPath) {
    console.warn('RSA_PRIVATE_KEY_PATH or RSA_PUBLIC_KEY_PATH not set. Payload encryption/decryption might fail.');
}
export default config;