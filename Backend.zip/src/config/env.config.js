import dotenv from 'dotenv';
dotenv.config(); // Load .env file

const config = {
    nodeEnv: process.env.NODE_ENV || 'development',
    port: process.env.PORT || 5000,
    mongoURI: process.env.MONGO_URI,
    jwtSecret: process.env.JWT_SECRET,
    jwtExpiresIn: process.env.JWT_EXPIRES_IN,

    rsaPublicKeyPath: process.env.RSA_PUBLIC_KEY_PATH,     // Will be undefined if .env not loaded
    rsaPrivateKeyPath: process.env.RSA_PRIVATE_KEY_PATH,   // Will be undefined if .env not loaded
};


if (!config.rsaPrivateKeyPath || !config.rsaPublicKeyPath) {
    // This log IS appearing, which confirms the variables are undefined here
    console.warn('FROM env.config.js: RSA_PRIVATE_KEY_PATH or RSA_PUBLIC_KEY_PATH not set in process.env. Check .env file and dotenv loading.');
}

// Basic validation for critical env variables
if (!config.mongoURI) {
    console.error('FATAL ERROR: MONGO_URI is not defined.');
    process.exit(1);
}
if (!config.jwtSecret) {
    console.error('FATAL ERROR: JWT_SECRET is not defined.');
    process.exit(1);
}

if (!config.rsaPrivateKeyPath || !config.rsaPublicKeyPath) {
    console.warn('RSA_PRIVATE_KEY_PATH or RSA_PUBLIC_KEY_PATH not set. Payload encryption/decryption might fail.');
}
export default config;