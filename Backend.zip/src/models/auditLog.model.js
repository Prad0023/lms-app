import mongoose from 'mongoose';

const auditLogSchema = new mongoose.Schema({
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', index: true }, // User performing action
    event_time: { type: Date, default: Date.now, index: true },
    event_type: { type: String, required: true, index: true }, // e.g., 'login', 'user_management', 'data_access'
    resource: { type: String, required: true }, // e.g., 'session', 'users', 'courses'
    resource_id: { type: mongoose.Schema.Types.ObjectId }, // ID of the affected resource, if any
    action: { type: String, required: true }, // e.g., 'create', 'read', 'update', 'delete', 'login', 'logout'
    status: { type: String, enum: ['success', 'failure', 'pending'], required: true },
    ip_address: { type: String },
    user_agent: { type: String }, // From request headers
    details: { type: mongoose.Schema.Types.Mixed }, // Any additional relevant info
});

const AuditLog = mongoose.model('AuditLog', auditLogSchema);
export default AuditLog;