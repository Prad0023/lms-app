import mongoose from 'mongoose';

const subjectSchema = new mongoose.Schema({
    SubjectName: { type: String, required: true, trim: true },
    SubjectDescription: { type: String, trim: true },
    SubjectCredits: { type: Number, default: 0 },
    // SubjectPrerequisites: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Subject' }], // Self-referencing
    SubjectLevel: { type: String, trim: true }, // e.g., Beginner, Intermediate, Advanced
    SubjectType: { type: String, trim: true }, // e.g., Core, Elective
    // SubjectModules: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Module' }], // We'll link Modules to Subjects
    SubjectInstructor: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }], // Teacher users
    // SubjectSchedule: [mongoose.Schema.Types.Mixed], // Or a more defined schema
    // SubjectMaterials: mongoose.Schema.Types.Mixed, // Or a more defined schema
    // SubjectStartDate: { type: Date },
    // SubjectEndDate: { type: Date },
    // SubjectDuration: { type: Number }, // in hours or days
    // SubjectResources: [mongoose.Schema.Types.Mixed],
    // SubjectAssignments: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Assignment' }],
    // SubjectExams: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Exam' }],
    // SubjectProjects: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Project' }],
    // SubjectGames: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Game' }],
    // SubjectQuizzes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Quiz' }],
    is_active: { type: Boolean, default: true },
    created_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
}, { timestamps: { createdAt: 'CreatedAt', updatedAt: 'UpdatedAt' } });

subjectSchema.index({ SubjectName: 1 });

const Subject = mongoose.model('Subject', subjectSchema);
export default Subject;