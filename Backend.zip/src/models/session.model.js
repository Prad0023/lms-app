import mongoose from 'mongoose';

const sessionSchema = new mongoose.Schema({
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    token_hash: { type: String, required: true, unique: true }, // Or store the JWT itself if it's opaque and short-lived
    ip_address: { type: String },
    user_agent: { type: String },
    is_active: { type: Boolean, default: true },
    expires_at: {
        type: Date,
        required: true,
        // TTL index: MongoDB will automatically delete documents after this time
        // index: { expires: '0s' } // Can also be set here
    },
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });

// TTL Index for automatic expiration of sessions
sessionSchema.index({ expires_at: 1 }, { expireAfterSeconds: 0 });
sessionSchema.index({ user_id: 1 });

const Session = mongoose.model('Session', sessionSchema);
export default Session;