import mongoose from 'mongoose';

const courseTeacherSchema = new mongoose.Schema({
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    assigned_at: { type: Date, default: Date.now },
    assigned_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
}, { _id: false });

const courseStudentSchema = new mongoose.Schema({
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    enrolled_at: { type: Date, default: Date.now },
    status: { type: String, enum: ['active', 'completed', 'dropped'], default: 'active' },
    // grade: String, // Optional
}, { _id: false });

const courseSchema = new mongoose.Schema({
    title: {
        type: String,
        required: [true, 'Course title is required.'],
        trim: true,
        unique: true, // Assuming course titles are unique
    },
    description: {
        type: String,
        trim: true,
    },
    course_code: { // e.g., 'MATH101'
        type: String,
        trim: true,
        unique: true,
        uppercase: true,
    },
    teachers: [courseTeacherSchema],
    students: [courseStudentSchema],
    created_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, // Admin who created course
    is_published: { type: Boolean, default: false },
    // category: String,
    // credits: Number,
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });

courseSchema.index({ title: 1 });
courseSchema.index({ course_code: 1 });
courseSchema.index({ "teachers.user_id": 1 });
courseSchema.index({ "students.user_id": 1 });

const Course = mongoose.model('Course', courseSchema);
export default Course;