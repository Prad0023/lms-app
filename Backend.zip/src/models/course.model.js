import mongoose from 'mongoose';

const courseTeacherSchema = new mongoose.Schema({
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    assigned_at: { type: Date, default: Date.now },
    assigned_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
}, { _id: false });

const courseStudentSchema = new mongoose.Schema({
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    enrolled_at: { type: Date, default: Date.now },
    status: { type: String, enum: ['active', 'completed', 'dropped'], default: 'active' },
}, { _id: false });

const courseSchema = new mongoose.Schema({
    CourseName: {
        type: String,
        required: [true, 'Course name is required.'],
        trim: true,
        unique: true, // Keep this for the unique index
    },
    CourseDescription: {
        type: String,
        trim: true,
    },
    course_code: {
        type: String,
        trim: true,
        unique: true, // Keep this for the unique index
                      // If course_code can be null/undefined for many courses, add sparse: true
                      // e.g., unique: true, sparse: true,
        uppercase: true,
    },
    Credits: { type: Number, default: 0 },
    CoursePrerequisites: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Course' }],
    CourseLevel: { type: String, trim: true },
    CourseType: { type: String, trim: true },
    CourseDuration: { type: Number },
    CourseStartDate: { type: Date },
    CourseEndDate: { type: Date },
    CourseInstructor: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    CourseSubjects: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Subject' }],
    teachers: [courseTeacherSchema],
    students: [courseStudentSchema],
    is_published: { type: Boolean, default: false },
    created_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
}, { timestamps: { createdAt: 'CreatedAt', updatedAt: 'UpdatedAt' } });

// Remove these duplicate index definitions as 'unique: true' above handles them
// courseSchema.index({ CourseName: 1 });
// courseSchema.index({ course_code: 1 });

// Keep other necessary indexes
courseSchema.index({ "teachers.user_id": 1 });
courseSchema.index({ "students.user_id": 1 });
courseSchema.index({ CourseSubjects: 1 }); // Index on the array of subject IDs

const Course = mongoose.model('Course', courseSchema);
export default Course;