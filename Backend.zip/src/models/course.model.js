import mongoose from 'mongoose';

const courseTeacherSchema = new mongoose.Schema({
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    assigned_at: { type: Date, default: Date.now },
    assigned_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
}, { _id: false });

const courseStudentSchema = new mongoose.Schema({
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    enrolled_at: { type: Date, default: Date.now },
    status: { type: String, enum: ['active', 'completed', 'dropped'], default: 'active' },
    // grade: String, // Optional
}, { _id: false });

const courseSchema = new mongoose.Schema({
    CourseName: { // Renaming 'title' to 'CourseName' to match your new schema
        type: String,
        required: [true, 'Course name is required.'],
        trim: true,
        unique: true,
    },
    CourseDescription: { // Renaming 'description' to 'CourseDescription'
        type: String,
        trim: true,
    },
    course_code: { // Keeping this as it's common
        type: String,
        trim: true,
        unique: true,
        uppercase: true,
    },
    Credits: { type: Number, default: 0 },
    CoursePrerequisites: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Course' }], // Self-referencing
    CourseLevel: { type: String, trim: true }, // e.g., 100, 200, Beginner
    CourseType: { type: String, trim: true }, // e.g., Core, Specialization
    CourseDuration: { type: Number }, // e.g., in weeks or hours
    CourseStartDate: { type: Date },
    CourseEndDate: { type: Date },
    CourseInstructor: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }], // Teachers assigned
    CourseSubjects: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Subject' }], // Array of Subject IDs
    // CourseMaterials: mongoose.Schema.Types.Mixed,
    // CourseSchedule: [mongoose.Schema.Types.Mixed],
    // CourseExams: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Exam' }],
    // ... (other fields like Projects, Games, Quizzes, Assignments, Resources)
    teachers: [{ // Kept from previous teacher assignment logic, maps to CourseInstructor
        user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
        assigned_at: { type: Date, default: Date.now },
        assigned_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        _id: false
    }],
    students: [{ // Kept from previous student enrollment logic
        user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
        enrolled_at: { type: Date, default: Date.now },
        status: { type: String, enum: ['active', 'completed', 'dropped'], default: 'active' },
        _id: false
    }],
    is_published: { type: Boolean, default: false },
    created_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
}, { timestamps: { createdAt: 'CreatedAt', updatedAt: 'UpdatedAt' } });

courseSchema.index({ CourseName: 1 });
courseSchema.index({ course_code: 1 });
courseSchema.index({ "teachers.user_id": 1 });
courseSchema.index({ "students.user_id": 1 });
courseSchema.index({ CourseSubjects: 1 });


const Course = mongoose.model('Course', courseSchema);
export default Course;