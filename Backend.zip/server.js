import app from './src/app.js';
import connectDB from './src/config/db.js';
import config from './src/config/env.config.js';
import { seedInitialData } from './src/services/seed.service.js'; // We will create this later

const startServer = async () => {
    try {
        await connectDB();
        await seedInitialData(); // Optional: Seed initial roles and admin if not present

        app.listen(config.port, () => {
            console.log(`Server running in ${config.nodeEnv} mode on port ${config.port}`);
        });
    } catch (error) {
        console.error('Failed to start server:', error);
        process.exit(1);
    }
};

startServer();