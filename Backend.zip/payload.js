import crypto from 'crypto';
import JSEncrypt from 'jsencrypt'; // JSEncrypt typically provides a default export
import fs from 'fs'; // For fallback if needed, though axios is preferred for fetching key
import axios from 'axios';

// CONFIGURATION
const SERVER_URL = 'http://localhost:5000'; // Your backend URL
const LOGIN_EMAIL = "testadmin@school.edu";
const LOGIN_PASSWORD = "SecurePassword123!";
// Fallback path if fetching public key via HTTP fails during script run
// const RSA_PUBLIC_KEY_PEM_PATH_FALLBACK = './secure/public.pem'; // Adjust path if you use this

async function generatePayload() {
    try {
        // 1. Fetch Server's RSA Public Key
        let rsaPublicKeyPem;
        try {
            console.log(`Fetching RSA public key from ${SERVER_URL}/api/v1/auth/public-key ...`);
            const response = await axios.get(`${SERVER_URL}/api/v1/auth/public-key`);
            if (response.data && response.data.success && response.data.data && response.data.data.publicKey) {
                rsaPublicKeyPem = response.data.data.publicKey;
                console.log("Successfully fetched RSA public key.");
            } else {
                throw new Error('Public key not found in server response or response format unexpected.');
            }
        } catch (e) {
            console.error(`Failed to fetch server's public RSA key: ${e.message}`);
            console.log("Ensure the backend server is running and the /api/v1/auth/public-key endpoint is accessible.");
            // Optional: Fallback to reading from a local file if HTTP fetch fails
            // console.log(`Attempting to read public key from fallback path: ${RSA_PUBLIC_KEY_PEM_PATH_FALLBACK}`);
            // try {
            //     rsaPublicKeyPem = fs.readFileSync(RSA_PUBLIC_KEY_PEM_PATH_FALLBACK, 'utf8');
            //     console.log("Successfully read public key from fallback file.");
            // } catch (fileError) {
            //     console.error(`Failed to read public key from fallback file: ${fileError.message}`);
            //     throw new Error("Could not obtain RSA public key from server or local fallback.");
            // }
            if (!rsaPublicKeyPem) throw e; // Re-throw if still no key
        }

        // 2. Generate AES Key
        const aesKeyBuffer = crypto.randomBytes(32); // 32 bytes for AES-256
        const aesKeyBase64 = aesKeyBuffer.toString('base64');
        console.log("Generated AES Key (Base64 - for debugging only):", aesKeyBase64);


        // 3. RSA Encrypt the Base64 encoded AES Key
        const rsaEncrypt = new JSEncrypt();
        rsaEncrypt.setKey(rsaPublicKeyPem); // setKey is often an alias for setPublicKey
        const encryptedAesKeyB64 = rsaEncrypt.encrypt(aesKeyBase64);
        if (!encryptedAesKeyB64) {
            // JSEncrypt returns false on failure
            throw new Error("RSA encryption of AES key failed. Check public key format or JSEncrypt usage. Is the key too long for RSA with the current key size and padding?");
        }
        console.log("RSA Encrypted AES Key (Base64):", encryptedAesKeyB64);


        // 4. AES-GCM Encrypt the Login Payload
        const iv = crypto.randomBytes(12); // 12 bytes for GCM IV
        const payloadJson = JSON.stringify({ email: LOGIN_EMAIL, password: LOGIN_PASSWORD });

        const cipher = crypto.createCipheriv('aes-256-gcm', aesKeyBuffer, iv);
        let encryptedPayloadPart = cipher.update(payloadJson, 'utf8', 'base64');
        encryptedPayloadPart += cipher.final('base64'); // This is Base64 of ciphertext
        const authTag = cipher.getAuthTag(); // This is a Buffer

        // Concatenate IV (raw) + Ciphertext (raw bytes from base64) + AuthTag (raw)
        // Then Base64 encode the whole thing
        const finalAesPayloadBuffer = Buffer.concat([
            iv,
            Buffer.from(encryptedPayloadPart, 'base64'),
            authTag
        ]);
        const encryptedPayloadB64 = finalAesPayloadBuffer.toString('base64');
        console.log("AES-GCM Encrypted Payload (Base64):", encryptedPayloadB64);

        console.log("\n--- Login Payload for Postman ---");
        console.log(JSON.stringify({
            encryptedAesKeyB64: encryptedAesKeyB64,
            encryptedPayloadB64: encryptedPayloadB64
        }, null, 2));
        console.log("--- End of Payload ---");

    } catch (error) {
        console.error("\nError generating payload:", error.message);
        if (error.stack) {
            console.error(error.stack);
        }
        if (error.isAxiosError && error.response) {
             console.error("Axios error details:", error.response.data);
        }
    }
}

generatePayload();