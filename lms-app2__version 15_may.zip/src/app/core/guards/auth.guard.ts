// src/app/core/guards/auth.guard.ts
import { inject } from '@angular/core';
import { CanActivateFn, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from '../services/auth.service'; // Path if guard is in core/guards and service in core/services

export const authGuard: CanActivateFn = (route: ActivatedRouteSnapshot, state: RouterStateSnapshot) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  if (authService.isLoggedIn()) {
    // Role-based access (if this guard is also meant for roles, or use a separate RoleGuard)
    const expectedRoles = route.data['expectedRoles'] as Array<string>; // Get expected roles from route data

    if (expectedRoles && expectedRoles.length > 0) {
      const user = authService.currentUserValue;
      if (user && user.roles && expectedRoles.some(role => user.roles.includes(role))) {
        return true; // User has at least one of the expected roles
      } else {
        console.warn('Access Denied - Insufficient Role');
        // Redirect to an unauthorized page or home
        router.navigate(['/']); // Or an '/unauthorized' page
        return false;
      }
    }
    return true; // Logged in, and no specific roles required by this route, or role check passed
  }

  // Not logged in
  console.warn('Access Denied - Not Logged In');
  router.navigate(['/auth/login'], { queryParams: { returnUrl: state.url } });
  return false;
};