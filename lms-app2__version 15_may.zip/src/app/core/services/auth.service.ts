import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environments'; // Adjust path
import { EncryptionService } from './encryption.service';
import { firstValueFrom } from 'rxjs'; // Adjust path

// --- Interfaces ---
export interface AdminRegistrationPayload {
  email: string;
  mobile_number: string;
  full_name: string;
  password?: string; // Optional during registration if backend handles differently
}

export interface LoginPayload {
  email: string;
  password?: string;
}

export interface EncryptedLoginRequest {
  encryptedAesKeyB64: string;
  encryptedPayloadB64: string;
  // ivB64?: string; // Only if server needs IV separately
}

export interface User {
  _id: string;
  email: string;
  full_name: string;
  roles: string[];
  // ... other fields
}

export interface AuthResponse {
  statusCode: number;
  data?: { // Make data optional for error responses
    token: string;
    user: User;
    expiresIn: string;
  };
  message: string;
  success: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = `${environment.apiUrl}/auth`;
  private currentUserSubject: BehaviorSubject<User | null>;
  public currentUser: Observable<User | null>;

  private readonly TOKEN_KEY = 'authToken';
  private readonly USER_KEY = 'currentUser';

  constructor(
    private http: HttpClient,
    private router: Router,
    private encryptionService: EncryptionService
  ) {
    const storedUser = localStorage.getItem(this.USER_KEY);
    this.currentUserSubject = new BehaviorSubject<User | null>(storedUser ? JSON.parse(storedUser) : null);
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue(): User | null {
    return this.currentUserSubject.value;
  }

  public get token(): string | null {
    return localStorage.getItem(this.TOKEN_KEY);
  }

  public isLoggedIn(): boolean {
    return !!this.token;
  }

  // --- Admin Registration ---
  registerFirstAdmin(payload: AdminRegistrationPayload): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiUrl}/register-first-admin`, payload).pipe(
      tap(response => {
        if (response.success) {
          // Optional: Log in the user directly or prompt to login
          console.log('Admin registration successful:', response.message);
        }
      }),
      catchError(this.handleError)
    );
  }

  // --- Login (with Encryption) ---
  async login(payload: LoginPayload): Promise<AuthResponse> { // async because of crypto
    try {
      const rsaPublicKey = await this.encryptionService.getRsaPublicKey();
      const aesKey = await this.encryptionService.generateAesKey();
      const aesKeyB64 = await this.encryptionService.exportAesKeyAsBase64(aesKey);

      const encryptedAesKeyB64 = await this.encryptionService.encryptAesKeyWithRsa(aesKeyB64, rsaPublicKey);
      const { encryptedPayloadB64 } = await this.encryptionService.encryptPayloadWithAes(payload, aesKey);

      const encryptedRequest: EncryptedLoginRequest = {
        encryptedAesKeyB64,
        encryptedPayloadB64,
      };

      const response = await firstValueFrom(
        this.http.post<AuthResponse>(`${this.apiUrl}/login`, encryptedRequest).pipe(
          tap(res => {
            if (res.success && res.data) {
              this.storeAuthData(res.data.token, res.data.user);
              this.navigateToDashboard(res.data.user.roles);
            }
          }),
          catchError(this.handleError) // This might not catch as expected with firstValueFrom, handle error from promise
        )
      );
      return response;
    } catch (error) {
      console.error('Login encryption or request failed:', error);
      // Ensure error is re-thrown or handled to be an AuthResponse like structure for consistency
      const httpError = error as HttpErrorResponse;
      return {
        statusCode: httpError?.status || 500,
        message: httpError?.error?.message || 'Login failed due to an unexpected error.',
        success: false,
      };
    }
  }

  private storeAuthData(token: string, user: User): void {
    localStorage.setItem(this.TOKEN_KEY, token);
    localStorage.setItem(this.USER_KEY, JSON.stringify(user));
    this.currentUserSubject.next(user);
  }

  navigateToDashboard(roles: string[]): void {
    // For now, just admin
    if (roles.includes('admin')) {
      this.router.navigate(['/admin/dashboard']); // Adjust admin dashboard route
    } else if (roles.includes('teacher')) {
      this.router.navigate(['/teacher/dashboard']);
    } else if (roles.includes('student')) {
      this.router.navigate(['/student/dashboard']);
    } else {
      this.router.navigate(['/']); // Fallback
    }
  }

  logout(): void {
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.USER_KEY);
    this.currentUserSubject.next(null);
    this.router.navigate(['/auth/login']);
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage = 'An unknown error occurred!';
    if (error.error instanceof ErrorEvent) {
      // Client-side errors
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side errors
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.error?.message || error.message}`;
    }
    console.error(error);
    return throwError(() => new Error(errorMessage)); // Return an observable error
  }
}