import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment'; // Adjust path

@Injectable({
  providedIn: 'root' // Or provide in a specific module if not used globally
})
export class EncryptionService {
  private rsaPublicKey: CryptoKey | null = null;

  constructor(private http: HttpClient) {}

  // --- Helper: String to ArrayBuffer and vice-versa ---
  private str2ab(str: string): ArrayBuffer {
    const buf = new ArrayBuffer(str.length);
    const bufView = new Uint8Array(buf);
    for (let i = 0, strLen = str.length; i < strLen; i++) {
      bufView[i] = str.charCodeAt(i);
    }
    return buf;
  }

  private ab2str(buf: ArrayBuffer): string {
    return String.fromCharCode.apply(null, Array.from(new Uint8Array(buf)));
  }

  private ab2b64(buf: ArrayBuffer): string {
    let binary = '';
    const bytes = new Uint8Array(buf);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }

  // --- RSA Public Key Handling ---
  private async importRsaPublicKey(pemKey: string): Promise<CryptoKey> {
    // Remove PEM header and footer
    const pemHeader = "-----BEGIN PUBLIC KEY-----";
    const pemFooter = "-----END PUBLIC KEY-----";
    const pemContents = pemKey.substring(pemHeader.length, pemKey.length - pemFooter.length -1).replace(/\s+/g, ''); // Remove newlines and spaces
    const binaryDer = this.str2ab(window.atob(pemContents));

    return window.crypto.subtle.importKey(
      "spki", // SubjectPublicKeyInfo format
      binaryDer,
      {
        name: "RSA-OAEP",
        hash: "SHA-256", // Match server's hash algorithm for OAEP
      },
      true, // whether the key is extractable (false for public key usually)
      ["encrypt"] // Permitted usages
    );
  }

  public async getRsaPublicKey(): Promise<CryptoKey> {
    if (this.rsaPublicKey) {
      return this.rsaPublicKey;
    }
    // Fetch the public key string from your API
    // Assumes API returns it in PEM format as a string in a 'publicKey' field
    const keyData = await firstValueFrom(this.http.get<{publicKey: string}>(`${environment.apiUrl}/auth/public-key`));
    this.rsaPublicKey = await this.importRsaPublicKey(keyData.publicKey);
    return this.rsaPublicKey;
  }

  // --- AES Key Generation ---
  public async generateAesKey(): Promise<CryptoKey> {
    return window.crypto.subtle.generateKey(
      {
        name: "AES-GCM",
        length: 256, // Key length in bits (32 bytes)
      },
      true, // Allow export
      ["encrypt", "decrypt"]
    );
  }

  public async exportAesKeyAsBase64(key: CryptoKey): Promise<string> {
    const rawKey = await window.crypto.subtle.exportKey("raw", key);
    return this.ab2b64(rawKey); // Server expects Base64 of the raw AES key string
  }


  // --- RSA Encryption (for AES key) ---
  public async encryptAesKeyWithRsa(aesKeyStringB64: string, rsaPublicKey: CryptoKey): Promise<string> {
    const dataBuffer = this.str2ab(aesKeyStringB64); // Encrypt the Base64 string of AES key
    const encryptedBuffer = await window.crypto.subtle.encrypt(
      {
        name: "RSA-OAEP",
      },
      rsaPublicKey,
      dataBuffer
    );
    return this.ab2b64(encryptedBuffer); // Return as Base64 string
  }

  // --- AES-GCM Encryption (for payload) ---
  public async encryptPayloadWithAes(
    payload: object, // The JSON payload
    aesKey: CryptoKey
  ): Promise<{ encryptedPayloadB64: string; ivB64: string }> { // Return IV separately or combined as per server
    const iv = window.crypto.getRandomValues(new Uint8Array(12)); // 12-byte IV for GCM
    const payloadString = JSON.stringify(payload);
    const payloadBuffer = this.str2ab(payloadString);

    const encryptedBuffer = await window.crypto.subtle.encrypt(
      {
        name: "AES-GCM",
        iv: iv,
        // tagLength: 128, // Default is 128, ensure it matches server
      },
      aesKey,
      payloadBuffer
    );

    // The server spec "IV + Ciphertext + AuthTag" base64 encoded implies combining them before b64
    // SubtleCrypto for AES-GCM returns ArrayBuffer containing (Ciphertext + AuthTag)
    // So we need to prepend the IV.
    const combined = new Uint8Array(iv.byteLength + encryptedBuffer.byteLength);
    combined.set(iv, 0);
    combined.set(new Uint8Array(encryptedBuffer), iv.byteLength);

    return {
        encryptedPayloadB64: this.ab2b64(combined.buffer),
        ivB64: this.ab2b64(iv.buffer) // Also send IV separately if needed by backend for parsing, though combined is more common
    };
  }
}