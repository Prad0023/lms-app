// src/app/components/landing/process-section/process-section.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ScrollAnimationDirective } from '../../../directives/scroll-animation.directive';
import { SafeHtmlPipe } from '../../../shared/pipes/safe-html.pipe'; // <--- IMPORT THE PIPE

interface ProcessStep {
  stepNumber: string;
  title: string;
  description: string;
  icon: string; // SVG
}

@Component({
  selector: 'app-process-section',
  standalone: true,
  imports: [
    CommonModule,
    ScrollAnimationDirective,
    SafeHtmlPipe // <--- ADD THE PIPE TO IMPORTS
  ],
  templateUrl: './process-section.component.html',
})
export class ProcessSectionComponent {
  steps: ProcessStep[] = [
    // ... your steps data
     {
      stepNumber: '01',
      title: 'Sign Up & Explore',
      description: 'Create your free account in minutes and browse our extensive catalog of courses and learning paths.',
      icon: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-8 h-8 text-indigo-500"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" /></svg>`
    },
    {
      stepNumber: '02',
      title: 'Learn & Practice',
      description: 'Engage with interactive content, participate in coding playgrounds, and complete hands-on exercises.',
      icon: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-8 h-8 text-indigo-500"><path stroke-linecap="round" stroke-linejoin="round" d="M17.25 6.75L22.5 12l-5.25 5.25m-10.5 0L1.5 12l5.25-5.25m7.5-3l-4.5 16.5" /></svg>`
    },
    // ... other steps
  ];
}