import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ScrollAnimationDirective } from '../../../directives/scroll-animation.directive';

interface Technology {
  name: string;
  logoUrl: string; // URL to the logo image or SVG path
}

@Component({
  selector: 'app-technologies-section',
  standalone: true,
  imports: [CommonModule, ScrollAnimationDirective],
  templateUrl: './technologies-section.component.html',
})
export class TechnologiesSectionComponent {
  technologies: Technology[] = [
    { name: 'Python', logoUrl: 'https://www.vectorlogo.zone/logos/python/python-icon.svg' },
    { name: 'JavaScript', logoUrl: 'https://www.vectorlogo.zone/logos/javascript/javascript-icon.svg' },
    { name: 'Java', logoUrl: 'https://www.vectorlogo.zone/logos/java/java-icon.svg' },
    { name: 'React', logoUrl: 'https://www.vectorlogo.zone/logos/reactjs/reactjs-icon.svg' },
    { name: 'Angular', logoUrl: 'https://www.vectorlogo.zone/logos/angular/angular-icon.svg' },
    { name: 'Node.js', logoUrl: 'https://www.vectorlogo.zone/logos/nodejs/nodejs-icon.svg' },
    { name: 'Docker', logoUrl: 'https://www.vectorlogo.zone/logos/docker/docker-icon.svg' },
    { name: 'SQL', logoUrl: 'https://www.svgrepo.com/show/303229/sql-database-sql-azure-file-markup-language.svg' }, // Placeholder generic SQL icon
  ];
}