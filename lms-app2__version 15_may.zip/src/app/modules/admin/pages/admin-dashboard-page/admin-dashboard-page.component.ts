import { Component } from '@angular/core';
import { AuthService } from '../../../../core/services/auth.service'; // <--- Adjust path
import { CommonModule } from '@angular/common'; // For async pipe or *ngIf

@Component({
  selector: 'app-admin-dashboard-page',
  standalone: true,
  imports: [CommonModule], // Add CommonModule
  templateUrl: './admin-dashboard-page.component.html',
  // styleUrls: ['./admin-dashboard-page.component.scss']
})
export class AdminDashboardPageComponent {
  // Inject AuthService to use it in the template directly (public)
  // or create a getter for currentUserValue
  constructor(public authService: AuthService) {}
}