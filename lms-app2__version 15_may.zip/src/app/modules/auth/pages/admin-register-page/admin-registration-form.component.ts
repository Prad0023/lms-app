import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService, AdminRegistrationPayload } from '../../../../services/auth.service'; // Adjust path

@Component({
  selector: 'app-admin-registration-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './admin-registration-form.component.html',
})
export class AdminRegistrationFormComponent {
  registerForm: FormGroup;
  isLoading = false;
  errorMessage: string | null = null;
  successMessage: string | null = null;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.registerForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      mobile_number: ['', [Validators.required, Validators.pattern(/^\+[1-9]\d{1,14}$/)]], // E.164 format
      full_name: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(8)]], // Add more complex regex if needed
    });
  }

  onSubmit(): void {
    if (this.registerForm.invalid) {
      this.markAllAsTouched();
      return;
    }

    this.isLoading = true;
    this.errorMessage = null;
    this.successMessage = null;
    const payload: AdminRegistrationPayload = this.registerForm.value;

    this.authService.registerFirstAdmin(payload).subscribe({
      next: (response) => {
        this.isLoading = false;
        if (response.success) {
          this.successMessage = response.message + " Please login.";
          this.registerForm.reset();
          // Optionally redirect after a delay or let user click a login link
          setTimeout(() => this.router.navigate(['/auth/login']), 2000);
        } else {
          this.errorMessage = response.message;
        }
      },
      error: (err) => {
        this.isLoading = false;
        this.errorMessage = err.message || 'An unexpected error occurred during registration.';
        console.error(err);
      }
    });
  }

  private markAllAsTouched(): void {
    Object.values(this.registerForm.controls).forEach(control => {
      control.markAsTouched();
    });
  }
}