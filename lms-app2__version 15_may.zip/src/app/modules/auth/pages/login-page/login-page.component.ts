import { Component } from '@angular/core';
import { LoginFormComponent } from '../../components/login-form/login-form.component'; // Adjust path

@Component({
  selector: 'app-login-page',
  standalone: true,
  imports: [LoginFormComponent],
  template: `
    <div class="min-h-screen flex items-center justify-center bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
      <div class="max-w-md w-full space-y-8">
        <div>
          <img class="mx-auto h-12 w-auto" src="https://tailwindui.com/img/logos/workflow-mark-indigo-600.svg" alt="Workflow">
          <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">
            Sign in to your account
          </h2>
        </div>
        <app-login-form></app-login-form>
         <p class="mt-2 text-center text-sm text-gray-600">
          First time Admin?
          <a routerLink="/auth/register-admin" class="font-medium text-indigo-600 hover:text-indigo-500">
            Register here
          </a>
        </p>
      </div>
    </div>
  `
})
export class LoginPageComponent {}