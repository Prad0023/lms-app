import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { AuthService, LoginPayload } from '../../../../services/auth.service'; // Adjust path

@Component({
  selector: 'app-login-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './login-form.component.html',
})
export class LoginFormComponent {
  loginForm: FormGroup;
  isLoading = false;
  errorMessage: string | null = null;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router // Used by AuthService for redirection
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
    });
  }

  async onSubmit(): Promise<void> { // Mark as async
    if (this.loginForm.invalid) {
      this.markAllAsTouched();
      return;
    }

    this.isLoading = true;
    this.errorMessage = null;
    const payload: LoginPayload = this.loginForm.value;

    try {
      const response = await this.authService.login(payload); // Call the async login
      this.isLoading = false;
      if (!response.success) {
        this.errorMessage = response.message;
      }
      // Successful login and redirection is handled by AuthService
    } catch (err: any) {
      this.isLoading = false;
      this.errorMessage = err.message || 'An unexpected error occurred during login.';
      console.error(err);
    }
  }

  private markAllAsTouched(): void {
    Object.values(this.loginForm.controls).forEach(control => {
      control.markAsTouched();
    });
  }
}