// src/app/components/landing/page-footer/page-footer.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router'; // Ensure this is imported

@Component({
  selector: 'app-page-footer',
  standalone: true,
  imports: [CommonModule, RouterLink], // RouterLink IS needed here if template uses it
  templateUrl: './page-footer.component.html',
})
export class PageFooterComponent {
  currentYear = new Date().getFullYear();
  contactEmail = 'info@abhyasify.com';
}