import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';

import { TeacherHireModalComponent } from '../../components/teacher-hire-modal/teacher-hire-modal.component';
import { AdminTeacherService } from '../../services/admin-teacher.service';
// Import all necessary interfaces from the model file
import { TeacherDetailsFE, TeacherBasicInfo, TeacherDetailsBackend } from '../../models/teacher.model';

@Component({
  selector: 'app-teacher-management-page',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    TeacherHireModalComponent
  ],
  templateUrl: './teacher-management-page.component.html',
})
export class TeacherManagementPageComponent implements OnInit {
  isHireModalOpen = false;
  teachers: TeacherDetailsFE[] = []; // <<<< Typed with the Frontend-specific interface
  isLoadingTeachers = false;
  errorMessage: string | null = null;

  filterForm: FormGroup;
  teacherStatusOptions = [
    { value: '', label: 'All Statuses' },
    { value: 'pending_onboarding', label: 'Pending Onboarding' },
    { value: 'pending_verification', label: 'Pending Verification' },
    { value: 'hired', label: 'Hired' },
    { value: 'marked_for_review', label: 'Marked for Review' },
    { value: 'left', label: 'Left' },
    { value: 'unknown', label: 'Unknown Status'} // For default
  ];

  constructor(
    private router: Router,
    private adminTeacherService: AdminTeacherService,
    private fb: FormBuilder
  ) {
    this.filterForm = this.fb.group({
      searchTerm: [''],
      status: [''] // This will filter based on the backend's raw status string
    });
  }

  ngOnInit(): void {
    this.loadTeachers();
    this.filterForm.valueChanges.subscribe(() => {
        this.loadTeachers();
    });
  }

  async loadTeachers(): Promise<void> {
    this.isLoadingTeachers = true;
    this.errorMessage = null;
    try {
      const filters = this.filterForm.value;
      // adminTeacherService.getTeachers returns TeacherDetailsBackend[]
      const teachersFromBackend: TeacherDetailsBackend[] = await this.adminTeacherService.getTeachers(filters);

      // Transform backend data to the frontend model (TeacherDetailsFE)
      this.teachers = teachersFromBackend.map(backendTeacher => {
        // This object being created MUST match the TeacherDetailsFE interface
        const feTeacher: TeacherDetailsFE = {
          _id: backendTeacher._id,
          fullName: backendTeacher.full_name, // Map snake_case to camelCase
          email: backendTeacher.email,
          mobile: backendTeacher.mobile_number || 'N/A', // Map and provide default
          designation: backendTeacher.designation || 'N/A', // Provide default
          // Safely cast backend status to the stricter frontend status type, with a default
          status: (backendTeacher.status as TeacherDetailsFE['status']) || 'unknown',
          isActive: backendTeacher.is_active,
          onboardingLinkSentAt: backendTeacher.onboardingLinkSentAt ? new Date(backendTeacher.onboardingLinkSentAt) : undefined,
          profileCompletedAt: backendTeacher.profileCompletedAt ? new Date(backendTeacher.profileCompletedAt) : undefined,
          hiredAt: backendTeacher.hiredAt ? new Date(backendTeacher.hiredAt) : undefined,
          leftAt: backendTeacher.leftAt ? new Date(backendTeacher.leftAt) : undefined,
        };
        return feTeacher;
      });

      console.log("TeacherManagementPageComponent: MAPPED teachers for template:", JSON.stringify(this.teachers, null, 2));
    } catch (error: any) {
      this.errorMessage = error.message || 'Failed to load teachers.';
      console.error("Error in loadTeachers:", error);
    } finally {
      this.isLoadingTeachers = false;
    }
  }

  openHireTeacherModal(): void {
    this.isHireModalOpen = true;
  }

  closeHireTeacherModal(): void {
    this.isHireModalOpen = false;
  }

  async handleTeacherHired(teacherData: TeacherBasicInfo): Promise<void> {
    console.log('Admin initiated hiring for (from modal):', teacherData);
    this.isHireModalOpen = false;
    this.router.navigate(['/admin/teachers/mail-preview'], { state: { teacherData: teacherData } });
  }

  // getStatusClass and formatStatus now operate on TeacherDetailsFE['status']
  getStatusClass(status: TeacherDetailsFE['status'] | undefined): string {
    if (!status) { return 'bg-gray-100 text-gray-800'; } // Should not happen if default 'unknown' is set
    switch (status) {
      case 'hired': return 'bg-green-100 text-green-800';
      case 'pending_onboarding': return 'bg-yellow-100 text-yellow-800';
      case 'pending_verification': return 'bg-blue-100 text-blue-800';
      case 'marked_for_review': return 'bg-purple-100 text-purple-800';
      case 'left': return 'bg-red-100 text-red-800';
      case 'unknown': return 'bg-gray-300 text-gray-700';
      default: // Handles any other string status that might come
        const lowerStatus = status.toLowerCase();
        if (lowerStatus.includes('pending')) return 'bg-yellow-100 text-yellow-800';
        return 'bg-gray-100 text-gray-800';
    }
  }

  formatStatus(status: TeacherDetailsFE['status'] | undefined): string {
    if (!status || status === 'unknown') { return 'N/A'; }
    // Check if it's one of our defined literal types first for direct formatting
    const knownStatuses = ['pending_onboarding', 'pending_verification', 'hired', 'marked_for_review', 'left'];
    if (knownStatuses.includes(status)) {
        return status.split('_').map((word: string) => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
    }
    // If it's a string but not a known underscore type, just capitalize it
    return status.charAt(0).toUpperCase() + status.slice(1);
  }

  viewTeacherDetails(teacherId: string): void {
    console.log('View details for teacher:', teacherId);
    // this.router.navigate(['/admin/teachers', teacherId, 'view']); // Example
  }

  editTeacher(teacherId: string): void {
    console.log('Edit teacher:', teacherId);
    // this.router.navigate(['/admin/teachers', teacherId, 'edit']); // Example
  }
}