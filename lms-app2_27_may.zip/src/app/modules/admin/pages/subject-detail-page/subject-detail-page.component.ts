import { Component, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
// Removed switchMap, tap, map for simplicity in initial load, but keep for reference if more complex observable chains are needed
import { Observable, of, forkJoin, from } from 'rxjs';

import { AdminSubjectService } from '../../services/admin-subject.service';
import { SubjectDetailsBackend, SubjectDetailViewFE, ModuleListItemFE, TopicListItemFE, ModuleBasicInfo } from '../../models/subject.model'; // Ensure TopicListItemFE is imported
import { MinimalCourseInfo } from '../../models/course.model';
import { SubjectModuleAddComponent } from '../../components/subject-module-add-modal/subject-module-add-modal.component';

@Component({
  selector: 'app-subject-detail-page',
  standalone: true,
  imports: [CommonModule, RouterModule, DatePipe, SubjectModuleAddComponent],
  templateUrl: './subject-detail-page.component.html',
})
export class SubjectDetailPageComponent implements OnInit {
  subjectId: string | null = null;
  subjectViewData: SubjectDetailViewFE | null = null;
  isLoading = true;
  isProcessingModuleAdd = false; 
  errorMessage: string | null = null;
  isAddModuleModalOpen = false;
  allAvailableCourses: MinimalCourseInfo[] = []; // For "Add Module" modal

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private adminSubjectService: AdminSubjectService
  ) {}

  ngOnInit(): void {
    // Using subscribe directly to paramMap for simplicity here
    this.route.paramMap.subscribe(params => {
      this.subjectId = params.get('id');
      if (this.subjectId) {
        this.loadSubjectDetailsAndModules();
        this.loadAllCoursesForModal(); // For the "Add Module" modal context
      } else {
        this.errorMessage = "Subject ID not found in route.";
        this.isLoading = false;
      }
    });
  }

  async loadAllCoursesForModal(): Promise<void> {
      try {
          this.allAvailableCourses = await this.adminSubjectService.getCoursesForSelection();
      } catch (e) { console.error("Failed to load all courses for modal", e); }
  }

  async loadSubjectDetailsAndModules(): Promise<void> {
    if (!this.subjectId) return;
    this.isLoading = true;
    this.errorMessage = null;
    try {
      const [subjectDetailsBackend, modulesList] = await Promise.all([
        this.adminSubjectService.getSubjectDetailsForView(this.subjectId),
        this.adminSubjectService.getModulesForSubject(this.subjectId)
      ]);

      if (subjectDetailsBackend) {
        // Ensure allAvailableCourses is loaded before trying to map AssociatedCourses if they are IDs
        if (this.allAvailableCourses.length === 0 && subjectDetailsBackend.AssociatedCourses?.some(c => typeof c === 'string')) {
            await this.loadAllCoursesForModal(); // Load them if not already loaded
        }

        let associatedCourseObjects: MinimalCourseInfo[] = [];
        if (subjectDetailsBackend.AssociatedCourses && subjectDetailsBackend.AssociatedCourses.length > 0) {
          if (typeof subjectDetailsBackend.AssociatedCourses[0] === 'string') {
            associatedCourseObjects = (subjectDetailsBackend.AssociatedCourses as string[]).map(id => {
              const course = this.allAvailableCourses.find(c => c._id === id);
              return course ? course : { _id: id, name: `Course ID: ${id}` };
            }).filter(course => course !== null) as MinimalCourseInfo[];
          } else {
            associatedCourseObjects = subjectDetailsBackend.AssociatedCourses as MinimalCourseInfo[];
          }
        }

        this.subjectViewData = {
          _id: subjectDetailsBackend._id,
          name: subjectDetailsBackend.SubjectName,
          description: subjectDetailsBackend.SubjectDescription || 'N/A',
          credits: subjectDetailsBackend.SubjectCredits,
          subjectLevel: subjectDetailsBackend.SubjectLevel,
          subjectType: subjectDetailsBackend.SubjectType,
          createdAt: new Date(subjectDetailsBackend.created_at),
          associatedCourses: associatedCourseObjects,
          // Ensure modules are initialized with UI properties
          modules: modulesList?.map(mod => ({ ...mod, isTopicsVisible: false, topics: [], isLoadingTopics: false })) || [],
        };
      } else {
        this.errorMessage = `Subject with ID ${this.subjectId} not found.`;
      }
    } catch (error: any) {
      this.errorMessage = error.message || "Failed to load subject data.";
    } finally {
      this.isLoading = false;
    }
  }

  async toggleTopics(module: ModuleListItemFE): Promise<void> {
    if (!this.subjectViewData) return;

    const targetModule = this.subjectViewData.modules.find(m => m._id === module._id);
    if (!targetModule) return;

    targetModule.isTopicsVisible = !targetModule.isTopicsVisible;

    // If opening and topics haven't been loaded yet (and there are topics to load)
    if (targetModule.isTopicsVisible && (!targetModule.topics || targetModule.topics.length === 0) && targetModule.topicCount > 0) {
      targetModule.isLoadingTopics = true;
      try {
        const topics = await this.adminSubjectService.getTopicsForModule(targetModule._id);
        targetModule.topics = topics;
      } catch (error) {
        console.error(`Failed to load topics for module ${targetModule.moduleName}:`, error);
        targetModule.topics = []; // Set to empty on error to stop retrying
        // Optionally display an error message next to the module
      } finally {
        targetModule.isLoadingTopics = false;
      }
    }
  }

  openAddModuleModal(): void { /* ... as before ... */
    if (!this.subjectViewData) return;
    this.isAddModuleModalOpen = true;
  }
  closeAddModuleModal(): void { /* ... as before ... */
    this.isAddModuleModalOpen = false;
  }



  async handleModuleAdded(moduleDataOrArray: ModuleBasicInfo | ModuleBasicInfo[]): Promise<void> {
    if (!this.subjectId) {
      console.error("Subject ID is missing, cannot add module.");
      alert("Error: Subject context is lost. Please refresh.");
      return;
    }

    console.log("SubjectDetailPage: Received module data from modal:", moduleDataOrArray);
    this.isProcessingModuleAdd = true; // Now this is valid
    this.closeAddModuleModal();

    try {
      let overallSuccess = true;
      let messages: string[] = [];

      if (Array.isArray(moduleDataOrArray)) {
        // ... (logic for array of modules) ...
        console.log(`SubjectDetailPage: Attempting to add ${moduleDataOrArray.length} modules from JSON.`);
        if (moduleDataOrArray.length === 0) {
          alert("No valid modules found in the uploaded file to add.");
          // No 'return' here because finally still needs to run
          overallSuccess = false; // Indicate nothing was processed
        } else {
            for (const moduleData of moduleDataOrArray) {
              try {
                const response = await this.adminSubjectService.addModuleToSubject(this.subjectId, moduleData);
                if (response.success) {
                  messages.push(response.message || `Module "${moduleData.moduleName}" added successfully.`);
                } else {
                  overallSuccess = false;
                  messages.push(`Failed to add module "${moduleData.moduleName}": ${response.message || 'Unknown server error.'}`);
                  // break; // Optional: stop on first error
                }
              } catch (loopError: any) {
                overallSuccess = false;
                messages.push(`Error processing module "${moduleData.moduleName}": ${loopError.message || 'Network or client error.'}`);
                // break; // Optional: stop on first error
              }
            }
        }
        if (messages.length > 0) { // Show messages only if something was processed or attempted
            if (overallSuccess && moduleDataOrArray.length > 0) {
                alert("Modules from JSON processed successfully!\n" + messages.join("\n"));
            } else if (moduleDataOrArray.length > 0) { // Only if array was not empty to start with
                alert("Some modules from JSON could not be processed or file was empty:\n" + messages.join("\n"));
            }
        }


      } else {
        // Handle single module from manual form
        const response = await this.adminSubjectService.addModuleToSubject(this.subjectId, moduleDataOrArray);
        if (response.success) {
            alert(response.message || "Module added successfully!");
        } else {
            alert("Failed to add module: " + (response.message || 'Unknown server error'));
            overallSuccess = false;
        }
      }

      // Refresh only if some operation was successful or at least attempted without breaking
      if (overallSuccess || (Array.isArray(moduleDataOrArray) && moduleDataOrArray.length > 0) || !Array.isArray(moduleDataOrArray) ) {
        this.loadSubjectDetailsAndModules();
      }

    } catch(error: any) {
        alert("An unexpected error occurred while adding module(s): " + (error.message || "Please try again."));
    } finally {
        this.isProcessingModuleAdd = false; // Valid use
    }
  }



  editSubject(): void { /* ... as before ... */
     if(this.subjectId) this.router.navigate(['/admin/subjects', this.subjectId, 'edit']);
  }
  goBack(): void { /* ... as before ... */
    this.router.navigate(['/admin/subjects']);
  }
}