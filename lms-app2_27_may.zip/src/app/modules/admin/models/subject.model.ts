import { CourseBasicInfo, MinimalCourseInfo } from "./course.model"; // Assuming Course model exists

// For listing subjects (simplified for now)
export interface SubjectListItem {
  _id: string;
  name: string;
  description: string;
  courseCount?: number; // How many courses this subject is part of
}

// For the "Add Subject" form
export interface SubjectBasicInfo {
  name: string;
  description: string;
  assignedCourseIds?: string[]; // Array of Course IDs this subject should be linked to
}

// For data coming from backend for a single subject (if needed for a detail view later)
export interface SubjectDetailsBackend {
  _id: string;
  SubjectName: string;         // Matches your DB structure
  SubjectDescription: string;  // Matches your DB structure
  SubjectCredits?: number;      // From your DB structure
  // ... other fields from your "Subjects" DB structure
  AssociatedCourses?: MinimalCourseInfo[] | string[]; // Array of associated course objects (with minimal info like ID and name) or just IDs
  created_at: string;
  updated_at: string;
  SubjectLevel?:string;
  SubjectType?:string;
}

export interface ModuleListItemFE {
  isTopicsVisible: boolean;
  topics: any;
  isLoadingTopics: boolean;
  _id: string;
  moduleName: string;
  moduleDescription?: string;
  topicCount: number;
  importance?: string; // Placeholder, e.g., "High", "Medium", "Low" or a number
  // We might also need sequence_order if that dictates display
}

export interface SubjectDetailViewFE extends SubjectDetailsFE { // Extends your existing SubjectDetailsFE for basic info
  associatedCourses: MinimalCourseInfo[]; // Resolved course names
  modules: ModuleListItemFE[];
  // Add other detailed fields from SubjectDetailsBackend if needed for display
  subjectCredits?: number;
  subjectLevel?: string;
  subjectType?: string;
  isTopicsVisible?:Boolean;

}



// For the "Add Module" Form
export interface ModuleBasicInfo {
  moduleName: string;
  moduleDescription?: string;
  // Course IDs this new module is specifically relevant for/required by.
  // This would relate to the 'ReqForCourses' field in the 'modules' DB schema.
  appliesToCourseIds: string[];
  // Topics will be added dynamically within this form.
  // Each topic initially might just be a name.
  initialTopics?: { topicName: string }[];
}

export interface SubjectUpdatePayload {
  name: string;              // Mapped from SubjectName
  description: string;       // Mapped from SubjectDescription
  assignedCourseIds: string[]; // Updated list of associated course IDs
  // Include other editable fields of a subject as needed
}
// For frontend view model of a single subject (if different from backend)
export interface SubjectDetailsFE {
  _id: string;
  name: string;
  description: string;
  credits?: number;
  associatedCoursesDisplay?: string; // Comma-separated list of course names
  createdAt: Date;
  // ... other relevant fields for detail view
}


// ---- Re-using/defining encryption and API response structures ----
// These can be generic if the pattern is the same across entities

export interface EncryptedListPayload {
  responseAesKeyB64: string;
  encryptedData: string;
}

export interface FetchSubjectsApiResponse { // Specific to fetching subjects
  success: boolean;
  statusCode: number;
  data?: EncryptedListPayload; // Where encryptedData contains SubjectDetailsBackend[]
  message: string;
}

export interface EncryptedSubjectRequest { // For sending encrypted subject data (e.g., for add/update)
  encryptedAesKeyB64: string;
  encryptedPayloadB64: string;
}

export interface SubjectMutationResponse { // For backend response when adding/updating a subject
  success: boolean;
  message: string;
  data?: SubjectDetailsBackend; // Return the created/updated subject
  statusCode?: number;
}

export interface TopicDetailsBackend {
  _id: string; // Was TopicID
  TopicName: string;
  ModuleID: string; // ObjectId (ref: 'Module')
  TopicVideos?: string[];
  TopicContent?: string;
  sequence_order?: number;
  is_active?: boolean;
  created_at: string;
  updated_at: string;
}

export interface TopicListItemFE {
  _id: string;
  topicName: string;
  // Add other simple topic details if needed for display, e.g., sequence_order
}