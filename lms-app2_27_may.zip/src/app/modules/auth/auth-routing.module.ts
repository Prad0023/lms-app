import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

// Import the page components to be routed to
import { LoginPageComponent } from './pages/login-page/login-page.component';
import { AdminRegisterPageComponent } from './pages/admin-register-page/admin-register-page.component';

const routes: Routes = [
  {
    path: 'login', // Full path will be /auth/login
    component: LoginPageComponent
  },
  {
    path: 'register-admin', // Full path will be /auth/register-admin
    component: AdminRegisterPageComponent
  },
  {
    path: '', // Default route for /auth
    redirectTo: 'login',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }