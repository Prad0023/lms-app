// src/app/core/guards/auth.guard.ts
import { inject } from '@angular/core';
import { CanActivateFn, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from '../services/auth.service'; // Path if guard is in core/guards and service in core/services
export const authGuard: CanActivateFn = (route: ActivatedRouteSnapshot, state: RouterStateSnapshot) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  console.log("AuthGuard: Checking access for route:", state.url);
  console.log("AuthGuard: isLoggedIn:", authService.isLoggedIn());
  console.log("AuthGuard: currentUserValue:", authService.currentUserValue);

  if (authService.isLoggedIn()) {
    const expectedRoles = route.data['expectedRoles'] as Array<string>;
    console.log("AuthGuard: Expected roles for route:", expectedRoles);

    if (expectedRoles && expectedRoles.length > 0) {
      const user = authService.currentUserValue;
      if (user && user.roles && expectedRoles.some(role => user.roles.map(r => r.toLowerCase()).includes(role.toLowerCase()))) { // Case insensitive for both
        console.log("AuthGuard: Access GRANTED. User has expected role.");
        return true;
      } else {
        console.warn('AuthGuard: Access DENIED - Insufficient Role. User roles:', user?.roles);
        router.navigate(['/']); // Or an '/unauthorized' page
        return false;
      }
    }
    console.log("AuthGuard: Access GRANTED. Logged in and no specific roles required or role check passed.");
    return true;
  }

  console.warn('AuthGuard: Access DENIED - Not Logged In. Redirecting to login.');
  router.navigate(['/auth/login'], { queryParams: { returnUrl: state.url } });
  return false;
};