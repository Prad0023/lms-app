// src/controllers/academic/module.controller.js
import asyncHandler from '../../utils/asyncHandler.utils.js'; // Adjust path
import { ApiResponse, ApiError } from '../../utils/apiResponse.utils.js'; // Adjust path
import { moduleService } from '../../services/module/module.service.js'; // Adjust path
import {
    decryptAesKeyWithRsa,
    decryptPayloadWithAesGcm,
} from '../../utils/crypto.utils.js'; // Adjust path

export const moduleController = {
    bulkCreateTopics: asyncHandler(async (req, res) => {
        const { subjectId, moduleId } = req.params;
        const { encryptedAesKeyB64, encryptedPayloadB64 } = req.body;

        if (!subjectId || !moduleId) {
            throw new ApiError(400, 'Subject ID and Module ID are required in the URL path.');
        }
        if (!encryptedAesKeyB64 || !encryptedPayloadB64) {
            throw new ApiError(400, 'Encrypted AES key and payload are required.');
        }

        const aesKeyBuffer = decryptAesKeyWithRsa(encryptedAesKeyB64);
        const decryptedTopicsArrayFromFrontend = decryptPayloadWithAesGcm(encryptedPayloadB64, aesKeyBuffer);
        // decryptedTopicsArrayFromFrontend is expected to be an array of topic objects:
        // [ { topicName, topicContent, ... }, ... ]

        console.log('[ModuleController] bulkCreateTopics - Decrypted data (should be an array of topics):', JSON.stringify(decryptedTopicsArrayFromFrontend, null, 2));

        if (!Array.isArray(decryptedTopicsArrayFromFrontend)) {
             throw new ApiError(400, 'Decrypted payload must be an array of topic objects.');
        }
        // The service will handle if the array is empty or if individual topics are invalid.

        // Map frontend field names to what the service expects for each topic, if necessary
        // For this example, assume frontend sends fields like TopicName, TopicContent directly.
        // If frontend sends 'name', 'content', you'd map them here:
        const topicsDataForService = decryptedTopicsArrayFromFrontend.map(ft => ({
            TopicName: ft.topicName || ft.TopicName, // Accept either casing for flexibility
            TopicContent: ft.topicContent || ft.TopicContent,
            TopicVideos: ft.topicVideos || ft.TopicVideos,
            sequence_order: ft.sequence_order || ft.sequence_order,
            // ... map other topic fields
        }));


        const adminUserId = req.user.id; // From protect middleware
        const result = await moduleService.bulkCreateTopicsForModule(
            subjectId,
            moduleId,
            topicsDataForService, // Pass the array of topic data
            adminUserId
        );

        res.status(201).json(new ApiResponse(201, result, result.message));
    }),

    // Other module controller methods...
};