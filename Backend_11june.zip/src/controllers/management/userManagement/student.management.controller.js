// src/controllers/management/userManagement/student.management.controller.js
import asyncHandler from '../../../utils/asyncHandler.utils.js';
import { ApiResponse, ApiError } from '../../../utils/apiResponse.utils.js';
import { studentService } from '../../../services/student/student.service.js';
import {
    decryptAesKeyWithRsa,
    decryptPayloadWithAesGcm,
    encryptPayloadWithAesGcm // For response if needed
} from '../../../utils/crypto.utils.js';
import cryptoNode from 'crypto';


export const studentManagementController = {
    viewAllStudents: asyncHandler(async (req, res) => {
        // console.log('[StudentMgmtController] viewAllStudents called by admin:', req.user.id);

        const students = await studentService.getAllStudents();

        if (!students || students.length === 0) {
            return res.status(200).json(new ApiResponse(200, [], 'No students found.'));
        }

        // Encrypt the response
        const responseAesKeyBuffer = cryptoNode.randomBytes(32); // New AES key for this response
        const encryptedStudentsDataB64 = encryptPayloadWithAesGcm(students, responseAesKeyBuffer);

        const responsePayload = {
            responseAesKeyB64: responseAesKeyBuffer.toString('base64'),
            encryptedData: encryptedStudentsDataB64
        };

        // console.log('[StudentMgmtController] Sending encrypted student list.');
        res.status(200).json(new ApiResponse(200, responsePayload, 'Students list retrieved and encrypted.'));
    }),

    initiateStudentEnrollment: asyncHandler(async (req, res) => {
        const { encryptedAesKeyB64, encryptedPayloadB64 } = req.body;

        if (!encryptedAesKeyB64 || !encryptedPayloadB64) {
            throw new ApiError(400, 'Encrypted AES key and payload are required for student enrollment.');
        }

        let aesKeyBuffer;
        try {
            aesKeyBuffer = decryptAesKeyWithRsa(encryptedAesKeyB64);
        } catch (rsaError) {
            throw rsaError;
        }
        
        if (typeof aesKeyBuffer === 'undefined') {
            throw new ApiError(500, 'Internal server error: AES key became undefined unexpectedly during student enrollment.');
        }

        let decryptedEnrollmentRequestData;
        try {
            decryptedEnrollmentRequestData = decryptPayloadWithAesGcm(encryptedPayloadB64, aesKeyBuffer);
        } catch (aesError) {
            throw aesError;
        }

        // Expected: { studentInfo: { fullName, email, mobile?, course? }, sendInviteEmail: boolean }
        if (!decryptedEnrollmentRequestData || !decryptedEnrollmentRequestData.studentInfo || typeof decryptedEnrollmentRequestData.sendInviteEmail === 'undefined') {
            throw new ApiError(400, 'Decrypted payload for student enrollment is malformed or missing studentInfo/sendInviteEmail field.');
        }

        const adminUserId = req.user.id; // From protect middleware
        const ipAddress = req.ip;
        const userAgent = req.headers['user-agent'];

        const result = await studentService.initiateStudentEnrollmentByAdmin(
            decryptedEnrollmentRequestData,
            adminUserId,
            ipAddress,
            userAgent
        );

        res.status(201).json(new ApiResponse(201, result, result.message));
    }),

    // Placeholder for other admin actions on students:
    // getStudentById: asyncHandler(async (req, res) => { ... }),
    // updateStudentProfileByAdmin: asyncHandler(async (req, res) => { ... }),
    // suspendStudentAccount: asyncHandler(async (req, res) => { ... }),
};