// src/controllers/auth.controller.js
import { authService } from '../services/auth.service.js';
import asyncHandler from '../utils/asyncHandler.utils.js';
import { ApiResponse } from '../utils/apiResponse.utils.js';
import {
    getServerRsaPublicKeyPem,
    decryptAesKeyWithRsa,
    decryptPayloadWithAesGcm
} from '../utils/crypto.utils.js';
import { ROLES } from '../services/common/seed.service.js';
import cryptoNode from 'crypto';
import {encryptPayloadWithAesGcm} from '../utils/crypto.utils.js';


export const authController = {


    getPublicKey: asyncHandler(async (req, res) => {
        const publicKeyPem = getServerRsaPublicKeyPem(); // Throws ApiError if not available
        res.status(200).json(new ApiResponse(200, { publicKey: publicKeyPem }));
    }),

    // registerFirstAdmin: asyncHandler(async (req, res) => {
    //     const { email, mobile_number, full_name, password } = req.body;
    //     const ipAddress = req.ip;
    //     const userAgent = req.headers['user-agent'];

    //     const result = await authService.registerFirstAdmin(
    //         { email, mobile_number, full_name, password },
    //         ipAddress,
    //         userAgent
    //     );
    //     res.status(201).json(new ApiResponse(201, result.user, result.message));
    // }),
    registerFirstAdmin: asyncHandler(async (req, res) => {
        // For this specific "first admin" scenario, we assume direct plaintext input.
        // If you wanted to encrypt this payload too, you'd follow the login pattern.
        const { email, mobile_number, full_name, password } = req.body;

        if (!email || !full_name || !password) {
            throw new ApiError(400, "Email, full name, and password are required for admin registration.");
        }

        const ipAddress = req.ip;
        const userAgent = req.headers['user-agent'];

        const result = await authService.registerFirstAdmin(
            { email, mobile_number, full_name, password },
            ipAddress,
            userAgent
        );
        res.status(201).json(new ApiResponse(201, result.user, result.message));
    }),
// backend/src/controllers/auth.controller.js
login: asyncHandler(async (req, res) => { // asyncHandler wraps this
    const { encryptedAesKeyB64, encryptedPayloadB64 } = req.body;

    // console.log('[Controller] Received encryptedAesKeyB64:', encryptedAesKeyB64 ? 'Exists' : 'Missing');
    // console.log('[Controller] Received encryptedPayloadB64:', encryptedPayloadB64 ? 'Exists' : 'Missing');

    if (!encryptedAesKeyB64 || !encryptedPayloadB64) {
        // This would throw and respond
        throw new ApiError(400, 'Encrypted AES key and payload are required.');
    }

    let aesKeyBuffer;
    try {
        // console.log('[Controller] Attempting to decrypt AES key with RSA...');
        aesKeyBuffer = decryptAesKeyWithRsa(encryptedAesKeyB64); // Synchronous call
        // console.log('[Controller] RSA Decryption of AES key finished. aesKeyBuffer type:', typeof aesKeyBuffer, 'Is Buffer?', Buffer.isBuffer(aesKeyBuffer));
        // ... (logging for buffer check)
    } catch (rsaError) {
        // This would throw and respond
        // console.error('[Controller] Error during RSA decryption of AES key:', rsaError.message, rsaError.stack);
        throw rsaError;
    }
    
    if (typeof aesKeyBuffer === 'undefined') {
        // This would throw and respond
        // console.error('[Controller] CRITICAL: aesKeyBuffer is undefined BEFORE calling decryptPayloadWithAesGcm...');
        throw new ApiError(500, 'Internal server error: AES key became undefined unexpectedly.');
    }

    // console.log('[Controller] Attempting to decrypt payload with AES. AES Key Buffer Length:', aesKeyBuffer ? aesKeyBuffer.length : 'undefined');
    const decryptedCredentials = decryptPayloadWithAesGcm(encryptedPayloadB64, aesKeyBuffer); // Synchronous call
    
    // Assuming decryption was successful, decryptedCredentials = { email, password }

    const ipAddress = req.ip;
    const userAgent = req.headers['user-agent'];

    // console.log('[Controller] Calling authService.loginUser with:', decryptedCredentials); // Add this log
    
    // POTENTIAL HANG POINT: The call to authService.loginUser
    const result = await authService.loginUser( // THIS IS AN ASYNC CALL
        { email: decryptedCredentials.email, password: decryptedCredentials.password },
        ipAddress,
        userAgent
    );
    // If authService.loginUser hangs, the code never reaches here.

    // console.log('[Controller] authService.loginUser returned. Sending response.'); // Add this log

    res.status(200).json(new ApiResponse(200, {
        token: result.token,
        user: result.user,
        expiresIn: result.expiresIn
    }, result.message));
}),


    // login: asyncHandler(async (req, res) => {
    //     const { email, password } = req.body;
    //     const ipAddress = req.ip;
    //     const userAgent = req.headers['user-agent'];

    //     const result = await authService.loginUser({ email, password }, ipAddress, userAgent);

    //     // It's common to send the token in a cookie for web apps, or in the response body for APIs.
    //     // HttpOnly cookie is more secure against XSS.
    //     // For now, sending in response body.
    //     res.status(200).json(new ApiResponse(200, {
    //         token: result.token,
    //         user: result.user, // Contains user details without sensitive info
    //         expiresIn: result.expiresIn
    //     }, result.message));
    // }),

    // Add other auth-related controllers here (logout, refreshToken, etc.)

  registerStudent: asyncHandler(async (req, res) => {
        const { fullName, email, password, mobileNumber } = req.body;

        const ipAddress = req.ip;
        const userAgent = req.headers['user-agent'];

        const serviceResult = await authService.registerStudent(
            { fullName, email, password, mobileNumber },
            ipAddress,
            userAgent
        );
        // serviceResult is now { message, responseData: { userId, email } }

        // --- Encrypt the responseData part ---
        const responseAesKeyBuffer = cryptoNode.randomBytes(32); // cryptoNode is now defined
        const encryptedResponseDataB64 = encryptPayloadWithAesGcm(
            serviceResult.responseData, // Encrypt only the data part
            responseAesKeyBuffer
        );

        const finalResponsePayload = {
            responseAesKeyB64: responseAesKeyBuffer.toString('base64'),
            encryptedData: encryptedResponseDataB64
        };
        // --- End of Encryption ---

        res.status(201).json(new ApiResponse(201, finalResponsePayload, serviceResult.message));
    }),

    verifyEmailOtp: asyncHandler(async (req, res) => {
        const { email, otp } = req.body; // Plaintext from client
        const ipAddress = req.ip;
        const userAgent = req.headers['user-agent'];

        const result = await authService.verifyEmailOtp(email, otp, ipAddress, userAgent);
        // result contains { message, is_active, status, user }

        // You can choose to encrypt this response if needed, similar to registerStudent response
        // For now, sending it plaintext as it's a status update.
        res.status(200).json(new ApiResponse(200, { user: result.user, is_active: result.is_active, status: result.status }, result.message));
    }),

    verifyMobileOtp: asyncHandler(async (req, res) => {
        const { mobileNumber, otp } = req.body; // <<< Values are taken from req.body
        const ipAddress = req.ip;
        const userAgent = req.headers['user-agent'];

        // Add a log here to see what was received
        console.log('[AuthCtrl-VerifyMobile] Received for mobile OTP verification:');
        console.log('[AuthCtrl-VerifyMobile] mobileNumber:', mobileNumber);
        console.log('[AuthCtrl-VerifyMobile] otp:', otp);

        const result = await authService.verifyMobileOtp(mobileNumber, otp, ipAddress, userAgent);
        // ...
        res.status(200).json(new ApiResponse(200, { user: result.user, is_active: result.is_active, status: result.status }, result.message));
    }),
};