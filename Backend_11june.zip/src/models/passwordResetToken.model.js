import mongoose from 'mongoose';
import crypto from 'crypto'; // For generating a secure token

const passwordResetTokenSchema = new mongoose.Schema({
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    token_hash: { type: String, required: true, unique: true }, // Store a hash of the token
    created_at: { type: Date, default: Date.now },
    expires_at: {
        type: Date,
        required: true,
        // index: { expires: '0s' } // TTL index
    },
    used: { type: Boolean, default: false },
});

// TTL Index for automatic expiration
passwordResetTokenSchema.index({ expires_at: 1 }, { expireAfterSeconds: 0 });
passwordResetTokenSchema.index({ user_id: 1 });

// Instance method to generate and hash token before saving (if needed, or do in service)
// Or generate the token in the service and just store the hash here.
// For now, we'll assume token is generated in service and only hash is stored.

const PasswordResetToken = mongoose.model('PasswordResetToken', passwordResetTokenSchema);
export default PasswordResetToken;