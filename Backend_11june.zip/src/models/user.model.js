import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const credentialSchema = new mongoose.Schema({
    password_hash: { type: String, required: true },
    // password_salt: { type: String, required: true }, // bcrypt stores salt within the hash
    last_password_change: { type: Date, default: Date.now },
    failed_login_attempts: { type: Number, default: 0 },
    lockout_until: { type: Date, default: null },
}, { _id: false });

const userRoleSchema = new mongoose.Schema({
    role_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Role', required: true },
    granted_at: { type: Date, default: Date.now },
    granted_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null }, // null for self-registration or system
    expires_at: { type: Date, default: null },
}, { _id: false });

const oAuthAccountSchema = new mongoose.Schema({ // For future Google/Facebook login
    provider: { type: String, required: true }, // e.g., 'google', 'facebook'
    provider_user_id: { type: String, required: true },
    access_token: String,
    refresh_token: String,
    email: String, // Email from provider
}, { _id: false });

const userSchema = new mongoose.Schema({
    email: {
        type: String,
        required: [true, 'Email is required.'],
        unique: true,
        trim: true,
        lowercase: true,
        match: [/\S+@\S+\.\S+/, 'Please use a valid email address.'],
    },
    mobile_number: {
        type: String,
        // unique: true, // Can be problematic if not always provided or verified
        trim: true,
        // Add validation if needed, e.g., for a specific country format
    },
    full_name: {
        type: String,
        required: [true, 'Full name is required.'],
        trim: true,
    },
    email_verified: { type: Boolean, default: false },
    mobile_verified: { type: Boolean, default: false },
    email_verification_token: String,
    mobile_verification_code: String,
    is_active: { type: Boolean, default: true }, // For soft delete or disabling accounts
    created_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null }, // Admin who created this user

    credentials: { type: credentialSchema, select: false }, // Exclude by default when querying
    roles: [userRoleSchema],
    oauth_accounts: [oAuthAccountSchema], // For future social logins

    is_active: { type: Boolean, default: false }, // Default to false until verified
    status: {
        type: String,
        enum: [
            'pending_setup', // For admin-initiated teacher/student
            'pending_admin_verification',
            'pending_email_verification',   // For self-registered student
            'pending_mobile_verification',  // If mobile OTP is next step
            'active',
            'inactive',
            'suspended'
        ],
        default: 'pending_email_verification',
    },
    email_verification_token: String, // For storing email verification token/OTP hash
    email_verification_expires: Date,
    mobile_verification_code: String, // For storing mobile OTP hash
    mobile_verification_expires: Date,

    created_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    // Additional profile fields (optional)
    // profile_picture_url: String,
    // bio: String,
    // date_of_birth: Date,

}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });

// Indexes (Mongoose will create these)
// userSchema.index({ email: 1 });
userSchema.index({ mobile_number: 1 }, { unique: true, sparse: true }); // Sparse allows nulls but unique if value exists
userSchema.index({ "roles.role_id": 1 });

// Pre-save hook to hash password
userSchema.pre('save', async function (next) {
    if (!this.isModified('credentials.password_hash') || !this.credentials?.password_hash) {
        return next();
    }
    // Add a check to see if it's already hashed (simple check, not foolproof but good for debugging)
    if (this.credentials.password_hash.startsWith('$2a$') || this.credentials.password_hash.startsWith('$2b$')) {
        console.log(`[User Pre-Save] Password for ${this.email} appears to be already hashed. Skipping re-hash.`);
        return next();
    }

    console.log(`[User Pre-Save] Hashing password for ${this.email}`); // Add this log
    try {
        const salt = await bcrypt.genSalt(10);
        this.credentials.password_hash = await bcrypt.hash(this.credentials.password_hash, salt);
        // this.credentials.last_password_change = Date.now(); // Already set elsewhere if password updated
        next();
    } catch (error) {
        console.error(`[User Pre-Save] Error hashing password for ${this.email}:`, error);
        next(error); // Pass error to Mongoose
    }
});

// Method to compare password
userSchema.methods.comparePassword = async function (enteredPassword) {
    if (!this.credentials || !this.credentials.password_hash) return false;
    return await bcrypt.compare(enteredPassword, this.credentials.password_hash);
};

const User = mongoose.model('User', userSchema);
export default User;