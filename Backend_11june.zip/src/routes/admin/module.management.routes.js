// src/routes/admin/subject.management.routes.js
import { Router } from 'express';
// Import subjectController for subject-level routes
import { subjectController } from '../../controllers/academic/subject.controller.js';
// Import moduleController for module-level routes related to a subject
import { moduleController } from '../../controllers/academic/module.controller.js'; // New import
import { protect } from '../../middlewares/auth.middleware.js';
import { authorizePermission } from '../../middlewares/role.middleware.js';

const subjectRouter = Router(); // Main router for /api/v1/admin/subjects

// --- Subject-Level Routes ---
subjectRouter.post(
    '/create',
    protect,
    authorizePermission('subject', 'create'),
    subjectController.createSubject
);
subjectRouter.get(
    '/view-all',
    protect,
    authorizePermission('subject', 'read_all'),
    subjectController.getAllSubjects
);
subjectRouter.get(
    '/:subjectId',
    protect,
    authorizePermission('subject', 'read_one'),
    subjectController.getSubjectById
);

// --- Module Creation for a specific Subject ---
// POST /api/v1/admin/subjects/:subjectId/modules/create (for adding multiple modules with their topics to a subject)
// This was the route we worked on previously, handled by subjectController.addModulesAndTopics
subjectRouter.post(
    '/:subjectId/modules/create', // Changed from 'modules-topics' to match your 404 path more closely
    protect,
    authorizePermission('subject', 'update'), // Or 'module_create'
    subjectController.addModulesAndTopics
);


// --- Topic Creation for a specific Module within a specific Subject ---
/**
 * @route   POST /api/v1/admin/subjects/:subjectId/modules/:moduleId/topics/bulk-create
 * @desc    Admin bulk creates topics for a specific module of a subject.
 *          Encrypted Payload: [ { topicName, topicContent, ... }, ... ]
 * @access  Private (Admin with 'module_update' or 'topic_create' permission)
 */
subjectRouter.post(
    '/:subjectId/modules/:moduleId/topics/bulk-create', // This matches your 404 path
    protect,
    authorizePermission('module', 'update'), // Or a more granular 'topic_create' on 'module' or 'topic' resource
    moduleController.bulkCreateTopics // Use the new moduleController method
);


export default subjectRouter; // Export the main subjectRouter