// src/routes/admin/student.management.routes.js
import { Router } from 'express';
import { studentManagementController } from '../../controllers/management/userManagement/student.management.controller.js'; // Adjust path
import { protect } from '../../middlewares/auth.middleware.js'; // Adjust path
import { authorizePermission } from '../../middlewares/role.middleware.js'; // Adjust path

const router = Router();

/**
 * @route   GET /api/v1/admin/students/view-students
 * @desc    Admin views a list of all students (response is encrypted)
 * @access  Private (Admin with 'user_read_all' or specific student read permission)
 */
router.get(
    '/view-students', // Mount point relative to /api/v1/admin/students
    protect,
    authorizePermission('user', 'read_all'), // Or a more specific permission like 'student_read_all'
    studentManagementController.viewAllStudents
);

router.post(
    '/initiate-enrollment',
    protect,
    authorizePermission('user', 'create'), // Or a more specific 'student_create' permission
    studentManagementController.initiateStudentEnrollment
);

// Add other student management routes here later, e.g.:
// router.get('/:studentId', protect, authorizePermission(...), studentManagementController.getStudentById);

export default router;