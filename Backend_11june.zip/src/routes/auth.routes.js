import { Router } from 'express';
// We'll import controllers and middlewares later
import { authController } from '../controllers/auth.controller.js';
const router = Router();

// Placeholder route
router.get('/', (req, res) => {
    res.send('Auth routes are working!');
});
router.get('/public-key', authController.getPublicKey);
router.post('/register-first-admin', authController.registerFirstAdmin); // Correct path and controller method
router.post('/login', authController.login);
router.post('/register-student', authController.registerStudent);
/**
 * @route   POST /api/v1/auth/verify-email-otp
 * @desc    Verify email OTP sent during student registration.
 * @access  Public
 */
router.post('/verify-email-otp', authController.verifyEmailOtp);

/**
 * @route   POST /api/v1/auth/verify-mobile-otp
 * @desc    Verify mobile OTP sent during student registration.
 * @access  Public
 */
router.post('/verify-mobile-otp', authController.verifyMobileOtp);


// TODO: Add routes for resending OTPs
// router.post('/resend-email-otp', authController.resendEmailOtp);
// router.post('/resend-mobile-otp', authController.resendMobileOtp);
export default router;