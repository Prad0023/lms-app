// src/services/email.service.js
export const sendTeacherOnboardingEmail = async (toEmail, teacherName, onboardingLink, temporaryPassword) => {
    console.log("======================================================");
    console.log("SIMULATING SENDING ONBOARDING EMAIL");
    console.log("To:", toEmail);
    console.log("Name:", teacherName);
    console.log("Onboarding Link:", onboardingLink);
    console.log("Temporary Password (for user to change):", temporaryPassword);
    console.log("Email Subject: Complete Your Teacher Profile Setup");
    console.log("Email Body: Hello " + teacherName + ", please complete your profile using this link: " + onboardingLink +
                ". Your temporary password is: " + temporaryPassword + ". You will be asked to set a new password.");
    console.log("======================================================");
    // In a real app, use Nodemailer or a similar library to send actual emails
    return Promise.resolve();
};


export const sendStudentOnboardingEmail = async (toEmail, studentName, onboardingLink, temporaryPassword) => {
    console.log("======================================================");
    console.log("SIMULATING SENDING STUDENT ONBOARDING EMAIL");
    console.log("To:", toEmail);
    console.log("Name:", studentName);
    console.log("Onboarding Link:", onboardingLink);
    console.log("Temporary Password (for user to change):", temporaryPassword);
    console.log("Email Subject: Welcome! Complete Your Student Registration");
    console.log("Email Body: Hello " + studentName + ", please complete your registration using this link: " + onboardingLink +
                ". Your temporary password is: " + temporaryPassword + ". You will be asked to set a new password.");
    console.log("======================================================");
    // In a real app, use Nodemailer or a similar library
    return Promise.resolve();
};


// src/services/common/email.service.js
// ... (sendTeacherOnboardingEmail, sendStudentOnboardingEmail by admin)

export const sendEmailVerificationEmail = async (toEmail, userName, otp) => {
    console.log("======================================================");
    console.log("SIMULATING SENDING EMAIL VERIFICATION OTP");
    console.log("To:", toEmail);
    console.log("Name:", userName);
    console.log("Email Verification OTP:", otp); // This is the PLAINTEXT OTP
    console.log("Email Subject: Verify Your Email Address");
    console.log("Email Body: Hello " + userName + ", your email verification OTP is: " + otp + ". It expires in 10 minutes.");
    console.log("======================================================");
    return Promise.resolve();
};

export const sendMobileVerificationOtp = async (mobileNumber, otp) => {
    console.log("======================================================");
    console.log("SIMULATING SENDING MOBILE VERIFICATION OTP VIA SMS");
    console.log("To Mobile:", mobileNumber);
    console.log("Mobile Verification OTP:", otp); // This is the PLAINTEXT OTP
    console.log("SMS Body: Your verification OTP is: " + otp + ". It expires in 10 minutes.");
    console.log("======================================================");
    return Promise.resolve();
};
// Add other email functions as needed (password reset, etc.)