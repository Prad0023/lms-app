// src/services/auth.service.js
import bcrypt from 'bcryptjs';
import crypto from 'crypto'; // For hashing tokens if needed, or generating random strings
import User from '../models/user.model.js';
import Role from '../models/role.model.js';
import Session from '../models/session.model.js';
import { ApiError } from '../utils/apiResponse.utils.js';
import { generateToken } from '../utils/jwt.utils.js';
import { logAuditEvent } from './common/audit.service.js'; // Assuming this is the correct path
import { ROLES } from './common/seed.service.js'; // To get 'admin' role name
import config from '../config/env.config.js';
import mongoose from 'mongoose';
// import bcrypt from 'bcryptjs';
// import { sendEmailVerificationEmail, sendMobileVerificationOtp } from './common/email.service.js'; // Create these

// OTP Configuration (as per your request)
const DEFAULT_EMAIL_OTP = "666666";
const DEFAULT_MOBILE_OTP = "666666"; // Using the same for simplicity, can be different
const OTP_EXPIRY_MINUTES = 10;

const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_TIME_MINUTES = 30;

export const authService = {
    /**
     * Registers the first administrator for the system.
     * This should ideally be a one-time setup.
     * 
     * 
     */
    registerFirstAdmin: async (userData, ipAddress, userAgent) => {
        const { email, mobile_number, full_name, password } = userData;

        const adminRole = await Role.findOne({ name: ROLES.ADMIN });
        if (!adminRole) {
            throw new ApiError(500, 'Admin role not configured. Please seed roles.');
        }

        // Check if an admin user already exists
        const existingAdmin = await User.findOne({ email:email });
        if (existingAdmin) {
            throw new ApiError(409, 'An administrator account already exists ok. This action is for initial setup.');
        }

        // Validate password strength (basic example)
        if (!password || password.length < 8) {
            throw new ApiError(400, 'Password must be at least 8 characters long.');
        }

        const newUser = new User({
            email,
            mobile_number,
            full_name,
            email_verified: true, // As per story for first admin
            mobile_verified: true, // As per story for first admin
            is_active: true,
            credentials: { // Password will be hashed by pre-save hook
                password_hash: password,
            },
            roles: [{
                role_id: adminRole._id,
                granted_at: new Date(),
                granted_by: null, // First admin has no grantor
            }]
        });

        const savedUser = await newUser.save();

        // Log audit event for registration
        await logAuditEvent({
            userId: savedUser._id,
            event_type: 'registration',
            resource: 'users',
            action: 'create_first_admin',
            status: 'success',
            ip_address: ipAddress,
            user_agent: userAgent,
            details: { email: savedUser.email, role: ROLES.ADMIN }
        });

        // Exclude sensitive data from return
        const userToReturn = savedUser.toObject();
        delete userToReturn.credentials;
        delete userToReturn.roles; // Or transform roles to show names if needed

        return { user: userToReturn, message: "Admin registered successfully. Please log in." };
    },

    
    registerStudent: async (registrationData, ipAddress, userAgent) => {
        const { fullName, email, password, mobileNumber } = registrationData;

        console.log(`[AuthService-RegStudent] Attempting registration for email: ${email}, mobile: ${mobileNumber}`);

        if (!fullName || !email || !password) {
            throw new ApiError(400, 'Full name, email, and password are required.');
        }
        if (password.length < 8) {
            throw new ApiError(400, 'Password must be at least 8 characters long.');
        }

        const studentRole = await Role.findOne({ name: ROLES.STUDENT });
        if (!studentRole) {
            throw new ApiError(500, 'Student role not configured. Please seed roles.');
        }

        let existingUserByEmail = await User.findOne({ email });
        let isReVerification = false;
        let userToProcess; // Declare here to be accessible for audit log and return

        if (existingUserByEmail) {
            console.log(`[AuthService-RegStudent] Found existing user by email: ${email}. User ID: ${existingUserByEmail._id}, isActive: ${existingUserByEmail.is_active}, emailVerified: ${existingUserByEmail.email_verified}, status: ${existingUserByEmail.status}`);

            if (existingUserByEmail.is_active || existingUserByEmail.email_verified) {
                console.log(`[AuthService-RegStudent] Existing user ${email} is active or email verified. Throwing 409.`);
                throw new ApiError(409, `This email address (${email}) is already registered and verified/active.`);
            } else {
                isReVerification = true;
                console.log(`[AuthService-RegStudent] Email ${email} found for unverified user. Flagging for re-verification.`);
                existingUserByEmail.full_name = fullName;
                existingUserByEmail.credentials.password_hash = password;
                existingUserByEmail.credentials.last_password_change = new Date();

                if (mobileNumber) {
                    const otherUserWithThisMobile = await User.findOne({
                        mobile_number: mobileNumber,
                        _id: { $ne: existingUserByEmail._id },
                        mobile_verified: true
                    });
                    if (otherUserWithThisMobile) {
                        console.log(`[AuthService-RegStudent] Mobile number ${mobileNumber} already verified by another user: ${otherUserWithThisMobile._id}. Throwing 409.`);
                        throw new ApiError(409, `This mobile number (${mobileNumber}) is already registered and verified by another account.`);
                    }
                    existingUserByEmail.mobile_number = mobileNumber;
                    existingUserByEmail.mobile_verified = false;
                } else {
                    existingUserByEmail.mobile_number = undefined;
                    existingUserByEmail.mobile_verified = false;
                }
                existingUserByEmail.status = 'pending_email_verification';
                existingUserByEmail.is_active = false;
                userToProcess = existingUserByEmail; // Assign to userToProcess
            }
        } else if (mobileNumber) {
            console.log(`[AuthService-RegStudent] No user by email ${email}. Checking mobile: ${mobileNumber}`);
            const existingVerifiedMobileUser = await User.findOne({ mobile_number: mobileNumber, mobile_verified: true });
            if (existingVerifiedMobileUser) {
                console.log(`[AuthService-RegStudent] Mobile number ${mobileNumber} already verified by user: ${existingVerifiedMobileUser._id} (${existingVerifiedMobileUser.email}). Throwing 409.`);
                throw new ApiError(409, `This mobile number (${mobileNumber}) is already registered and verified.`);
            }
            console.log(`[AuthService-RegStudent] No existing verified user by mobile ${mobileNumber}. Proceeding to create new user.`);
        } else {
            console.log(`[AuthService-RegStudent] No existing user by email ${email} and no mobile provided for further checks. Proceeding to create new user.`);
        }

        const emailOtpPlain = DEFAULT_EMAIL_OTP;
        const emailOtpHash = await bcrypt.hash(emailOtpPlain, 10);
        const emailOtpExpires = new Date(Date.now() + OTP_EXPIRY_MINUTES * 60 * 1000);

        let mobileOtpHash = null, mobileOtpExpires = null, mobileOtpPlainForSim = null;
        const finalMobileNumber = mobileNumber || (isReVerification && userToProcess ? userToProcess.mobile_number : undefined);

        if (finalMobileNumber) {
            mobileOtpPlainForSim = DEFAULT_MOBILE_OTP;
            mobileOtpHash = await bcrypt.hash(mobileOtpPlainForSim, 10);
            mobileOtpExpires = new Date(Date.now() + OTP_EXPIRY_MINUTES * 60 * 1000);
        }

        if (isReVerification && userToProcess) {
            console.log(`[AuthService-RegStudent] Updating existing unverified user ${userToProcess.email} with new OTPs.`);
            userToProcess.email_verification_token = emailOtpHash;
            userToProcess.email_verification_expires = emailOtpExpires;
            userToProcess.mobile_verification_code = mobileOtpHash;
            userToProcess.mobile_verification_expires = mobileOtpExpires;
            await userToProcess.save(); // userToProcess is already the existingUserByEmail instance
            console.log(`[AuthService-RegStudent] Existing user ${userToProcess.email} updated and saved.`);
        } else if (!isReVerification) { // Only create if not a re-verification case
            console.log(`[AuthService-RegStudent] Creating new user with email ${email}.`);
            try {
                userToProcess = await User.create({
                    full_name: fullName,
                    email,
                    credentials: { password_hash: password },
                    mobile_number: mobileNumber || undefined,
                    roles: [{ role_id: studentRole._id, granted_at: new Date(), granted_by: null }],
                    is_active: false,
                    status: 'pending_email_verification',
                    email_verified: false,
                    mobile_verified: false,
                    email_verification_token: emailOtpHash,
                    email_verification_expires: emailOtpExpires,
                    mobile_verification_code: mobileOtpHash,
                    mobile_verification_expires: mobileOtpExpires,
                    created_by: null,
                });
                console.log(`[AuthService-RegStudent] New user ${userToProcess.email} created successfully.`);
            } catch (error) {
                console.error(`[AuthService-RegStudent] Error during User.create for email ${email}:`, error.message);
                if (error.code === 11000) {
                    let field = 'unknown field';
                    if (error.message.includes('email_1')) field = 'email';
                    else if (error.message.includes('mobile_number_1')) field = 'mobile number';
                    console.error(`[AuthService-RegStudent] Duplicate key error on User.create for ${field}. Email: ${email}, Mobile: ${mobileNumber}`);
                    throw new ApiError(409, `This ${field} is already actively registered.`);
                }
                throw error;
            }
        }


        // --- Send Verification Communications (Simulated) ---
        // Ensure userToProcess is defined before trying to access its properties
        if (userToProcess) {
            console.log(`SIMULATED: Email OTP for ${userToProcess.email}: ${emailOtpPlain}`);
            if (userToProcess.mobile_number && mobileOtpPlainForSim) {
                console.log(`SIMULATED: Mobile OTP for ${userToProcess.mobile_number}: ${mobileOtpPlainForSim}`);
            }

            await logAuditEvent({
                userId: userToProcess._id,
                event_type: isReVerification ? 're_verification_initiated' : 'registration',
                resource: 'users',
                resource_id: userToProcess._id,
                action: isReVerification ? 'student_re_verify_initiated' : 'student_self_register',
                status: 'success', // Or 'pending' based on your AuditLog enum for this event
                ip_address: ipAddress,
                user_agent: userAgent,
                details: { email: userToProcess.email, reVerification: isReVerification }
            });

            let message = isReVerification
                ? `Verification process re-initiated for ${userToProcess.email}. Please check your email for a new OTP.`
                : `Student account created for ${userToProcess.email}. Please check your email to verify your account.`;

            if (userToProcess.mobile_number && mobileOtpPlainForSim) {
                message += " Also, check your mobile for an OTP if provided.";
            }

            return {
                message: message,
                responseData: {
                    userId: userToProcess._id.toString(),
                    email: userToProcess.email,
                }
            };
        } else {
            // This case should ideally not be reached if logic is correct,
            // but as a fallback if existingUserByEmail was not found and creation somehow didn't set userToProcess.
            console.error("[AuthService-RegStudent] Critical error: userToProcess is undefined before returning.");
            throw new ApiError(500, "An unexpected error occurred during registration.");
        }
    },

    /**
     * Logs in a user.
     */
    loginUser: async (credentials, ipAddress, userAgent) => {
        const { email, password } = credentials;

        if (!email || !password) {
            throw new ApiError(400, 'Email and password are required.');
        }
        console.log(email)
        const user = await User.findOne({ email }).select('+credentials'); // Explicitly select credentials

        if (!user) {
            throw new ApiError(401, 'Invalid email or password.');
        }

        if (!user.is_active) {
            throw new ApiError(403, 'Account is inactive. Please contact support.');
        }

        if (user.credentials.lockout_until && user.credentials.lockout_until > new Date()) {
            await logAuditEvent({ // Log failed attempt due to lockout
                userId: user._id,
                event_type: 'login_attempt',
                resource: 'session',
                action: 'attempt',
                status: 'failure',
                ip_address: ipAddress,
                user_agent: userAgent,
                details: { email: user.email, reason: 'account_locked', lockout_until: user.credentials.lockout_until }
            });
            throw new ApiError(403, `Account locked due to too many failed login attempts. Try again after ${user.credentials.lockout_until.toLocaleTimeString()}.`);
        }

        const isMatch = await user.comparePassword(password);

        if (!isMatch) {
            user.credentials.failed_login_attempts = (user.credentials.failed_login_attempts || 0) + 1;
            if (user.credentials.failed_login_attempts >= MAX_LOGIN_ATTEMPTS) {
                user.credentials.lockout_until = new Date(Date.now() + LOCKOUT_TIME_MINUTES * 60 * 1000);
            }
            await user.save();

            await logAuditEvent({
                userId: user._id,
                event_type: 'login_attempt',
                resource: 'session',
                action: 'attempt',
                status: 'failure',
                ip_address: ipAddress,
                user_agent: userAgent,
                details: { email: user.email, reason: 'invalid_credentials', attempts: user.credentials.failed_login_attempts }
            });
            throw new ApiError(401, 'Invalid email or password.');
        }

        // Successful login: reset failed attempts and lockout
        user.credentials.failed_login_attempts = 0;
        user.credentials.lockout_until = null;
        await user.save();

        const userRoles = await Role.find({ _id: { $in: user.roles.map(r => r.role_id) } }).select('name');
        const roleNames = userRoles.map(r => r.name);

        const token = generateToken(user._id.toString(), roleNames);

        // Hash the token for storage in the session document as per the original document
        // Note: bcrypt is for passwords. For JWTs, a simple SHA256 might be more appropriate if just for tracking.
        // Or store a unique session ID (e.g., from JWT's jti claim if you add one)
        // For simplicity, let's hash the token with SHA256.
        const tokenHash = crypto.createHash('sha256').update(token).digest('hex');

        const sessionExpiresAt = new Date(Date.now() + ms(config.jwtExpiresIn)); // ms library can parse "4h"

        const newSession = await Session.create({
            user_id: user._id,
            token_hash: tokenHash, // Storing hash of JWT
            created_at: new Date(),
            expires_at: sessionExpiresAt,
            ip_address: ipAddress,
            user_agent: userAgent,
            is_active: true,
        });

        // Log audit event for successful login
        await logAuditEvent({
            userId: user._id,
            event_type: 'login',
            resource: 'session',
            action: 'create',
            status: 'success',
            ip_address: ipAddress,
            user_agent: userAgent,
            details: { session_id: newSession._id, user_agent: userAgent }
        });

        const userToReturn = user.toObject();
        delete userToReturn.credentials;
        // Populate role names for the response
        userToReturn.roles = roleNames;


        return {
            token,
            user: userToReturn,
            expiresIn: config.jwtExpiresIn, // e.g., "4h"
            message: 'Login successful.'
        };
    },

    registerStudent: async (registrationData, ipAddress, userAgent) => {
        const { fullName, email, password, mobileNumber } = registrationData;

        // --- Validations ---
        if (!fullName || !email || !password) {
            throw new ApiError(400, 'Full name, email, and password are required.');
        }
        if (password.length < 8) {
            throw new ApiError(400, 'Password must be at least 8 characters long.');
        }

        // --- Check for existing users ---
        const existingUser = await User.findOne({ email });
        let isReVerification = false;

        // Scenario 3: Existing verified/active user
        if (existingUser && existingUser.is_active && existingUser.email_verified) {
            throw new ApiError(409, `This email address (${email}) is already registered and verified/active.`);
        }

        // Check mobile number conflicts (only for different users)
        if (mobileNumber) {
            const existingMobileUser = await User.findOne({ mobile_number: mobileNumber });
            if (existingMobileUser && existingMobileUser._id.toString() !== existingUser?._id.toString()) {
                // Mobile belongs to a different user
                if (existingMobileUser.is_active && existingMobileUser.mobile_verified) {
                    // Scenario 4: Mobile belongs to another verified user
                    throw new ApiError(409, `This mobile number (${mobileNumber}) is already registered and verified by another account.`);
                }
                // Scenario 5: Mobile belongs to another unverified user
                console.log(`Warning: Mobile number ${mobileNumber} is associated with unverified user ${existingMobileUser.email}`);
            }
        }

        const studentRole = await Role.findOne({ name: ROLES.STUDENT });
        if (!studentRole) {
            throw new ApiError(500, 'Student role not configured. Please seed roles.');
        }

        // --- Prepare OTPs and Hashes ---
        const emailOtpPlain = DEFAULT_EMAIL_OTP;
        const emailOtpHash = await bcrypt.hash(emailOtpPlain, 10);
        const emailOtpExpires = new Date(Date.now() + OTP_EXPIRY_MINUTES * 60 * 1000);

        let mobileOtpHash = null;
        let mobileOtpExpires = null;
        if (mobileNumber) {
            const mobileOtpPlain = DEFAULT_MOBILE_OTP;
            mobileOtpHash = await bcrypt.hash(mobileOtpPlain, 10);
            mobileOtpExpires = new Date(Date.now() + OTP_EXPIRY_MINUTES * 60 * 1000);
        }

        let newUser;

        // Scenario 2: Existing unverified user - Update existing record
        if (existingUser && (!existingUser.is_active || !existingUser.email_verified)) {
            isReVerification = true;

            try {
                // Update existing user's details
                newUser = await User.findByIdAndUpdate(
                    existingUser._id,
                    {
                        full_name: fullName, // Update name
                        credentials: { password_hash: password }, // Will be hashed by pre-save hook
                        mobile_number: mobileNumber || undefined,
                        // Reset verification status
                        is_active: false,
                        status: 'pending_email_verification',
                        email_verified: false,
                        mobile_verified: false,
                        // Update OTPs
                        email_verification_token: emailOtpHash,
                        email_verification_expires: emailOtpExpires,
                        mobile_verification_code: mobileOtpHash,
                        mobile_verification_expires: mobileOtpExpires,
                        // Update role if needed
                        roles: [{
                            role_id: studentRole._id,
                            granted_at: new Date(),
                            granted_by: null,
                        }],
                        updated_at: new Date()
                    },
                    { new: true, runValidators: true }
                );
            } catch (error) {
                if (error.code === 11000) {
                    if (error.message.includes('mobile_number_1')) {
                        throw new ApiError(409, 'This mobile number is already registered by another account.');
                    }
                    throw new ApiError(409, 'A user with these details already exists.');
                }
                throw error;
            }
        }
        // Scenario 1: Completely new user
        else {
            try {
                newUser = await User.create({
                    full_name: fullName,
                    email,
                    credentials: { password_hash: password }, // Will be hashed by pre-save hook
                    mobile_number: mobileNumber || undefined,
                    roles: [{
                        role_id: studentRole._id,
                        granted_at: new Date(),
                        granted_by: null,
                    }],
                    is_active: false,
                    status: 'pending_email_verification',
                    email_verified: false,
                    mobile_verified: false,
                    email_verification_token: emailOtpHash,
                    email_verification_expires: emailOtpExpires,
                    mobile_verification_code: mobileOtpHash,
                    mobile_verification_expires: mobileOtpExpires,
                    created_by: null,
                });
            } catch (error) {
                if (error.code === 11000) {
                    if (error.message.includes('email_1')) {
                        throw new ApiError(409, 'This email address is already registered.');
                    } else if (error.message.includes('mobile_number_1')) {
                        throw new ApiError(409, 'This mobile number is already registered.');
                    }
                    throw new ApiError(409, 'A user with these details (email or mobile) already exists.');
                }
                throw error;
            }
        }

        // Send Verification Communications (Simulated with static OTPs)
        console.log(`SIMULATED EMAIL: Sending OTP to ${newUser.email}: ${emailOtpPlain}`);

        if (mobileNumber && mobileOtpHash) {
            console.log(`SIMULATED SMS: Sending OTP to ${newUser.mobile_number}: ${DEFAULT_MOBILE_OTP}`);
        }

        // Log OTP generation for re-verification scenario
        if (isReVerification) {
            console.log(`RE-VERIFICATION: New OTPs generated for user ${newUser._id}`);
        }

        // --- Audit Log ---
        await logAuditEvent({
            userId: newUser._id,
            event_type: isReVerification ? 're_registration' : 'registration',
            resource: 'users',
            resource_id: newUser._id,
            action: isReVerification ? 'student_re_register' : 'student_self_register',
            status: 'pending_verification',
            ip_address: ipAddress,
            user_agent: userAgent,
            details: {
                email: newUser.email,
                isReVerification: isReVerification
            }
        });

        // Prepare Response Message
        let message;
        if (isReVerification) {
            message = "Account found! We've sent new verification codes to your email";
            if (mobileNumber) {
                message += " and mobile number";
            }
            message += ". Please check and verify to activate your account.";
        } else {
            message = "Student account created successfully. Please check your email to verify your account.";
            if (mobileNumber) {
                message += " Also, check your mobile for the verification code.";
            }
        }

        return {
            message: message,
            responseData: {
                userId: newUser._id.toString(),
                email: newUser.email,
                isReVerification: isReVerification
            }
        };
    },

    verifyEmailOtp: async (email, otp, ipAddress, userAgent) => {
        if (!email || !otp) {
            throw new ApiError(400, 'Email and OTP are required.');
        }

        const user = await User.findOne({ email });
        if (!user) {
            // For security, don't reveal if email exists or not on OTP failure
            throw new ApiError(400, 'Invalid OTP or email.');
        }

        if (user.email_verified) {
            throw new ApiError(400, 'Email is already verified.');
        }

        if (!user.email_verification_token || !user.email_verification_expires) {
            throw new ApiError(400, 'No OTP found for this email or OTP already used/expired. Please request a new one.');
        }

        if (new Date() > user.email_verification_expires) {
            // Invalidate the expired OTP
            user.email_verification_token = undefined;
            user.email_verification_expires = undefined;
            await user.save();
            throw new ApiError(400, 'OTP has expired. Please request a new one.');
        }

        const isOtpMatch = await bcrypt.compare(otp, user.email_verification_token);
        if (!isOtpMatch) {
            // Note: You might want to implement attempt limits for OTPs too
            throw new ApiError(400, 'Invalid OTP or email.');
        }

        // OTP is correct and not expired
        user.email_verified = true;
        user.email_verification_token = undefined; // Invalidate OTP after use
        user.email_verification_expires = undefined;

        // Determine next status
        if (user.mobile_number && !user.mobile_verified) {
            user.status = 'pending_mobile_verification';
        } else {
            user.status = 'active';
            user.is_active = true; // Activate the user
        }
        await user.save();

        await logAuditEvent({
            userId: user._id,
            event_type: 'verification',
            resource: 'users',
            resource_id: user._id,
            action: 'verify_email_otp',
            status: 'success',
            ip_address: ipAddress,
            user_agent: userAgent,
            details: { email: user.email }
        });

        let message = 'Email verified successfully.';
        if (user.status === 'active') {
            message += ' Your account is now active.';
        } else if (user.status === 'pending_mobile_verification') {
            message += ' Please verify your mobile number next.';
        }

        return {
            message,
            is_active: user.is_active,
            status: user.status,
            // Optionally return user data for the client (e.g., to update UI state)
            // Ensure not to send sensitive data like password hashes
            user: {
                _id: user._id,
                email: user.email,
                full_name: user.full_name,
                is_active: user.is_active,
                status: user.status,
                email_verified: user.email_verified,
                mobile_verified: user.mobile_verified
            }
        };
    },

    verifyMobileOtp: async (identifier, otp, ipAddress, userAgent) => {
        // Identifier can be email or mobile number, assuming mobile is unique (sparse)
        if (!identifier || !otp) {
            throw new ApiError(400, 'Identifier (email or mobile) and OTP are required.');
        }

        // Try finding user by mobile first, then by email if mobile search fails or identifier isn't a typical mobile format
        let user = await User.findOne({ mobile_number: identifier });
        if (!user) {
            user = await User.findOne({ email: identifier });
        }

        if (!user) {
            throw new ApiError(400, 'Invalid OTP or identifier.');
        }

        if (!user.mobile_number) { // Should not happen if status is pending_mobile_verification
            throw new ApiError(400, 'No mobile number associated with this account for verification.');
        }

        if (user.mobile_verified) {
            throw new ApiError(400, 'Mobile number is already verified.');
        }

        if (!user.mobile_verification_code || !user.mobile_verification_expires) {
            throw new ApiError(400, 'No mobile OTP found for this account or OTP already used/expired. Please request a new one.');
        }

        if (new Date() > user.mobile_verification_expires) {
            user.mobile_verification_code = undefined;
            user.mobile_verification_expires = undefined;
            await user.save();
            throw new ApiError(400, 'Mobile OTP has expired. Please request a new one.');
        }

        const isOtpMatch = await bcrypt.compare(otp, user.mobile_verification_code);
        if (!isOtpMatch) {
            throw new ApiError(400, 'Invalid OTP or identifier.');
        }

        // OTP is correct
        user.mobile_verified = true;
        user.mobile_verification_code = undefined;
        user.mobile_verification_expires = undefined;

        // If email was also verified, or not required to be verified first for mobile-only flows
        if (user.email_verified || !user.email) { // Assuming email verification might not be a strict prerequisite for mobile if mobile is primary
            user.status = 'active';
            user.is_active = true;
        } else if (!user.email_verified && user.email) {
            // This case implies mobile verified but email still pending, which is unusual if email is primary.
            // Usually, email verification precedes mobile or happens in parallel.
            // For now, let's assume if mobile is verified and email was pending, we still need email.
            // Or, if mobile is primary, this step would activate.
            // Let's stick to: if email is verified or not present, and mobile is now verified -> active.
            // If email is present and NOT verified, status remains pending_email_verification.
            // This part needs to align with your exact desired user activation flow.
            // For simplicity, if email_verified is true OR there's no email to verify:
            user.status = 'active';
            user.is_active = true;
        }
        // If email is not verified and mobile is now verified, the status might still be pending_email_verification
        // unless your flow dictates mobile verification alone can activate.
        // Let's assume: verifying mobile makes user active IF email is already verified OR no email exists.
        // If email exists and is NOT verified, status remains 'pending_email_verification'.
        // This logic is clearer:
        if (user.email_verified || !user.email) { // If email is verified OR no email to verify
            user.status = 'active';
            user.is_active = true;
        } else {
            user.status = 'pending_email_verification'; // Still need to verify email
        }


        await user.save();

        await logAuditEvent({
            userId: user._id,
            event_type: 'verification',
            resource: 'users',
            resource_id: user._id,
            action: 'verify_mobile_otp',
            status: 'success',
            ip_address: ipAddress,
            user_agent: userAgent,
            details: { mobile: user.mobile_number }
        });

        let message = 'Mobile number verified successfully.';
        if (user.is_active) { // Check is_active instead of status === 'active' as status might change
            message += ' Your account is now active.';
        } else if (user.status === 'pending_email_verification') {
            message += ' Please verify your email address next.';
        }


        return {
            message,
            is_active: user.is_active,
            status: user.status,
            user: { // Return updated user state
                _id: user._id,
                email: user.email,
                full_name: user.full_name,
                is_active: user.is_active,
                status: user.status,
                email_verified: user.email_verified,
                mobile_verified: user.mobile_verified
            }
        };
    },


};
import ms from 'ms';