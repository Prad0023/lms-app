import { Router } from 'express';
// We'll import controllers and middlewares later

const router = Router();

// Placeholder route (we'll replace this with actual admin routes)
router.get('/', (req, res) => {
    res.send('Admin routes are working!');
});

export default router;