import Role from '../models/role.model.js';
import User from '../models/user.model.js';
import config from '../config/env.config.js'; // If using initial admin from .env
import { hashPassword } from '../utils/password.utils.js'; // For initial admin

export const ROLES = {
    ADMIN: 'admin',
    TEACHER: 'teacher',
    STUDENT: 'student',
    // Add more roles as needed
};

const initialRoles = [
    {
        name: ROLES.ADMIN,
        description: 'System Administrator with full access.',
        is_system_role: true,
        permissions: [
            // User Management
            { resource: 'user', action: 'create' },
            { resource: 'user', action: 'read_all' }, // specific for listing all users
            { resource: 'user', action: 'read_one' },
            { resource: 'user', action: 'update' },
            { resource: 'user', action: 'delete' },
            { resource: 'user', action: 'assign_role' },
            { resource: 'user', action: 'unlock_account' },
            // Role Management
            { resource: 'role', action: 'create' },
            { resource: 'role', action: 'read_all' },
            { resource: 'role', action: 'update' },
            { resource: 'role', action: 'delete' },
            // Course Management
            { resource: 'course', action: 'create' },
            { resource: 'course', action: 'read_all' },
            { resource: 'course', action: 'update' },
            { resource: 'course', action: 'delete' },
            { resource: 'course', action: 'assign_teacher' },
            { resource: 'course', action: 'enroll_student' },
            // Audit Logs
            { resource: 'audit_log', action: 'read_all' },
        ]
    },
    {
        name: ROLES.TEACHER,
        description: 'Teacher with access to manage their courses and students.',
        is_system_role: true,
        permissions: [
            { resource: 'course', action: 'read_assigned' }, // Read courses they teach
            { resource: 'course', action: 'update_assigned' }, // Update details of courses they teach
            { resource: 'student_progress', action: 'read_assigned_course' }, // View student progress in their courses
            { resource: 'submission', action: 'read_assigned_course' }, // View submissions for their courses
            // { resource: 'profile', action: 'update_own' }, // Update their own profile
        ]
    },
    {
        name: ROLES.STUDENT,
        description: 'Student with access to enrolled courses and materials.',
        is_system_role: true,
        permissions: [
            { resource: 'course', action: 'read_enrolled' }, // View courses they are enrolled in
            { resource: 'course_material', action: 'read_enrolled_course' },
            { resource: 'submission', action: 'create_own' }, // Submit assignments for their courses
            { resource: 'submission', action: 'read_own' },
            // { resource: 'profile', action: 'update_own' }, // Update their own profile
        ]
    }
];

export const seedRoles = async () => {
    try {
        for (const roleData of initialRoles) {
            const existingRole = await Role.findOne({ name: roleData.name });
            if (!existingRole) {
                await Role.create(roleData);
                console.log(`Role '${roleData.name}' seeded.`);
            }
        }
    } catch (error) {
        console.error('Error seeding roles:', error);
    }
};


// Optional: Seed initial Admin User (Maria) - as per Story 1 for Admin
// This is simplified. A proper CLI command or a one-time setup page is better for the first admin.
export const seedInitialAdmin = async () => {
    try {
        const adminRole = await Role.findOne({ name: ROLES.ADMIN });
        if (!adminRole) {
            console.error('Admin role not found. Seed roles first.');
            return;
        }

        // Check if an admin user already exists
        // A more robust check might look for any user with the admin role
        const existingAdmin = await User.findOne({ email: config.initialAdmin.email });
        if (existingAdmin) {
            console.log('Initial admin user already exists.');
            return;
        }

        if (config.initialAdmin && config.initialAdmin.email && config.initialAdmin.password) {
            const hashedPassword = await hashPassword(config.initialAdmin.password);

            const adminUser = await User.create({
                email: config.initialAdmin.email,
                full_name: config.initialAdmin.fullName || "Initial Admin",
                mobile_number: config.initialAdmin.mobileNumber,
                email_verified: true, // Assuming first admin is pre-verified
                mobile_verified: true,
                is_active: true,
                credentials: {
                    password_hash: hashedPassword, // Will be re-hashed by pre-save hook if passed as plain
                },
                roles: [{
                    role_id: adminRole._id,
                    granted_by: null, // System granted
                }]
            });
            console.log(`Initial admin user '${adminUser.email}' seeded successfully.`);
        } else {
            console.log('Initial admin credentials not found in .env. Skipping admin seed.');
        }

    } catch (error) {
        console.error('Error seeding initial admin:', error);
    }
};

export const seedInitialData = async () => {
    await seedRoles();
    // If you want to use the .env based admin seeding:
    // Make sure to define INITIAL_ADMIN_EMAIL etc. in your .env
    // if (config.initialAdmin?.email) {
    //     await seedInitialAdmin();
    // }
};