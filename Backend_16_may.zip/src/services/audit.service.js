// src/services/audit.service.js
import AuditLog from '../models/auditLog.model.js';
import mongoose from 'mongoose';

/**
 * Logs an audit event.
 * @param {object} eventData - The data for the audit event.
 * @param {string | mongoose.Types.ObjectId} eventData.userId - The ID of the user performing the action. Can be null for system events.
 * @param {string} eventData.event_type - Type of event (e.g., 'login', 'user_management').
 * @param {string} eventData.resource - The resource being affected (e.g., 'session', 'users').
 * @param {string} eventData.action - The action performed (e.g., 'create', 'update').
 * @param {string} [eventData.status='success'] - Status of the event ('success', 'failure').
 * @param {string} [eventData.ip_address] - IP address of the request.
 * @param {string} [eventData.user_agent] - User agent string from the request.
 * @param {object} [eventData.details={}] - Additional details about the event.
 * @param {string | mongoose.Types.ObjectId} [eventData.resource_id=null] - The ID of the affected resource, if any.
 */
export const logAuditEvent = async (eventData) => {
    try {
        const {
            userId,
            event_type,
            resource,
            action,
            status = 'success',
            ip_address,
            user_agent,
            details = {},
            resource_id = null
        } = eventData;

        if (!event_type || !resource || !action) {
            console.warn('Audit log attempt with missing critical data (event_type, resource, or action):', eventData);
            return;
        }

        await AuditLog.create({
            user_id: userId ? new mongoose.Types.ObjectId(userId) : null,
            event_time: new Date(),
            event_type,
            resource,
            resource_id: resource_id ? new mongoose.Types.ObjectId(resource_id) : null,
            action,
            status,
            ip_address,
            user_agent,
            details,
        });
        // console.log('Audit event logged:', event_type, action);
    } catch (error) {
        console.error('Failed to log audit event:', error.message, 'Event Data:', eventData);
        // Decide if this failure should propagate or just be logged and ignored
    }
};