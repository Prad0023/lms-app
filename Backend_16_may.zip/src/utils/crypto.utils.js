// src/utils/crypto.utils.js
import forge from 'node-forge';
import cryptoNode from 'crypto'; // Renamed to avoid conflict if 'crypto' is used as a var name
import fs from 'fs';
import config from '../config/env.config.js';
import { ApiError } from './apiResponse.utils.js';
import path from 'path';
const AES_ALGORITHM = 'aes-256-gcm';
const AES_KEY_BYTE_LENGTH = 32; // 256 bits
const IV_BYTE_LENGTH = 12;    // 96 bits for GCM
const AUTH_TAG_BYTE_LENGTH = 16; // 128 bits for GCM

let rsaPrivateKeyInstance;
let rsaPublicKeyPemContent;
let loadedPrivateKeyPem;
try {
    if (config.rsaPrivateKeyPath) {
        // Resolve the path relative to the project root if it's a relative path
        const absolutePrivateKeyPath = path.resolve(process.cwd(), config.rsaPrivateKeyPath);
        console.log('[CryptoUtils] Attempting to load Private Key from (absolute):', absolutePrivateKeyPath);
        if (fs.existsSync(absolutePrivateKeyPath)) {
            const pem = fs.readFileSync(absolutePrivateKeyPath, 'utf8');
            rsaPrivateKeyInstance = forge.pki.privateKeyFromPem(pem);
            console.log('[CryptoUtils] Private Key loaded successfully.');
        } else {
            console.error(`[CryptoUtils] FATAL: Private Key file NOT FOUND at: ${absolutePrivateKeyPath}`);
        }
    } else {
        console.error('[CryptoUtils] FATAL: RSA_PRIVATE_KEY_PATH is not configured.');
    }

    
    if (config.rsaPublicKeyPath) {
        const absolutePublicKeyPath = path.resolve(process.cwd(), config.rsaPublicKeyPath);
        console.log('[CryptoUtils] Attempting to load Public Key from (absolute):', absolutePublicKeyPath);
        if (fs.existsSync(absolutePublicKeyPath)) {
            rsaPublicKeyPemContent = fs.readFileSync(absolutePublicKeyPath, 'utf8');
            console.log('[CryptoUtils] Public Key loaded successfully.');
        } else {
            console.error(`[CryptoUtils] Public Key file NOT FOUND at: ${absolutePublicKeyPath}`);
        }
    } else {
        console.warn('[CryptoUtils] RSA_PUBLIC_KEY_PATH is not configured. Server cannot provide public key.');
    }
} catch (error) {
    console.error('[CryptoUtils] Error loading RSA keys during initialization:', error.message);
    if (error.stack) console.error(error.stack);
    rsaPrivateKeyInstance = null;
    rsaPublicKeyPemContent = null;
}

console.log('[CryptoUtils] rsaPublicKeyPemContent after load attempt:', rsaPublicKeyPemContent ? 'Loaded' : 'Not Loaded');


export const getServerRsaPublicKeyPem = () => {
    console.log('[CryptoUtils] getServerRsaPublicKeyPem called.');
    console.log('[CryptoUtils] Current rsaPublicKeyPemContent status:', rsaPublicKeyPemContent ? 'Available' : 'Unavailable');
    if (!rsaPublicKeyPemContent) {
        throw new ApiError(503, 'Server encryption service (public key) is currently unavailable.');
    }
    return rsaPublicKeyPemContent;
};

/**
 * Decrypts an RSA-OAEP encrypted AES key.
 * The client is expected to Base64 encode the AES key, then RSA encrypt that Base64 string.
 * @param {string} rsaEncryptedBase64AesKeyB64 - Base64 encoded, RSA encrypted (Base64 representation of the AES key).
 * @returns {Buffer} The decrypted AES key as a Buffer.
 */

// backend/src/utils/crypto.utils.js

export const decryptAesKeyWithRsa = (rsaEncryptedBase64AesKeyB64) => {
    console.log('[CryptoUtils] decryptAesKeyWithRsa called...');
    
    // Check if the private key instance is available
    if (!rsaPrivateKeyInstance) {
        throw new ApiError(500, 'Server RSA private key not loaded.');
    }
    
    try {
        // Convert the base64 encrypted key to binary
        const encryptedBytes = forge.util.decode64(rsaEncryptedBase64AesKeyB64);
        
        // Decrypt using forge's RSA-OAEP with SHA-256
        let decryptedBase64Key;
        try {
            // Try to decrypt with RSA-OAEP using SHA-256 for both the hash and MGF1 hash
            decryptedBase64Key = rsaPrivateKeyInstance.decrypt(encryptedBytes, 'RSA-OAEP', {
                md: forge.md.sha256.create(),
                mgf1: {
                    md: forge.md.sha256.create()
                }
            });
            console.log('[CryptoUtils] Successfully decrypted AES key using RSA-OAEP with SHA-256');
        } catch (e) {
            console.error('RSA Decryption of AES key failed. Error:', e.message);
            throw new Error(`Invalid RSAES-OAEP padding. ${e.message}`);
        }
        
        // Convert the decrypted Base64 string to an actual Buffer
        const aesKeyBuffer = Buffer.from(decryptedBase64Key, 'base64');
        
        // Validate key length
        if (aesKeyBuffer.length !== AES_KEY_BYTE_LENGTH) {
            throw new Error(`Decrypted AES key has incorrect length: ${aesKeyBuffer.length}. Expected ${AES_KEY_BYTE_LENGTH}.`);
        }
        
        console.log('[CryptoUtils] Successfully decrypted and converted AES key to Buffer');
        return aesKeyBuffer;
    } catch (error) {
        console.error('[CryptoUtils] decryptAesKeyWithRsa error:', error.message);
        throw new ApiError(400, `Failed to decrypt AES key: ${error.message}`);
    }
};

/**
 * Decrypts a payload using AES-256-GCM.
 * Expects input as Base64 string: IV (12 bytes) + Ciphertext + AuthTag (16 bytes).
 * @param {string} aesEncryptedPayloadB64 - Base64 encoded (IV + Ciphertext + AuthTag).
 * @param {Buffer} aesKeyBuffer - The 32-byte AES key.
 * @returns {object} The decrypted JSON object.
 */
export const decryptPayloadWithAesGcm = (aesEncryptedPayloadB64, aesKeyBuffer) => {
    try {
        const combinedBuffer = Buffer.from(aesEncryptedPayloadB64, 'base64');

        const iv = combinedBuffer.subarray(0, IV_BYTE_LENGTH);
        const authTag = combinedBuffer.subarray(combinedBuffer.length - AUTH_TAG_BYTE_LENGTH);
        const ciphertext = combinedBuffer.subarray(IV_BYTE_LENGTH, combinedBuffer.length - AUTH_TAG_BYTE_LENGTH);

        if (iv.length !== IV_BYTE_LENGTH) throw new Error('Invalid IV length.');
        if (authTag.length !== AUTH_TAG_BYTE_LENGTH) throw new Error('Invalid AuthTag length.');

        const decipher = cryptoNode.createDecipheriv(AES_ALGORITHM, aesKeyBuffer, iv);
        decipher.setAuthTag(authTag);

        let decryptedJsonString = decipher.update(ciphertext, null, 'utf8');
        decryptedJsonString += decipher.final('utf8');

        return JSON.parse(decryptedJsonString);
    } catch (error) {
        console.error('AES Payload Decryption failed:', error);
        if (error.message.includes('Unsupported state') || error.message.includes('authentication tag')) {
             throw new ApiError(400, 'AES payload decryption failed: authentication failed (tampered or incorrect key/IV).');
        }
        throw new ApiError(400, 'Failed to decrypt or parse AES payload.');
    }
};