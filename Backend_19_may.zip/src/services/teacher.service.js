// src/services/teacher.service.js
import crypto from 'crypto';
import User from '../models/user.model.js';
import mongoose from 'mongoose';
import Role from '../models/role.model.js';
import OnboardingToken from '../models/onboardingToken.model.js';
import { ApiError } from '../utils/apiResponse.utils.js';
import { logAuditEvent } from './audit.service.js';
import { ROLES } from './seed.service.js';
import { generateTemporaryPassword } from '../utils/password.utils.js';
import { sendTeacherOnboardingEmail } from './email.service.js'; // Ensure this is imported


const ONBOARDING_TOKEN_EXPIRY_HOURS = 24;

export const teacherService = {
    initiateTeacherHiring: async (hireRequestData, adminUserId, ipAddress, userAgent) => {
        const { teacherInfo, sendEmail } = hireRequestData;
        const { fullName, email, mobile, designation } = teacherInfo;

        if (!fullName || !email || !mobile || !designation) {
            throw new ApiError(400, 'Missing required fields in teacherInfo (fullName, email, mobile, designation).');
        }

        const existingUser = await User.findOne({ email });
        const teacherRole = await Role.findOne({ name: ROLES.TEACHER }); // ROLES.TEACHER is 'teacher'
        if (!teacherRole) {
            throw new ApiError(500, 'Teacher role not found. Please seed roles.');
        }

        if (existingUser) {
            // Check if existing user already has the teacher role and is active
            const hasActiveTeacherRole = existingUser.roles.some(
                r => r.role_id.toString() === teacherRole._id.toString()
            ) && existingUser.is_active;

            if (hasActiveTeacherRole || (existingUser.is_active && existingUser.status !== 'pending_setup')) {
                throw new ApiError(409, `User with email ${email} already exists as an active teacher or is an active user not pending setup.`);
            }
        }


        const tempPasswordDetails = generateTemporaryPassword();
        const adminObjectId = new mongoose.Types.ObjectId(adminUserId); // Ensure adminUserId is an ObjectId

        let newTeacher;
        let isReInitiation = false;

        const teacherRoleEntry = {
            role_id: teacherRole._id,
            granted_at: new Date(),
            granted_by: adminObjectId, // Admin is granting this role (even if pending)
            expires_at: null
        };

        if (existingUser && existingUser.status === 'pending_setup') {
            isReInitiation = true;
            existingUser.full_name = fullName;
            existingUser.mobile_number = mobile;
            existingUser.designation = designation;
            existingUser.credentials = { password_hash: tempPasswordDetails.plain };
            existingUser.status = 'pending_setup';
            existingUser.is_active = false;
            existingUser.email_verified = false;
            existingUser.mobile_verified = false;
            existingUser.updated_at = new Date();

            // Ensure the teacher role is present, remove duplicates if any then add
            existingUser.roles = existingUser.roles.filter(
                r => r.role_id.toString() !== teacherRole._id.toString()
            );
            existingUser.roles.push(teacherRoleEntry);

            newTeacher = await existingUser.save();
            await OnboardingToken.updateMany({ user_id: newTeacher._id, used: false }, { $set: { used: true, expires_at: new Date() } });
            console.log(`[TeacherService] Re-initiating setup for existing pending user: ${email} and assigning/confirming teacher role.`);
        } else {
            newTeacher = await User.create({
                full_name: fullName,
                email,
                mobile_number: mobile,
                designation,
                credentials: {
                    password_hash: tempPasswordDetails.plain,
                },
                status: 'pending_setup',
                created_by: adminObjectId,
                is_active: false, // Not active until they complete setup AND admin confirms
                email_verified: false,
                mobile_verified: false,
                roles: [teacherRoleEntry], // **** ASSIGN THE TEACHER ROLE HERE ****
            });
            console.log(`[TeacherService] Created new pending user: ${email} and assigned teacher role (inactive).`);
        }

        // ... (rest of the token generation, email sending, audit logging remains the same)
        const onboardingTokenPlain = crypto.randomBytes(32).toString('hex');
        const onboardingTokenHash = crypto.createHash('sha256').update(onboardingTokenPlain).digest('hex');
        const expiresAt = new Date(Date.now() + ONBOARDING_TOKEN_EXPIRY_HOURS * 60 * 60 * 1000);

        await OnboardingToken.create({
            user_id: newTeacher._id,
            token_hash: onboardingTokenHash,
            token_type: 'teacher_onboarding',
            expires_at: expiresAt,
        });

        let responseMessage = `Teacher '${fullName}' ${isReInitiation ? 're-initiated for setup' : 'added and marked for setup'}.`;

        if (sendEmail === true) {
            const frontendBaseUrl = process.env.FRONTEND_URL || 'http://localhost:4200';
            const completeProfileLink = `${frontendBaseUrl}/complete-teacher-profile?token=${onboardingTokenPlain}`;
            try {
                await sendTeacherOnboardingEmail(newTeacher.email, newTeacher.full_name, completeProfileLink, tempPasswordDetails.plain);
                responseMessage = `Teacher '${fullName}' ${isReInitiation ? 're-initiated for setup' : 'added'}. An onboarding email has been sent to ${email}.`;
            } catch (emailError) {
                console.error(`[TeacherService] Failed to send onboarding email for ${email}:`, emailError);
                responseMessage += " However, there was an issue sending the onboarding email.";
            }
        }

        await logAuditEvent({
            userId: adminObjectId,
            event_type: 'teacher_management',
            resource: 'users',
            resource_id: newTeacher._id,
            action: 'initiate_hire',
            status: 'success',
            ip_address: ipAddress,
            user_agent: userAgent,
            details: {
                teacher_email: email,
                designation,
                sendEmailInitiated: sendEmail === true,
                action_type: isReInitiation ? 're_initiate' : 'new_hire_initiate',
                assigned_role: ROLES.TEACHER // Log that teacher role was notionally assigned
            }
        });

        return {
            message: responseMessage,
            teacherId: newTeacher._id,
        };
    },

    getAllTeachers: async () => {
        const teacherRole = await Role.findOne({ name: ROLES.TEACHER });
        if (!teacherRole) {
            throw new ApiError(500, 'Teacher role not found. Cannot fetch teachers.');
        }

        // Now this query will find users with the teacher role,
        // but you might want to filter further by is_active or status in the controller or here
        const teachers = await User.find({ "roles.role_id": teacherRole._id })
            .select('-credentials -roles._id -roles.granted_at -roles.granted_by -roles.expires_at -oauth_accounts -email_verification_token -mobile_verification_code')
            .sort({ created_at: -1 });

        return teachers.map(teacher => {
            const teacherObj = teacher.toObject();
            // Optionally, add a field to indicate if they are fully active based on your logic
            // teacherObj.isFullyActive = teacherObj.is_active && teacherObj.status === 'active';
            return teacherObj;
        });
    },

    getAllTeachers: async () => {
        const teacherRole = await Role.findOne({ name: ROLES.TEACHER });
        if (!teacherRole) {
            throw new ApiError(500, 'Teacher role not found. Cannot fetch teachers.');
        }

        // Find users who have the teacher role
        // Exclude sensitive fields like credentials.
        // Populate designation or other relevant teacher-specific fields if needed.
        const teachers = await User.find({ "roles.role_id": teacherRole._id })
            .select('-credentials -roles._id -roles.granted_at -roles.granted_by -roles.expires_at -oauth_accounts -email_verification_token -mobile_verification_code') // Select fields
            .sort({ created_at: -1 }); // Sort by creation date, newest first

        // Transform to remove the roles array if it's just for filtering, or simplify it
        return teachers.map(teacher => {
            const teacherObj = teacher.toObject();
            // Optionally, simplify the roles array in the output or remove it
            // delete teacherObj.roles; // If roles array itself is not needed in response
            return teacherObj;
        });
    },
    // ... other service methods (completeTeacherProfile, confirmTeacherHiring)
};