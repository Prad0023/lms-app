import mongoose from 'mongoose';

const onboardingTokenSchema = new mongoose.Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
        index: true,
    },
    token_hash: { // Store hash of the token, not the token itself
        type: String,
        required: true,
        unique: true,
    },
    token_type: { // e.g., 'teacher_onboarding', 'email_verification'
        type: String,
        required: true,
        default: 'teacher_onboarding',
    },
    expires_at: {
        type: Date,
        required: true,
        index: { expires: '0s' } // TTL index for automatic deletion
    },
    used: {
        type: Boolean,
        default: false,
    }
}, { timestamps: true });

const OnboardingToken = mongoose.model('OnboardingToken', onboardingTokenSchema);
export default OnboardingToken;