import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../services/auth.service'; // Adjust path
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-admin-dashboard-page',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './admin-dashboard-page.component.html',
})
export class AdminDashboardPageComponent {
  constructor(public authService: AuthService) {}

  logout() {
    this.authService.logout();
  }
}