import { Component, ViewChild, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { Subscription } from 'rxjs';
import { AuthService } from '../../../services/auth.service'; // Adjust path
import { LoginFormComponent } from '../../../components/auth/login-form/login-form.component'; // Adjust path

@Component({
  selector: 'app-login-page',
  standalone: true,
  imports: [CommonModule, LoginFormComponent, RouterLink],
  templateUrl: './login-page.component.html',
})
export class LoginPageComponent implements OnDestroy {
  @ViewChild(LoginFormComponent) loginFormComponent!: LoginFormComponent;
  private loginSubscription?: Subscription;

  constructor(private authService: AuthService, private router: Router) {
    // If user is already logged in, redirect them
    if (this.authService.isLoggedIn()) {
      this.authService.navigateBasedOnRole();
    }
  }

  handleLogin(credentials: {username: string, password: string}): void {
    this.loginSubscription = this.authService.login(credentials.username, credentials.password)
      .subscribe({
        next: (user) => {
          console.log('Login successful, navigating by role...', user.role);
          this.loginFormComponent?.resetForm();
          this.authService.navigateBasedOnRole();
        },
        error: (err) => {
          console.error('Login failed:', err);
          this.loginFormComponent?.showError(err.message || 'Login failed. Please check your credentials.');
        }
      });
  }

  navigateToAdminRegister() {
    this.router.navigate(['/auth/admin-register']); // Assuming this route will exist
  }

  ngOnDestroy(): void {
    this.loginSubscription?.unsubscribe();
  }
}