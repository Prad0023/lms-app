// src/app/app.routes.ts
import { Routes } from '@angular/router';
import { authGuard } from './guards/auth.guard'; // Adjust path

export const routes: Routes = [
  // Public Landing Page
  {
    path: '',
    loadComponent: () =>
      import('./pages/landing-page/landing-page.component').then(
        (m) => m.LandingPageComponent
      ),
    title: 'Abhyasify - Home'
  },

  // Authentication Routes (e.g., /auth/login, /auth/register)
  {
    path: 'auth/login', // Direct path for login
    loadComponent: () =>
      import('./pages/auth/login-page/login-page.component').then(
        (m) => m.LoginPageComponent
      ),
    title: 'Login - Abhyasify'
  },
  // Add /auth/admin-register route here if you create it
  // {
  //   path: 'auth/admin-register',
  //   loadComponent: () => import('./pages/auth/admin-register-page/admin-register-page.component').then(m => m.AdminRegisterPageComponent),
  //   title: 'Admin Registration - Abhyasify'
  // },


  // --- Protected Routes ---
  {
    path: 'admin/dashboard',
    loadComponent: () =>
      import('./pages/admin/admin-dashboard-page/admin-dashboard-page.component').then(
        (m) => m.AdminDashboardPageComponent
      ),
    canActivate: [authGuard],
    data: { expectedRoles: ['Admin'] }, // Specify expected role(s)
    title: 'Admin Dashboard'
  },
  // Example for future student dashboard
  // {
  //   path: 'student/dashboard',
  //   loadComponent: () => import('./pages/student/student-dashboard-page/student-dashboard-page.component').then(m => m.StudentDashboardPageComponent),
  //   canActivate: [authGuard],
  //   data: { expectedRoles: ['Student'] },
  //   title: 'Student Dashboard'
  // },
  // Example for future teacher dashboard
  // {
  //   path: 'teacher/dashboard',
  //   loadComponent: () => import('./pages/teacher/teacher-dashboard-page/teacher-dashboard-page.component').then(m => m.TeacherDashboardPageComponent),
  //   canActivate: [authGuard],
  //   data: { expectedRoles: ['Teacher'] },
  //   title: 'Teacher Dashboard'
  // },

  // Wildcard route - should be last
  { path: '**', redirectTo: '', pathMatch: 'full' } // Or a dedicated NotFoundPageComponent
];