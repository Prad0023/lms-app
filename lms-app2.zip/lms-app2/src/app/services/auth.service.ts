// src/app/services/auth.service.ts
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, of, throwError, timer } from 'rxjs';
import { delay, map, tap } from 'rxjs/operators';

// Define user roles
export type UserRole = 'Admin' | 'Student' | 'Teacher' | null;

export interface User {
  id: string;
  username: string;
  role: UserRole;
  token?: string; // Simulated JWT
}

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private currentUserSubject = new BehaviorSubject<User | null>(this.getStoredUser());
  public currentUser$: Observable<User | null> = this.currentUserSubject.asObservable();

  private readonly USER_KEY = 'lms_current_user';

  constructor(private router: Router) {}

  public get currentUserValue(): User | null {
    return this.currentUserSubject.value;
  }

  isLoggedIn(): boolean {
    return !!this.currentUserValue;
  }

  getCurrentUserRole(): UserRole {
    return this.currentUserValue?.role || null;
  }

  private getStoredUser(): User | null {
    if (typeof localStorage !== 'undefined') {
      const user = localStorage.getItem(this.USER_KEY);
      return user ? JSON.parse(user) : null;
    }
    return null;
  }

  private storeUser(user: User): void {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(this.USER_KEY, JSON.stringify(user));
    }
    this.currentUserSubject.next(user);
  }

  private clearUser(): void {
    if (typeof localStorage !== 'undefined') {
      localStorage.removeItem(this.USER_KEY);
    }
    this.currentUserSubject.next(null);
  }

  // Simulated login
  login(username: string, password: string): Observable<User> {
    // Simulate API call delay
    return timer(1000).pipe(
      map(() => {
        // --- SIMULATED BACKEND LOGIC ---
        if (username === 'admin@example.com' && password === 'admin123') {
          const user: User = { id: '1', username: 'Admin User', role: 'Admin', token: 'fake-admin-jwt' };
          this.storeUser(user);
          return user;
        } else if (username === 'student@example.com' && password === 'student123') {
          const user: User = { id: '2', username: 'Student User', role: 'Student', token: 'fake-student-jwt' };
          this.storeUser(user);
          return user;
        } else if (username === 'teacher@example.com' && password === 'teacher123') {
          const user: User = { id: '3', username: 'Teacher User', role: 'Teacher', token: 'fake-teacher-jwt' };
          this.storeUser(user);
          return user;
        } else {
          throw new Error('Invalid credentials');
        }
        // --- END SIMULATED BACKEND LOGIC ---
      }),
      tap(user => console.log('Logged in user:', user)) // For debugging
    );
  }

  logout(): void {
    this.clearUser();
    this.router.navigate(['/auth/login']); // Or to landing page '/'
    console.log('User logged out');
  }

  // Helper to navigate after login based on role
  navigateBasedOnRole(): void {
    const role = this.getCurrentUserRole();
    switch (role) {
      case 'Admin':
        this.router.navigate(['/admin/dashboard']);
        break;
      case 'Student':
        this.router.navigate(['/student/dashboard']); // Assuming this route will exist
        break;
      case 'Teacher':
        this.router.navigate(['/teacher/dashboard']); // Assuming this route will exist
        break;
      default:
        this.router.navigate(['/']); // Fallback to landing page
        break;
    }
  }
}