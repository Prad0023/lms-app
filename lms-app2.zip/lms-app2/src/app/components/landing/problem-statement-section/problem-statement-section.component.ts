import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ScrollAnimationDirective } from '../../../directives/scroll-animation.directive'; // Ensure this path is correct

@Component({
  selector: 'app-problem-statement-section',
  standalone: true, // CRUCIAL
  imports: [CommonModule, ScrollAnimationDirective], // Import what this component needs
  templateUrl: './problem-statement-section.component.html',
})
export class ProblemStatementSectionComponent {}