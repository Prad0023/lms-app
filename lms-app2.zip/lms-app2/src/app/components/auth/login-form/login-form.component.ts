import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-login-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './login-form.component.html',
})
export class LoginFormComponent {
  @Output() loginSubmit = new EventEmitter<{username: string, password: string}>();
  @Output() navigateToRegister = new EventEmitter<void>(); // If you add admin registration later

  loginForm: FormGroup;
  isLoading = false;
  errorMessage: string | null = null;

  constructor(private fb: FormBuilder) {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  get username() { return this.loginForm.get('username'); }
  get password() { return this.loginForm.get('password'); }

  onSubmit(): void {
    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      return;
    }
    this.isLoading = true;
    this.errorMessage = null;
    // Emit credentials, let parent component (LoginPage) handle the authService call
    this.loginSubmit.emit(this.loginForm.value);
  }

  // Call this method from parent if login fails
  showError(message: string) {
    this.errorMessage = message;
    this.isLoading = false;
  }

  // Call this from parent on success or if form needs reset
  resetForm() {
    this.loginForm.reset();
    this.isLoading = false;
    this.errorMessage = null;
  }

  onRegisterClick() {
    this.navigateToRegister.emit();
  }
}