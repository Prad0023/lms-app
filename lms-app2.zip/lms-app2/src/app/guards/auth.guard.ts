// src/app/guards/auth.guard.ts
import { inject } from '@angular/core';
import { CanActivateFn, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService, UserRole } from '../services/auth.service'; // Adjust path

export const authGuard: CanActivateFn = (
  route: ActivatedRouteSnapshot,
  state: RouterStateSnapshot
) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  const expectedRoles = route.data?.['expectedRoles'] as Array<UserRole>; // Get expected roles from route data

  if (authService.isLoggedIn()) {
    const userRole = authService.getCurrentUserRole();
    if (expectedRoles && expectedRoles.length > 0) {
      if (userRole && expectedRoles.includes(userRole)) {
        return true; // User is logged in and has an expected role
      } else {
        console.warn(`Access denied for role: ${userRole}. Expected: ${expectedRoles.join(', ')}`);
        // Optionally redirect to an 'unauthorized' page or back to login/dashboard
        router.navigate(['/auth/login']); // Or a specific 'unauthorized' page
        return false;
      }
    }
    return true; // User is logged in, and no specific roles are expected for this route
  }

  // Not logged in, redirect to login page with the return url
  console.log('User not logged in, redirecting to login.');
  router.navigate(['/auth/login'], { queryParams: { returnUrl: state.url } });
  return false;
};