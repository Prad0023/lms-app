export interface NavigationItem {
  label: string;         // Text to display
  icon?: string;        // Icon class (e.g., from Font Awesome, Heroicons, or Tailwind UI SVG path)
  route?: string;       // Router link
  action?: () => void;  // For items that trigger an action (e.g., logout)
  roles?: string[];     // Roles that can see this item (e.g., ['admin'], ['teacher', 'admin'])
  children?: NavigationItem[]; // For nested/dropdown menus
  isSeparator?: boolean; // To add a visual separator
  isActive?: boolean;   // To indicate active link, can be set dynamically
}