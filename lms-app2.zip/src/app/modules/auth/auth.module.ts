import { NgModule } from '@angular/core'; // <<<< ADD THIS LINE
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { AuthRoutingModule } from './auth-routing.module';

// Import Standalone Page Components
import { LoginPageComponent } from './pages/login-page/login-page.component';
import { AdminRegisterPageComponent } from './pages/admin-register-page/admin-register-page.component';

// Import Standalone Form Components
import { LoginFormComponent } from './components/login-form/login-form.component';
import { AdminRegistrationFormComponent } from './components/admin-registration-form/admin-registration-form.component';

@NgModule({ // Now this decorator will be recognized
  declarations: [
    // If any of the components above are NOT standalone, declare them here.
    // For now, we assume they are all standalone as per previous discussions.
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    AuthRoutingModule,

    // Import standalone components that are routed to by AuthRoutingModule
    // or used by components within this module.
    LoginPageComponent,
    AdminRegisterPageComponent,
    LoginFormComponent,
    AdminRegistrationFormComponent
  ]
})
export class AuthModule { }