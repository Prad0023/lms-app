import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { AdminRegistrationFormComponent } from './admin-registration-form.component';
import { AuthService } from '../../../../core/services/auth.service'; // Adjust path

describe('AdminRegistrationFormComponent', () => {
  let component: AdminRegistrationFormComponent;
  let fixture: ComponentFixture<AdminRegistrationFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        HttpClientTestingModule,
        RouterTestingModule,
        AdminRegistrationFormComponent // Import the standalone component for testing
      ],
      // providers: [AuthService] // AuthService is providedIn: 'root'
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminRegistrationFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});