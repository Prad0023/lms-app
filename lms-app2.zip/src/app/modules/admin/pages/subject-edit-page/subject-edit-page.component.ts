import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormArray } from '@angular/forms';
import {
  Subject as RxJsSubject, // Aliased to avoid conflict
  Subscription,
  debounceTime,
  distinctUntilChanged,
  switchMap,
  map,                   // IMPORT map operator
  filter,                // filter is not directly used but good to have in mind
  tap,
  catchError,
  of,
  from,                  // IMPORT from operator
  startWith              // IMPORT startWith
} from 'rxjs';

import { AdminSubjectService } from '../../services/admin-subject.service';
// Make sure these interfaces are correctly defined and exported from their model files
import { SubjectDetailsBackend, SubjectUpdatePayload } from '../../models/subject.model';
import { MinimalCourseInfo } from '../../models/course.model';

@Component({
  selector: 'app-subject-edit-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './subject-edit-page.component.html',
})
export class SubjectEditPageComponent implements OnInit, OnDestroy {
  subjectId: string | null = null;
  subjectForm: FormGroup;
  currentSubject: SubjectDetailsBackend | null = null; // Stores raw backend data for original state
  isLoading = false;          // For main form save
  isFetchingDetails = true; // For initial load of subject
  errorMessage: string | null = null;

  courseSearchTerm$ = new RxJsSubject<string | null>(); // Subject for course search
  availableCoursesForSearch: MinimalCourseInfo[] = [];   // Filtered list for dropdown
  selectedCourses: MinimalCourseInfo[] = [];             // Courses currently assigned to subject (for chips)
  allSystemCourses: MinimalCourseInfo[] = [];            // Cache of all courses for lookup
  showCourseDropdown = false;
  isLoadingCourses = false;     // For loading courses in dropdown

  private subscriptions = new Subscription();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    private adminSubjectService: AdminSubjectService
  ) {
    this.subjectForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required],
      assignedCourseIds: this.fb.array([]) // Holds IDs of courses to be assigned
    });
  }

  ngOnInit(): void {
    // Fetch all courses once for lookups and dropdown population
    this.adminSubjectService.getCoursesForSelection().then(courses => {
      this.allSystemCourses = courses;
      // Now load subject details, as it might depend on allSystemCourses for mapping names
      const idParam = this.route.snapshot.paramMap.get('subjectId');
      if (idParam) {
        this.subjectId = idParam;
        this.loadSubjectDetails();
      } else {
        this.errorMessage = "Subject ID not found in route.";
        this.isFetchingDetails = false;
      }
    }).catch(err => {
      console.error("Failed to load initial course list for dropdowns:", err);
      this.errorMessage = "Could not load necessary course data for editing.";
      this.isFetchingDetails = false;
    });


    this.subscriptions.add(
      this.courseSearchTerm$.pipe(
        startWith(''), // Trigger initial population (or pass null if getCoursesForSelection handles null term)
        debounceTime(300),
        distinctUntilChanged(),
        tap(() => this.isLoadingCourses = true),
        // No need to call getCoursesForSelection repeatedly if we have allSystemCourses
        // We will filter allSystemCourses directly
        map((term: string | null) => { // term is the search string
          if (!term || term.trim() === '') {
            return this.allSystemCourses; // Show all if no search term
          }
          const lowerTerm = term.toLowerCase();
          return this.allSystemCourses.filter(c => c.name.toLowerCase().includes(lowerTerm));
        }),
        tap(() => this.isLoadingCourses = false)
      ).subscribe((filteredCourses: MinimalCourseInfo[]) => {
        // Further filter out already selected courses from the search results
        this.availableCoursesForSearch = filteredCourses.filter(
          (ac: MinimalCourseInfo) => !this.selectedCourses.find(sc => sc._id === ac._id)
        );
        // Manage dropdown visibility
        const courseSearchInputEl = document.getElementById('courseSearchEditInput') as HTMLInputElement;
        const currentSearchVal = courseSearchInputEl ? courseSearchInputEl.value : '';
        if (currentSearchVal && (this.availableCoursesForSearch.length > 0 || this.isLoadingCourses)) {
            this.showCourseDropdown = true;
        } else if (!currentSearchVal) {
             this.showCourseDropdown = false;
        } else if (currentSearchVal && this.availableCoursesForSearch.length === 0 && !this.isLoadingCourses) {
            this.showCourseDropdown = true; // Keep open to show "No results"
        }

      })
    );
  }

 async loadSubjectDetails(): Promise<void> {
  if (!this.subjectId) return;
  this.isFetchingDetails = true;
  try {
    // ... (fetch allSystemCourses) ...
    const subject = await this.adminSubjectService.getSubjectById(this.subjectId);
    if (subject) {
      this.currentSubject = subject;
      this.subjectForm.patchValue({ /* ... */ });

      this.selectedCourses = [];
      this.assignedCourseIdsFormArray.clear();

      // vvvvvv CORRECT PROPERTY NAME HERE vvvvvv
      if (subject.AssociatedCourses && Array.isArray(subject.AssociatedCourses)) {
        // Assuming subject.AssociatedCourses is string[] from backend for a Subject entity
        (subject.AssociatedCourses as string[]).forEach(courseId => {
      // ^^^^^^ CORRECT PROPERTY NAME HERE ^^^^^^
          const foundCourse = this.allSystemCourses.find(c => c._id === courseId);
          if (foundCourse) {
            this.selectedCourses.push(foundCourse);
            this.assignedCourseIdsFormArray.push(this.fb.control(courseId));
          } else {
            this.assignedCourseIdsFormArray.push(this.fb.control(courseId));
            this.selectedCourses.push({ _id: courseId, name: `Course ID: ${courseId} (Details N/A)`, description: '' });
          }
        });
      }
      // ...
    } else { /* ... */ }
  } catch (error: any) { /* ... */ }
  finally { /* ... */ }
}

  get f() { return this.subjectForm.controls; }
  get assignedCourseIdsFormArray() { return this.subjectForm.get('assignedCourseIds') as FormArray; }

  onCourseSearch(event: Event): void {
    const searchTerm = (event.target as HTMLInputElement).value;
    this.courseSearchTerm$.next(searchTerm);
  }

  selectCourse(course: MinimalCourseInfo, searchInput: HTMLInputElement): void {
    if (!this.selectedCourses.find(c => c._id === course._id)) {
      this.selectedCourses.push(course);
      this.assignedCourseIdsFormArray.push(this.fb.control(course._id));
      // Update availableCoursesForSearch after selection
      this.availableCoursesForSearch = this.availableCoursesForSearch.filter(ac => ac._id !== course._id);
    }
    searchInput.value = ''; // Clear search
    this.showCourseDropdown = false;
    // Optionally, re-trigger search with empty term to repopulate availableCoursesForSearch minus all selected
    // this.courseSearchTerm$.next(''); // This will show all unselected courses
  }

  removeSelectedCourse(courseToRemove: MinimalCourseInfo): void {
    this.selectedCourses = this.selectedCourses.filter(c => c._id !== courseToRemove._id);
    const index = this.assignedCourseIdsFormArray.controls.findIndex(control => control.value === courseToRemove._id);
    if (index > -1) {
      this.assignedCourseIdsFormArray.removeAt(index);
    }
    // Add back to available if it's not there. This requires checking against allSystemCourses & current search term
    // For simplicity, just re-triggering the current search term will refresh the available list correctly.
    this.courseSearchTerm$.next((document.getElementById('courseSearchEditInput') as HTMLInputElement)?.value || '');
  }

  async onSubmit(): Promise<void> {
    if (this.subjectForm.invalid || !this.subjectId) {
      this.subjectForm.markAllAsTouched();
      return;
    }
    this.isLoading = true;
    this.errorMessage = null;

    const formValue = this.subjectForm.value;
    const updatePayload: SubjectUpdatePayload = {
      name: formValue.name,
      description: formValue.description,
      assignedCourseIds: formValue.assignedCourseIds // Array of selected course IDs
    };

    try {
      const response = await this.adminSubjectService.updateSubject(this.subjectId, updatePayload);
      if (response.success) {
        alert(response.message || 'Subject updated successfully!');
        this.router.navigate(['/admin/subjects']); // Or back to subject detail: ['/admin/subjects', this.subjectId]
      } else {
        this.errorMessage = response.message || 'Failed to update subject.';
      }
    } catch (error: any) {
      this.errorMessage = error.message || 'An error occurred while updating the subject.';
      console.error("Error updating subject:", error);
    } finally {
      this.isLoading = false;
    }
  }

  onSearchFocus(): void {
    // If there's a search term or if the input is empty and we want to show all initial options
    const courseSearchInputEl = document.getElementById('courseSearchEditInput') as HTMLInputElement;
    if ((courseSearchInputEl && courseSearchInputEl.value) || this.availableCoursesForSearch.length > 0) {
        this.showCourseDropdown = true;
    }
  }
  onSearchBlur(): void {
    setTimeout(() => {
      // Check if the newly focused element is part of the dropdown list
      if (!document.activeElement?.closest('.subject-dropdown-list')) {
         this.showCourseDropdown = false;
      }
    }, 200); // Delay to allow click on dropdown item
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }
}