// src/app/modules/admin/pages/subject-detail-page/subject-detail-page.component.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';

import { AdminSubjectService } from '../../services/admin-subject.service';
import { MinimalCourseInfo } from '../../models/course.model'
import {
  SubjectDetailsBackend,  // From service, contains nested raw Modules/Topics
  SubjectDetailViewFE,    // Target for this.subjectViewData
  ModuleListItemFE,       // For this.subjectViewData.modules
  TopicListItemFE,        // For this.subjectViewData.modules[x].topics
  ModuleBasicInfo,        // Data from Add Module Modal
        // For displaying associated courses
  ModuleDetailsBackendNested, // Helper for mapping
  TopicDetailsBackendNested   // Helper for mapping
} from '../../models/subject.model';
// MinimalCourseInfo likely comes from course.model.ts
// import { MinimalCourseInfo } from '../../models/course.model';
import { SubjectModuleAddComponent } from '../../components/subject-module-add-modal/subject-module-add-modal.component';

@Component({
  selector: 'app-subject-detail-page',
  standalone: true,
  imports: [CommonModule, RouterModule, DatePipe, SubjectModuleAddComponent],
  templateUrl: './subject-detail-page.component.html',
})
export class SubjectDetailPageComponent implements OnInit {
  subjectId: string | null = null;
  subjectViewData: SubjectDetailViewFE | null = null; // Holds transformed data for view
  isLoading = true;
  isProcessingModuleAdd = false;
  errorMessage: string | null = null;
  isAddModuleModalOpen = false;
  allAvailableCourses: MinimalCourseInfo[] = []; // For passing to Add Module Modal for its course selection

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private adminSubjectService: AdminSubjectService
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.subjectId = params.get('id');
      if (this.subjectId) {
        this.loadSubjectData();
        // Fetch all courses once for context, e.g., for "Add Module" modal if it needs all courses
        this.adminSubjectService.getCoursesForSelection().then(courses => {
          this.allAvailableCourses = courses;
        }).catch(err => console.error("Failed to load all courses for context", err));
      } else {
        this.errorMessage = "Subject ID not found in route.";
        this.isLoading = false;
      }
    });
  }

  async loadSubjectData(): Promise<void> { // Renamed to reflect what it does
    if (!this.subjectId) return;
    this.isLoading = true;
    this.errorMessage = null;
    try {
      // This service call now returns SubjectDetailsBackend with nested Modules and Topics
      const subjectBackendData = await this.adminSubjectService.getSubjectDetailsWithNestedData(this.subjectId);

      if (subjectBackendData) {
        this.subjectViewData = this.mapBackendToViewData(subjectBackendData);
        console.log("SubjectDetailPage: Fully mapped subjectViewData for display:", this.subjectViewData);
      } else {
        this.errorMessage = `Subject with ID ${this.subjectId} not found.`;
      }
    } catch (error: any) {
      this.errorMessage = error.message || "Failed to load subject data.";
      console.error("Error in loadSubjectData:", error);
    } finally {
      this.isLoading = false;
    }
  }

  // Mapper function
  private mapBackendToViewData(backendData: SubjectDetailsBackend): SubjectDetailViewFE {
    const createdAt = backendData.CreatedAt && !isNaN(new Date(backendData.CreatedAt).getTime())
                      ? new Date(backendData.CreatedAt)
                      : new Date(0); // Default to epoch if invalid
    const updatedAt = backendData.UpdatedAt && !isNaN(new Date(backendData.UpdatedAt).getTime())
                      ? new Date(backendData.UpdatedAt)
                      : undefined;

    // AssociatedCourses from backend should be MinimalCourseInfo[] as per your log & model
    const associatedCoursesForView = (backendData.AssociatedCourses || []).map(ac => ({
        _id: ac._id,
        name: ac.name // Using CourseName as per your log for AssociatedCourses
    }));

    const modulesForView: ModuleListItemFE[] = (backendData.Modules || []).map(modBackend => ({
      _id: modBackend._id,
      moduleName: modBackend.ModuleName,
      moduleDescription: modBackend.ModuleDescription,
      topicCount: modBackend.Topics?.length || 0, // Get count from nested topics
      importance: undefined, // Placeholder for importance
      isTopicsVisible: false, // Default to collapsed
      topics: (modBackend.Topics || []).map(topicBackend => ({ // Map nested topics
        _id: topicBackend._id,
        topicName: topicBackend.TopicName,
      })),
      isLoadingTopics: false, // Topics are now embedded, so no individual loading state needed here
      sequenceOrder: modBackend.sequence_order
    }));

    return {
      _id: backendData._id,
      name: backendData.SubjectName,
      description: backendData.SubjectDescription || 'N/A',
      credits: backendData.SubjectCredits,
      subjectLevel: backendData.SubjectLevel,
      subjectType: backendData.SubjectType,
      createdAt: createdAt,
      updatedAt: updatedAt,
      createdByFullName: backendData.created_by?.full_name,
      isActive: backendData.is_active,
      associatedCourses: associatedCoursesForView,
      modules: modulesForView,
    };
  }

  // toggleTopics now only changes the UI state
  toggleTopics(moduleItem: ModuleListItemFE): void {
    moduleItem.isTopicsVisible = !moduleItem.isTopicsVisible;
    // No API call needed here if topics are already part of moduleItem.topics
  }

  openAddModuleModal(): void {
    if (!this.subjectViewData) {
        alert("Subject data is not loaded yet. Please wait.");
        return;
    }
    this.isAddModuleModalOpen = true;
  }

  closeAddModuleModal(): void {
    this.isAddModuleModalOpen = false;
  }

  async handleModuleAdded(moduleDataOrArray: ModuleBasicInfo | ModuleBasicInfo[]): Promise<void> {
    if (!this.subjectId) { /* ... existing error handling ... */ return; }
    this.isProcessingModuleAdd = true;
    // We don't close the modal until the operation is done or user cancels
    // The modal itself can set its internal isLoading for its button when it emits.
    // this.closeAddModuleModal(); // <<< MOVE THIS TO finally or after success

    try {
      let overallSuccess = true;
      let alertMessage = '';

      if (Array.isArray(moduleDataOrArray)) {
        if (moduleDataOrArray.length > 0) {
          const response = await this.adminSubjectService.addMultipleModulesToSubject(this.subjectId, moduleDataOrArray);
          overallSuccess = response.success;
          alertMessage = response.message;
          if(response.data?.errors && response.data.errors.length > 0){
            alertMessage += "\nDetails: " + response.data.errors.map(e => `${e.moduleNameAttempted}: ${e.error}`).join("\n");
          }
        } else {
          alertMessage = "No modules from file to add.";
          overallSuccess = true; // Not a failure, just nothing to do
        }
      } else {
        const response = await this.adminSubjectService.addModuleToSubject(this.subjectId, moduleDataOrArray);
        overallSuccess = response.success;
        alertMessage = response.message;
      }

      alert(alertMessage || "Processing complete.");
      if (overallSuccess) {
        await this.loadSubjectData(); // Refresh the entire subject detail, which includes modules
      }
    } catch (error: any) {
      alert("Error adding module(s): " + (error.message || "An unknown error occurred"));
    } finally {
      this.isProcessingModuleAdd = false;
      this.closeAddModuleModal(); // Close modal after operation finishes
    }
  }

  editSubject(): void {
     if(this.subjectId) this.router.navigate(['/admin/subjects', this.subjectId, 'edit']);
  }

  goBack(): void {
    this.router.navigate(['/admin/subjects']);
  }
}