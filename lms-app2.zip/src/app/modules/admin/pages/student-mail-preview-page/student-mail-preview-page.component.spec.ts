import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentMailPreviewPageComponent } from './student-mail-preview-page.component';

describe('StudentMailPreviewPageComponent', () => {
  let component: StudentMailPreviewPageComponent;
  let fixture: ComponentFixture<StudentMailPreviewPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StudentMailPreviewPageComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StudentMailPreviewPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
