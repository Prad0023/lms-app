// src/app/app.routes.ts
import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./modules/public/pages/landing-page/landing-page.component').then(
        (m) => m.LandingPageComponent
      ),
    title: 'Abhyasify - Home' // Optional: for browser tab title
  },
  
  
  { path: '**', redirectTo: '', pathMatch: 'full' } // Or a NotFoundPageComponent
];


  // Example other routes:
  // { path: 'courses', loadComponent: () => import('./pages/courses-page/courses-page.component').then(m => m.CoursesPageComponent) },
  // { path: 'blogs', loadComponent: () => import('./pages/blogs-page/blogs-page.component').then(m => m.BlogsPageComponent) },
  // { path: 'contact', loadComponent: () => import('./pages/contact-page/contact-page.component').then(m => m.ContactPageComponent) },

  // { path: 'auth', loadChildren: () => import('./modules/auth/auth.routes').then(m => m.AUTH_ROUTES) },
  // { path: 'admin', loadChildren: () => import('./modules/admin/admin.routes').then(m => m.ADMIN_ROUTES), canActivate: [() => inject(AuthGuard).canActivate(['Admin'])] },
  // { path: 'student', loadChildren: () => import('./modules/student/student.routes').then(m => m.STUDENT_ROUTES), canActivate: [() => inject(AuthGuard).canActivate(['Student'])] },
  // { path: 'teacher', loadChildren: () => import('./modules/teacher/teacher.routes').then(m => m.TEACHER_ROUTES), canActivate: [() => inject(AuthGuard).canActivate(['Teacher'])] },
