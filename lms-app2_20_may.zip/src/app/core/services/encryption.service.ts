import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environments';

@Injectable({
  providedIn: 'root'
})
export class EncryptionService {
  private importedRsaPublicKey: CryptoKey | null = null;

  constructor(private http: HttpClient) {}

  // --- Helper: String to ArrayBuffer ---
  private str2ab(str: string): ArrayBuffer {
    const buf = new ArrayBuffer(str.length);
    const bufView = new Uint8Array(buf);
    for (let i = 0, strLen = str.length; i < strLen; i++) {
      bufView[i] = str.charCodeAt(i);
    }
    return buf;
  }

  // --- Helper: ArrayBuffer to Base64 String ---
  private ab2b64(buf: ArrayBuffer): string {
    let binary = '';
    const bytes = new Uint8Array(buf);
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }

  // --- Helper: Base64 String to ArrayBuffer ---
 

  // --- 1. Fetch and Import Server's RSA Public Key ---
  private async importRsaSpkiPublicKey(pemKey: string): Promise<CryptoKey> {
    const pemHeader = "-----BEGIN PUBLIC KEY-----";
    const pemFooter = "-----END PUBLIC KEY-----";
    // Remove header, footer, and all whitespace (including newlines)
    const pemContents = pemKey
      .replace(pemHeader, "")
      .replace(pemFooter, "")
      .replace(/\s+/g, ""); // Crucial for base64 decoding

    const binaryDer = this.b642ab(pemContents); // Convert Base64 PEM content to ArrayBuffer

    return window.crypto.subtle.importKey(
      "spki", // SubjectPublicKeyInfo format (standard for PEM public keys)
      binaryDer,
      {
        name: "RSA-OAEP",
        hash: "SHA-256", // MUST match the server's RSA-OAEP hash
      },
      true, // Usually false for public keys, but JSEncrypt might operate differently. Let's try true.
      ["encrypt"]
    );
  }

  public async getRsaPublicKey(): Promise<CryptoKey> {
    if (this.importedRsaPublicKey) {
      return this.importedRsaPublicKey;
    }
    try {
      console.log(`Fetching RSA public key from ${environment.apiUrl}/auth/public-key ...`);
      const response = await firstValueFrom(
        this.http.get<{ success: boolean; data?: { publicKey: string }; message?: string }>(
          `${environment.apiUrl}/auth/public-key`
        )
      );

      if (response.success && response.data && response.data.publicKey) {
        console.log("Successfully fetched RSA public key PEM.");
        this.importedRsaPublicKey = await this.importRsaSpkiPublicKey(response.data.publicKey);
        return this.importedRsaPublicKey;
      } else {
        throw new Error(response.message || 'Public key not found in server response or response format unexpected.');
      }
    } catch (e: any) {
      console.error(`Failed to fetch or import server's public RSA key: ${e.message}`);
      throw e; // Re-throw to be caught by the calling function
    }
  }

  // --- 2. Generate AES Key ---
  public async generateAesGcmKey(): Promise<CryptoKey> {
    // Node script uses 32 bytes (256 bits) for AES-256-GCM
    return window.crypto.subtle.generateKey(
      {
        name: "AES-GCM",
        length: 256,
      },
      true, // Allow key to be exportable (to get its raw bytes for Base64 encoding)
      ["encrypt", "decrypt"] // "decrypt" isn't strictly needed for this flow but good practice
    );
  }

  // Helper to export the raw AES key and then Base64 encode it
  public async exportRawAesKeyAsBase64(aesKey: CryptoKey): Promise<string> {
    const rawKeyBuffer = await window.crypto.subtle.exportKey("raw", aesKey);
    return this.ab2b64(rawKeyBuffer);
  }

  // --- 3. RSA Encrypt the Base64 encoded AES Key ---
  // The Node script encrypts the *Base64 string* of the AES key.
  public async encryptAesKeyBase64WithRsa(
    aesKeyBase64: string, // The Base64 string of the AES key
    rsaPublicKey: CryptoKey
  ): Promise<string> { // Returns Base64 string of encrypted AES key
    const dataToEncryptBuffer = this.str2ab(aesKeyBase64); // Convert the Base64 string to ArrayBuffer
    const encryptedBuffer = await window.crypto.subtle.encrypt(
      {
        name: "RSA-OAEP",
        // No IV needed for RSA-OAEP directly in SubtleCrypto encrypt call
      },
      rsaPublicKey,
      dataToEncryptBuffer
    );
    return this.ab2b64(encryptedBuffer); // Base64 encode the encrypted result
  }

  

  // --- 4. AES-GCM Encrypt the Login Payload ---
  // Your Node script concatenates: IV (raw) + Ciphertext (raw) + AuthTag (raw), then Base64 encodes.
  public async encryptLoginPayloadAesGcm(
    payload: object, // e.g., { email: "...", password: "..." }
    aesKey: CryptoKey // The AES-GCM CryptoKey generated in step 2
  ): Promise<string> { // Returns the final Base64 encoded string (IV + Ciphertext + AuthTag)
    const iv = window.crypto.getRandomValues(new Uint8Array(12)); // 12-byte IV for GCM, as in Node script
    const payloadString = JSON.stringify(payload);
    const payloadBuffer = this.str2ab(payloadString); // Convert JSON string to ArrayBuffer

    // Encrypt
    // SubtleCrypto's AES-GCM encrypt returns an ArrayBuffer containing (Ciphertext + AuthTag)
    const encryptedDataAndTagBuffer = await window.crypto.subtle.encrypt(
      {
        name: "AES-GCM",
        iv: iv, // Pass the IV here
        // tagLength: 128, // Optional, default is 128 bits (16 bytes). Node default is also 16 bytes.
      },
      aesKey,
      payloadBuffer
    );

    // Concatenate: IV (raw bytes) + (Ciphertext + AuthTag) (raw bytes)
    const combinedBuffer = new Uint8Array(iv.byteLength + encryptedDataAndTagBuffer.byteLength);
    combinedBuffer.set(iv, 0); // Place IV at the beginning
    combinedBuffer.set(new Uint8Array(encryptedDataAndTagBuffer), iv.byteLength); // Place (Ciphertext + AuthTag) after IV

    return this.ab2b64(combinedBuffer.buffer); // Base64 encode the entire combined buffer
  }
private b642ab(b64: string): ArrayBuffer {
    const binary_string = window.atob(b64);
    const len = binary_string.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binary_string.charCodeAt(i);
    }
    return bytes.buffer;
  }

  public async decryptAesGcmPayload(
    encryptedPayloadBase64: string, // IV + Ciphertext + AuthTag, Base64 encoded
    aesKeyBase64: string            // Base64 of the raw AES key
  ): Promise<string> { // Returns the decrypted JSON string
    try {
      console.log("EncryptionService: Decrypting with AES key (first 10b64):", aesKeyBase64.substring(0,10)+"...");
      const aesKeyBuffer = this.b642ab(aesKeyBase64);
      const aesKey = await window.crypto.subtle.importKey(
        "raw",
        aesKeyBuffer,
        { name: "AES-GCM", length: 256 }, // Ensure length matches encryption
        false, // Key is not extractable after import for decryption
        ["decrypt"]
      );

      const combinedBufferWithIv = this.b642ab(encryptedPayloadBase64);
      console.log("EncryptionService: Combined (IV+Ciphertext+Tag) buffer length:", combinedBufferWithIv.byteLength);


      // IMPORTANT: Ensure IV length matches what was used during encryption (typically 12 bytes for GCM)
      const ivLength = 12;
      if (combinedBufferWithIv.byteLength < ivLength) {
          throw new Error("Encrypted payload is too short to contain an IV.");
      }

      const iv = combinedBufferWithIv.slice(0, ivLength);
      const ciphertextAndTag = combinedBufferWithIv.slice(ivLength);
      console.log("EncryptionService: Extracted IV length:", iv.byteLength, "Ciphertext+Tag length:", ciphertextAndTag.byteLength);


      if (ciphertextAndTag.byteLength === 0) {
          // This can happen if the original payload was empty and only IV was sent,
          // or if slicing was incorrect. An empty ciphertext might be valid for AES-GCM (decrypts to empty)
          // but if it's unexpected, it's good to log.
          console.warn("EncryptionService: Ciphertext + AuthTag part is empty after slicing IV.");
      }


      const decryptedBuffer = await window.crypto.subtle.decrypt(
        {
          name: "AES-GCM",
          iv: iv, // The extracted IV
          // tagLength: 128, // Optional: if non-default tag length was used by server
        },
        aesKey, // The imported AES CryptoKey
        ciphertextAndTag // The buffer containing ciphertext + auth tag
      );

      return new TextDecoder().decode(decryptedBuffer);
    } catch (error) {
      console.error("EncryptionService: AES-GCM Decryption failed:", error);
      // More specific error handling can be added here (e.g., for TagMismatchError)
      throw new Error("Payload decryption failed. Check console for AES-GCM errors.");
    }
  }

  
  
}