import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
// import { TeacherBasicInfo } from '../../models/teacher-management-page/teacher-management-page.component';
import { TeacherBasicInfo } from '../../models/teacher.model'
@Component({
  selector: 'app-teacher-hire-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './teacher-hire-modal.component.html',
  styleUrls: ['./teacher-hire-modal.component.css']
})
export class TeacherHireModalComponent {
  @Output() closeModal = new EventEmitter<void>();
  @Output() teacherHired = new EventEmitter<TeacherBasicInfo>();

  hireForm: FormGroup;
  isLoading = false;

  constructor(private fb: FormBuilder) {
    this.hireForm = this.fb.group({
      fullName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', [Validators.required, Validators.pattern(/^\+[1-9]\d{1,14}$/)]],
      designation: ['', Validators.required]
    });
    console.log("TeacherHireModalComponent: Initialized");
  }

  get f() { return this.hireForm.controls; }

  onSubmit(): void {
    console.log("TeacherHireModalComponent: onSubmit called."); // <<< DEBUG
    if (this.hireForm.invalid) {
      console.log("TeacherHireModalComponent: Form is invalid."); // <<< DEBUG
      this.hireForm.markAllAsTouched();
      return;
    }

    console.log("TeacherHireModalComponent: Form is valid. Setting isLoading = true."); // <<< DEBUG
    this.isLoading = true;
    const formData: TeacherBasicInfo = this.hireForm.value;
    console.log("TeacherHireModalComponent: Form data:", formData); // <<< DEBUG

    // Simulate API call delay - in a real app, this would be an actual service call
    setTimeout(() => {
      console.log("TeacherHireModalComponent: Emitting teacherHired event with data:", formData); // <<< DEBUG
      this.teacherHired.emit(formData);
      this.isLoading = false; // Set isLoading to false AFTER emitting
      console.log("TeacherHireModalComponent: isLoading set to false after emit."); // <<< DEBUG
      // The parent (TeacherManagementPageComponent) is responsible for closing the modal
      // by setting its 'isHireModalOpen' to false, which it does in handleTeacherHired.
    }, 1000); // Simulating a 1-second delay
  }

  onCancel(): void {
    console.log("TeacherHireModalComponent: onCancel called, emitting closeModal."); // <<< DEBUG
    this.closeModal.emit();
  }
}