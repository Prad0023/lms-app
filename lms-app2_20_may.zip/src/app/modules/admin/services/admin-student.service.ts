import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { firstValueFrom, Observable, throwError } from 'rxjs'; // No 'of' needed if we remove pure mocks
import { catchError, tap } from 'rxjs/operators';
import { environment } from '../../../../environments/environments';
import { EncryptionService } from '../../../core/services/encryption.service';
import { AuthService } from '../../../core/services/auth.service';
// Import interfaces from student.model.ts
import {
  StudentDetailsBackend,
  FetchStudentsApiResponse, // Matches your GET /view-students response
  StudentBasicEnrollInfo,  // Used within StudentEnrollmentInitiationPayload
  // EncryptedListPayload  // This is now part of FetchStudentsApiResponse.data
} from '../models/student.model';

// Interfaces specific to the actions in this service
export interface StudentEnrollmentInitiationPayload { // This is what your /initiate-enrollment backend expects (unencrypted)
  studentInfo: StudentBasicEnrollInfo;
  sendInviteEmail: boolean;
  onboardingLink?: string; // Frontend generates this currently, backend might ignore/replace
}

export interface EncryptedStudentRequest { // This is what /initiate-enrollment receives (encrypted)
  encryptedAesKeyB64: string;
  encryptedPayloadB64: string;
}

export interface StudentEnrollmentResponse { // Expected response from /initiate-enrollment
  success: boolean;
  message: string;
  data?: any;
  statusCode?: number; // Often backends include this too
}


@Injectable({
  providedIn: 'root'
})
export class AdminStudentService {
  // Corrected base apiUrl to point to the root for student admin actions
  private baseAdminStudentsUrl = `${environment.apiUrl}/admin/students`;

  constructor(
    private http: HttpClient,
    private encryptionService: EncryptionService,
    private authService: AuthService
  ) {}

  // --- Admin Initiates Student Enrollment ---
  async initiateStudentEnrollment(payload: StudentEnrollmentInitiationPayload): Promise<StudentEnrollmentResponse> {
    const enrollEndpoint = `${this.baseAdminStudentsUrl}/initiate-enrollment`; // Corrected endpoint
    console.log(`AdminStudentService: Initiating enrollment for ${payload.studentInfo.email} via ${enrollEndpoint}`);

    // The onboardingLink is generated client-side for now, backend might generate its own
    if (!payload.onboardingLink) { // If not already set by a preview step
        payload.onboardingLink = `https://our-lms.com/student-onboarding?token=${Date.now()}-${payload.studentInfo.email.split('@')[0]}`;
    }

    try {
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      const rsaEncryptedAesKeyB64 = await this.encryptionService.encryptAesKeyBase64WithRsa(
        aesKeyBase64ForRsa,
        rsaPublicKeyCryptoKey
      );
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(
        payload, // The StudentEnrollmentInitiationPayload object
        aesCryptoKey
      );
      const encryptedRequest: EncryptedStudentRequest = {
        encryptedAesKeyB64: rsaEncryptedAesKeyB64,
        encryptedPayloadB64: aesEncryptedPayloadB64
      };

      const adminToken = this.authService.token;
      if (!adminToken) {
        throw new Error("Admin authentication token not found. Please log in again.");
      }
      const headers = {
        'Authorization': `Bearer ${adminToken}`,
        'Content-Type': 'application/json' // Ensure content type for POST
      };

      console.log("AdminStudentService: Sending encrypted enrollment request:", encryptedRequest);
      // ACTUAL API CALL (will 404 or error if backend isn't ready, or succeed if it is)
      return await firstValueFrom(
        this.http.post<StudentEnrollmentResponse>(enrollEndpoint, encryptedRequest, { headers })
          .pipe(
            tap(res => console.log("AdminStudentService: Response from initiate-enrollment:", res)),
            catchError(this.handleHttpError) // Centralized HTTP error handling
          )
      );
    } catch (error) { // Catches errors from encryption or if token not found
      console.error("Error in initiateStudentEnrollment service (pre-HTTP call or during):", error);
      const err = error as Error;
      return Promise.reject({ // Ensure a consistent rejection structure
        success: false,
        message: err.message || 'Failed to initiate student enrollment due to a client-side error.',
        statusCode: 0 // Or some other indicator of client-side failure
      } as StudentEnrollmentResponse ); // Cast to expected error type
    }
  }

  // --- Admin Views All Students ---
  async getStudents(filters?: { searchTerm?: string; status?: string }): Promise<StudentDetailsBackend[]> {
    const viewStudentsEndpoint = `${this.baseAdminStudentsUrl}/view-students`; // Corrected endpoint
    console.log(`AdminStudentService: Fetching students from ${viewStudentsEndpoint} with filters:`, filters);

    let httpParams = new HttpParams();
    if (filters?.searchTerm) {
      httpParams = httpParams.set('search', filters.searchTerm);
    }
    if (filters?.status) {
      // Assuming your backend filter param for student status is 'enrollment_status'
      // If it's just 'status', change this line accordingly.
      httpParams = httpParams.set('enrollment_status', filters.status);
    }

    try {
      const adminToken = this.authService.token;
      if (!adminToken) {
        throw new Error("Admin authentication token not found. Please log in again.");
      }
      const headers = { 'Authorization': `Bearer ${adminToken}` };

      // ACTUAL API CALL
      const apiResponse = await firstValueFrom(
        this.http.get<FetchStudentsApiResponse>(viewStudentsEndpoint, { params: httpParams, headers: headers })
          .pipe(
            tap(res => console.log("AdminStudentService: Raw response from /view-students:", res)),
            catchError(this.handleHttpError)
          )
      );

      console.log("AdminStudentService: Received API response from /view-students:", apiResponse);

      if (apiResponse.success && apiResponse.data) {
        const { responseAesKeyB64, encryptedData } = apiResponse.data;
        console.log("AdminStudentService: Attempting to decrypt student list...");
        const decryptedJsonString = await this.encryptionService.decryptAesGcmPayload(
          encryptedData,
          responseAesKeyB64
        );
        const studentsFromBackend: StudentDetailsBackend[] = JSON.parse(decryptedJsonString);
        console.log("AdminStudentService: Decrypted students:", studentsFromBackend.length);
        return studentsFromBackend;
      } else {
        throw new Error(apiResponse.message || "Failed to fetch students: Server indicated failure or no data.");
      }
    } catch (error: any) {
      console.error("AdminStudentService: Error in getStudents:", error);
      const err = error as Error; // or HttpErrorResponse
      // Check if it's an HttpErrorResponse and use its message if available
      let errorMessage = "Could not fetch or decrypt student data.";
      if (error instanceof HttpErrorResponse && error.error && error.error.message) {
          errorMessage = error.error.message;
      } else if (error.message) {
          errorMessage = error.message;
      }
      throw new Error(errorMessage);
    }
  }

  // Centralized HTTP error handler for this service
  private handleHttpError(error: HttpErrorResponse): Observable<never> {
    console.error('AdminStudentService HTTP Error:', error);
    let userMessage = 'An unexpected error occurred with the student service.';
    if (error.error && error.error.message) {
      userMessage = error.error.message;
    } else if (error.message) {
      userMessage = error.message;
    }
    // For a POST request, the backend might send a structured error in StudentEnrollmentResponse format
    // For a GET, it might be FetchStudentsApiResponse, or a simpler error structure.
    // This generic throw works, but UI might need to inspect the actual error type.
    return throwError(() => ({
        success: false,
        message: userMessage,
        statusCode: error.status,
        error: error.error // include original error if needed by caller
    }));
  }

  // getAuthHeaders method can be removed if logic is inlined or token check is done before each call
}