import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { HttpClient, HttpErrorResponse } from '@angular/common/http'; // Import HttpErrorResponse
import { firstValueFrom, catchError, tap, throwError, Observable } from 'rxjs'; // Import more from rxjs

import { TeacherBasicInfo } from '../../models/teacher.model';
import { EncryptionService } from '../../../../core/services/encryption.service';
import { environment } from '../../../../../environments/environments';
import { AuthService } from '../../../../core/services/auth.service'; // To get admin token

// Interfaces (can be here or imported)
export interface TeacherOnboardingInitiationPayload {
  teacherInfo: TeacherBasicInfo;
  onboardingLink: string;
  mailSubject?: string;
  mailBody?: string;
  sendEmail: boolean;
}

export interface EncryptedOnboardingRequest {
  encryptedAesKeyB64: string;
  encryptedPayloadB64: string;
}

// Dummy success response from backend for this action
export interface OnboardingInitiationResponse {
  success: boolean;
  message: string;
  data?: any; // Optional data from backend
}


@Component({
  selector: 'app-teacher-mail-preview-page',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './teacher-mail-preview-page.component.html',
})
export class TeacherMailPreviewPageComponent implements OnInit {
  teacherData: TeacherBasicInfo | null = null;
  mailSubject = '';
  mailBody = '';
  simulatedOnboardingLink = '';
  isLoading = false;

  private onboardingEndpoint = `${environment.apiUrl}/admin/teachers/initiate-hire`;


  constructor(
    private router: Router,
    private encryptionService: EncryptionService,
    private http: HttpClient,
    private authService: AuthService // Inject AuthService to get the admin's token
  ) {}

  ngOnInit(): void {
    const navigationState = history.state;
    if (navigationState && navigationState.teacherData) {
      this.teacherData = navigationState.teacherData as TeacherBasicInfo;
      this.generateMailContent();
    } else {
      console.error('TeacherMailPreviewPageComponent: Teacher data not found. Navigating back.');
      this.router.navigate(['/admin/teachers']);
    }
  }

  private generateMailContent(): void {
    // ... (same as before)
    if (!this.teacherData) return;
    this.simulatedOnboardingLink = `https://our-lms.com/teacher-onboarding?token=${Date.now()}-${this.teacherData.email.split('@')[0]}`;
    this.mailSubject = `Invitation to Join Abhyasify LMS as a Teacher`;
    this.mailBody = `
Dear ${this.teacherData.fullName},
We are pleased to invite you to complete your onboarding process for the ${this.teacherData.designation} position at Abhyasify LMS.
Please click on the link below to complete your profile and set up your account:
${this.simulatedOnboardingLink}
This link is unique to you and should not be shared.
If you have any questions, please don't hesitate to contact us.
Best regards,
The Abhyasify Admin Team`;
  }

  onCancel(): void {
    if (this.isLoading) return; // Prevent cancelling during processing
    console.log('Mail preview cancelled.');
    this.router.navigate(['/admin/teachers']);
  }

  async onSendMail(): Promise<void> {
    if (!this.teacherData || this.isLoading) return;
    this.isLoading = true;
    console.log(`Processing "Send Mail" for ${this.teacherData.email}`);
    const payload: TeacherOnboardingInitiationPayload = {
      teacherInfo: this.teacherData,
      onboardingLink: this.simulatedOnboardingLink,
      mailSubject: this.mailSubject,
      mailBody: this.mailBody,
      sendEmail: true
    };
    await this.processOnboardingRequest(payload);
    // isLoading is set to false inside processOnboardingRequest's finally block
  }

  async onMarkForReview(): Promise<void> {
    if (!this.teacherData || this.isLoading) return;
    this.isLoading = true;
    console.log(`Processing "Mark for Review" for ${this.teacherData.fullName}`);
    const payload: TeacherOnboardingInitiationPayload = {
      teacherInfo: this.teacherData,
      onboardingLink: this.simulatedOnboardingLink,
      sendEmail: false
    };
    await this.processOnboardingRequest(payload);
    // isLoading is set to false inside processOnboardingRequest's finally block
  }

  private async processOnboardingRequest(payload: TeacherOnboardingInitiationPayload): Promise<void> {
    this.isLoading = true; // Ensure it's true at the start of processing
    try {
      console.log("Preparing to encrypt payload:", payload);

      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      const rsaEncryptedAesKeyBase64 = await this.encryptionService.encryptAesKeyBase64WithRsa(
        aesKeyBase64ForRsa,
        rsaPublicKeyCryptoKey
      );
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(
        payload,
        aesCryptoKey
      );

      const encryptedRequest: EncryptedOnboardingRequest = {
        encryptedAesKeyB64: rsaEncryptedAesKeyBase64,
        encryptedPayloadB64: aesEncryptedPayloadB64
      };

      console.log("Actual REQUEST TO BACKEND (Encrypted):");
      console.log("URL: POST " + this.onboardingEndpoint);
      console.log("Body:", JSON.stringify(encryptedRequest, null, 2));

      // Get the admin's auth token to send in headers
      const adminToken = this.authService.token;
      if (!adminToken) {
        throw new Error("Admin authentication token not found. Please log in again.");
      }

      const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${adminToken}`
      };

      // Make the ACTUAL HTTP POST request
      const response = await firstValueFrom(
        this.http.post<OnboardingInitiationResponse>(this.onboardingEndpoint, encryptedRequest, { headers: headers }).pipe(
          tap(res => {
            console.log("Backend response from teacher onboarding initiation:", res);
            if (res.success) {
              alert(res.message || (payload.sendEmail ? 'Teacher onboarding initiated and email (simulated) sent!' : 'Teacher marked for review successfully!'));
              this.router.navigate(['/admin/teachers']);
            } else {
              // Backend indicated failure, but HTTP was successful
              alert(`Operation failed: ${res.message || 'Unknown error from server.'}`);
            }
          }),
          catchError((err: HttpErrorResponse) => {
            console.error("HTTP Error during teacher onboarding initiation:", err);
            alert(`Error: ${err.error?.message || err.message || 'Failed to process request.'}`);
            return throwError(() => err); // Re-throw to be caught by outer try/catch
          })
        )
      );
      // 'response' variable here will hold the result if the promise resolved
      // Further actions based on 'response' can be done here if needed.

    } catch (error: any) {
      console.error("Error during onboarding request processing (outer catch):", error.message, error);
      // Alert the user based on the error caught
      if (error instanceof HttpErrorResponse) {
         alert(`API Error: ${error.error?.message || error.message || 'A server error occurred.'}`);
      } else {
         alert(`An error occurred: ${error.message || 'Please try again.'}`);
      }
    } finally {
        this.isLoading = false; // <<< ENSURE isLoading is reset in all cases
        console.log("processOnboardingRequest finished, isLoading set to false.");
    }
  }
}