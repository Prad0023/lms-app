import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService, AdminRegistrationPayload, AuthResponse } from '../../../../core/services/auth.service'; // Adjusted path
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-admin-registration-form',
  standalone: true, // Make it a standalone component
  imports: [
    CommonModule,
    ReactiveFormsModule // For [(ngModel)] and form directives
  ],
  templateUrl: './admin-registration-form.component.html',
  // styleUrls: ['./admin-registration-form.component.css'] // Optional: if you have specific styles
})
export class AdminRegistrationFormComponent {
  registerForm: FormGroup;
  isLoading = false;
  errorMessage: string | null = null;
  successMessage: string | null = null;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.registerForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      mobile_number: ['', [Validators.required, Validators.pattern(/^\+[1-9]\d{1,14}$/)]], // E.164 format
      full_name: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(8)]],
    });
  }

  onSubmit(): void {
    if (this.registerForm.invalid) {
      this.markAllAsTouched();
      return;
    }

    this.isLoading = true;
    this.errorMessage = null;
    this.successMessage = null;
    const payload: AdminRegistrationPayload = this.registerForm.value;

    this.authService.registerFirstAdmin(payload).subscribe({
      next: (response: AuthResponse) => { // <<<< Type the response
        this.isLoading = false;
        if (response.success) {
          this.successMessage = response.message + " Please login.";
          this.registerForm.reset();
          setTimeout(() => this.router.navigate(['/auth/login']), 2000);
        } else {
          this.errorMessage = response.message;
        }
      },
      error: (err: HttpErrorResponse | Error) => { // <<<< Type the error (can be HttpErrorResponse or a generic Error)
        this.isLoading = false;
        // Try to access a specific error message from HttpErrorResponse if possible
        this.errorMessage = (err instanceof HttpErrorResponse && err.error?.message)
                            ? err.error.message
                            : err.message || 'An unexpected error occurred during registration.';
        console.error(err);
      }
    });
  }

  private markAllAsTouched(): void {
    Object.values(this.registerForm.controls).forEach(control => {
      control.markAsTouched();
    });
  }
}