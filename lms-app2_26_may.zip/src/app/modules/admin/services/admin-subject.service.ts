// src/app/modules/admin/services/admin-subject.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { firstValueFrom, Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { environment } from '../../../../environments/environments';
import { EncryptionService } from '../../../core/services/encryption.service';
import { AuthService } from '../../../core/services/auth.service';
import {
  SubjectDetailsBackend,
  FetchSubjectsApiResponse, // Used for list and potentially adapted for single GET if backend structure is same
  SubjectBasicInfo,
  EncryptedSubjectRequest, // Generic for sending encrypted Subject data
  SubjectMutationResponse, // For add/update responses
  SubjectUpdatePayload   // For the update operation
} from '../models/subject.model';
import {
  MinimalCourseInfo,
  FetchCoursesApiResponse, // Reusing this for fetching courses list
  CourseDetailsBackend as FullCourseDetailsBackend // For raw course data
} from '../models/course.model';
import {
  ModuleBasicInfo, ModuleListItemFE, // New for module handling
  SubjectDetailViewFE // Could be constructed in component instead of service
} from '../models/subject.model';
import {CourseDetailsBackend  } from '../models/course.model';





@Injectable({
  providedIn: 'root'
})
export class AdminSubjectService {
  private baseApiUrl = `${environment.apiUrl}/admin/subjects`;
  private coursesApiUrl = `${environment.apiUrl}/admin/courses`; // For fetching courses list

  constructor(
    private http: HttpClient,
    private encryptionService: EncryptionService,
    private authService: AuthService
  ) {}

  private getAuthHeaders() {
    const token = this.authService.token;
    if (!token) {
      console.error(`${this.constructor.name}: Admin token not found for API call.`);
      throw new Error("Authentication token is missing. Please log in again.");
    }
    return {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json' // Usually for POST/PUT/PATCH
    };
  }

  private handleHttpError(error: HttpErrorResponse, context: string = 'operation'): Observable<never> {
    console.error(`AdminSubjectService HTTP Error during ${context}:`, error.status, error.message, error.error);
    let userMessage = `An unexpected error occurred during ${context}.`;

    if (error.error && typeof error.error === 'object' && error.error.message) {
      userMessage = error.error.message;
    } else if (typeof error.error === 'string' && error.error.length > 0 && error.error.length < 300) {
        userMessage = error.error;
    } else if (error.message) {
      userMessage = `Error ${error.status}: ${error.statusText || 'Server communication error'}`;
    }

    return throwError(() => ({
        success: false,
        message: userMessage,
        statusCode: error.status,
        errorDetail: error.error
    }));
  }

  // --- Add New Subject ---
  async addSubject(subjectPayloadToEncrypt: SubjectBasicInfo): Promise<SubjectMutationResponse> {
    const addSubjectEndpoint = `${this.baseApiUrl}/create`;
    console.log(`AdminSubjectService: Adding new subject via ${addSubjectEndpoint}`, subjectPayloadToEncrypt);

    try {
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      const rsaEncryptedAesKeyB64 = await this.encryptionService.encryptAesKeyBase64WithRsa(aesKeyBase64ForRsa, rsaPublicKeyCryptoKey);
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(subjectPayloadToEncrypt, aesCryptoKey);
      const encryptedRequest: EncryptedSubjectRequest = { encryptedAesKeyB64: rsaEncryptedAesKeyB64, encryptedPayloadB64: aesEncryptedPayloadB64 };
      const headers = this.getAuthHeaders();

      return await firstValueFrom(
        this.http.post<SubjectMutationResponse>(addSubjectEndpoint, encryptedRequest, { headers })
          .pipe(
            tap(res => console.log("AdminSubjectService: Response from add subject API:", res)),
            catchError(err => this.handleHttpError(err, 'add subject'))
          )
      );
    } catch (error) {
      console.error("Error in AdminSubjectService.addSubject (client-side or encryption):", error);
      const err = error as Error;
      // Re-throw or return a consistent error structure
      return Promise.reject({
        success: false, message: err.message || 'Client-side error adding subject.',
        statusCode: 0 // Indicate client-side failure
      } as SubjectMutationResponse);
    }
  }

  // --- Fetch All Subjects ---
  async getSubjects(filters?: { searchTerm?: string }): Promise<SubjectDetailsBackend[]> {
    const viewSubjectsEndpoint = `${this.baseApiUrl}/view-subjects`;
    console.log(`AdminSubjectService: Fetching subjects from ${viewSubjectsEndpoint} with filters:`, filters);
    let httpParams = new HttpParams();
    if (filters?.searchTerm) httpParams = httpParams.set('search', filters.searchTerm);

    try {
      const headers = this.getAuthHeaders();
      // Replace with actual API call when backend is ready
      const apiResponse = await firstValueFrom(
        this.http.get<FetchSubjectsApiResponse>(viewSubjectsEndpoint, { params: httpParams, headers })
          .pipe(catchError(err => this.handleHttpError(err, 'fetch subjects list')))
      );
      // const apiResponse = await this.simulateFetchSubjectsApi(filters); // Using simulation

      console.log("AdminSubjectService: Received API response from /view-subjects:", apiResponse);

      if (apiResponse && apiResponse.success && apiResponse.data) {
        const { responseAesKeyB64, encryptedData } = apiResponse.data;
        const decryptedJsonString = await this.encryptionService.decryptAesGcmPayload(encryptedData, responseAesKeyB64);
        const subjectsFromBackend: SubjectDetailsBackend[] = JSON.parse(decryptedJsonString);
        return subjectsFromBackend;
      } else {
        throw new Error(apiResponse?.message || "Failed to fetch subjects: Server indicated failure or no data.");
      }
    } catch (error: any) {
      console.error("AdminSubjectService: Error in getSubjects:", error);
      const message = (error instanceof HttpErrorResponse && error.error?.message) || error.message || "Could not fetch or decrypt subjects.";
      throw new Error(message);
    }
  }

  // --- Fetch Single Subject by ID (for editing) ---
  async getSubjectById(subjectId: string): Promise<SubjectDetailsBackend | null> {
    const subjectDetailEndpoint = `${this.baseApiUrl}/${subjectId}`;
    console.log(`AdminSubjectService: Fetching subject details for ID: ${subjectId}`);

    try {
      const headers = this.getAuthHeaders();
      // Replace with actual API call
      const apiResponse = await firstValueFrom(
        this.http.get<FetchSubjectsApiResponse>(subjectDetailEndpoint, { headers }) // Assuming single subject GET uses similar response wrapper
          .pipe(catchError(err => this.handleHttpError(err, `fetch subject ${subjectId}`)))
      );
      // const apiResponse = await this.simulateFetchSubjectByIdApi(subjectId); // Simulation

      if (apiResponse && apiResponse.success && apiResponse.data) {
        const { responseAesKeyB64, encryptedData } = apiResponse.data;
        const decryptedJsonString = await this.encryptionService.decryptAesGcmPayload(encryptedData, responseAesKeyB64);
        const subject: SubjectDetailsBackend = JSON.parse(decryptedJsonString); // Assumes encryptedData decrypts to a single object
        return subject;
      } else if (apiResponse && apiResponse.statusCode === 404) {
        return null;
      } else {
        throw new Error(apiResponse?.message || "Failed to fetch subject details.");
      }
    } catch (error: any) {
      console.error(`AdminSubjectService: Error in getSubjectById for ID ${subjectId}:`, error);
      if ((error as any).statusCode === 404 || error.message?.toLowerCase().includes('not found')) return null;
      const message = (error instanceof HttpErrorResponse && error.error?.message) || error.message || "Could not fetch/decrypt subject.";
      throw new Error(message);
    }
  }

  // --- Update Subject ---
  async updateSubject(subjectId: string, payload: SubjectUpdatePayload): Promise<SubjectMutationResponse> {
    const updateSubjectEndpoint = `${this.baseApiUrl}/update/${subjectId}`;
    console.log(`AdminSubjectService: Updating subject ID ${subjectId}:`, payload);

    try {
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      const rsaEncryptedValue = await this.encryptionService.encryptAesKeyBase64WithRsa(
        aesKeyBase64ForRsa,
        rsaPublicKeyCryptoKey
      );
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(
        payload, // This is SubjectBasicInfo or SubjectUpdatePayload
        aesCryptoKey
      );
      const encryptedRequest: EncryptedSubjectRequest = {
        encryptedAesKeyB64: rsaEncryptedValue, // Use the INTERFACE property name as the key
        encryptedPayloadB64: aesEncryptedPayloadB64
      };
      const headers = this.getAuthHeaders();

      // Replace with actual API call
      // return await firstValueFrom(
      //   this.http.put<SubjectMutationResponse>(updateSubjectEndpoint, encryptedRequest, { headers })
      //     .pipe(catchError(err => this.handleHttpError(err, `update subject ${subjectId}`)))
      // );
      // Simulation:
      console.log("AdminSubjectService: Sending encrypted update subject request:", encryptedRequest);
      await new Promise(resolve => setTimeout(resolve, 1000));
      // Construct a plausible backend-like subject detail from the update payload
      const updatedSubjectData: Partial<SubjectDetailsBackend> = {
          _id: subjectId,
          SubjectName: payload.name,
          SubjectDescription: payload.description,
          AssociatedCourses: payload.assignedCourseIds, // Assuming Courses in backend is string[] for IDs
          updated_at: new Date().toISOString(),
          // Other fields like created_at, etc., would typically come from backend record
      };
      return { success: true, message: "Subject updated successfully (simulated).", data: updatedSubjectData as SubjectDetailsBackend };


    } catch (error) {
      console.error("Error in AdminSubjectService.updateSubject (client-side or encryption):", error);
      const err = error as Error;
      return Promise.reject({
          success: false, message: err.message || 'Client-side error updating subject.',
          statusCode: 0
      } as SubjectMutationResponse);
    }
  }


  // --- Fetch Courses for Dropdown (in Add/Edit Subject Modals/Pages) ---
  async getCoursesForSelection(): Promise<MinimalCourseInfo[]> {
    const viewCoursesEndpoint = `${this.coursesApiUrl}/view-courses`;
    console.log(`AdminSubjectService: Fetching courses for selection from ${viewCoursesEndpoint}`);
    try {
      const headers = this.getAuthHeaders();
      // Replace with actual API call
      const apiResponse = await firstValueFrom(
        this.http.get<FetchCoursesApiResponse>(viewCoursesEndpoint, { headers })
          .pipe(catchError(err => this.handleHttpError(err, 'fetch courses for selection')))
      );
      // const apiResponse = await this.simulateFetchCoursesForDropdownApi(); // Simulation

      if (apiResponse.success && apiResponse.data) {
        const { responseAesKeyB64, encryptedData } = apiResponse.data;
        const decryptedJsonString = await this.encryptionService.decryptAesGcmPayload(encryptedData, responseAesKeyB64);
        const fullCourses: FullCourseDetailsBackend[] = JSON.parse(decryptedJsonString);
        return fullCourses.map(course => ({
          _id: course._id,
          name: course.CourseName // Ensure FullCourseDetailsBackend has CourseName
        }));
      } else {
        throw new Error(apiResponse.message || "Failed to fetch courses for selection.");
      }
    } catch (error: any) {
      console.error("AdminSubjectService: Error fetching courses for selection:", error);
      const message = (error instanceof HttpErrorResponse && error.error?.message) || error.message || "Could not fetch courses.";
      throw new Error(message);
    }
  }

  // --- SIMULATION METHODS (to be removed or replaced) ---
  private async simulateFetchSubjectsApi(filters?: { searchTerm?: string }): Promise<FetchSubjectsApiResponse> {
    console.log("AdminSubjectService: SIMULATING API call to /view-subjects", filters);
    await new Promise(resolve => setTimeout(resolve, 500));
    const mockData: SubjectDetailsBackend[] = this.getMockSubjectsData(filters);
    const tempAesKey = await this.encryptionService.generateAesGcmKey();
    const responseAesKeyB64 = await this.encryptionService.exportRawAesKeyAsBase64(tempAesKey);
    const encryptedData = await this.encryptionService.encryptLoginPayloadAesGcm(mockData, tempAesKey);
    return { success: true, statusCode: 200, data: { responseAesKeyB64, encryptedData }, message: "Simulated subjects fetch success."};
  }

  private getMockSubjectsData(filters?: { searchTerm?: string }): SubjectDetailsBackend[] {
    let subjects: SubjectDetailsBackend[] = [
      { _id: 'subj001', SubjectName: 'Algebra Fundamentals', SubjectDescription: 'Core concepts of algebra.', AssociatedCourses: ['c001', 'c003'], created_at: "2023-01-15T10:00:00Z", updated_at: "2023-01-16T11:00:00Z" },
      { _id: 'subj002', SubjectName: 'Newtonian Physics', SubjectDescription: 'Motion, forces, and energy.', AssociatedCourses: ['c002'], created_at: "2023-02-10T10:00:00Z", updated_at: "2023-02-11T11:00:00Z" },
      { _id: 'subj003', SubjectName: 'Introduction to Programming', SubjectDescription: 'Basics of coding with Python.', AssociatedCourses: [], created_at: "2023-03-05T10:00:00Z", updated_at: "2023-03-06T11:00:00Z" }
    ];
    if (filters?.searchTerm) {
      const term = filters.searchTerm.toLowerCase();
      subjects = subjects.filter(s => s.SubjectName.toLowerCase().includes(term) || s.SubjectDescription.toLowerCase().includes(term));
    }
    return subjects;
  }

  private async simulateFetchSubjectByIdApi(subjectId: string): Promise<FetchSubjectsApiResponse> { // Still returns list-like wrapper for simulation simplicity
      console.log(`AdminSubjectService: SIMULATING API call to /view/${subjectId} for subject`);
      await new Promise(resolve => setTimeout(resolve, 400));
      const mockSubjects = this.getMockSubjectsData({});
      const foundSubject = mockSubjects.find(s => s._id === subjectId);

      if (!foundSubject) {
          return { success: false, statusCode: 404, data: undefined, message: `Simulated: Subject with ID ${subjectId} not found.` };
      }
      const tempAesKey = await this.encryptionService.generateAesGcmKey();
      const responseAesKeyB64 = await this.encryptionService.exportRawAesKeyAsBase64(tempAesKey);
      const encryptedData = await this.encryptionService.encryptLoginPayloadAesGcm(foundSubject, tempAesKey); // Encrypt single object

      return {
          success: true,
          statusCode: 200,
          data: { responseAesKeyB64: responseAesKeyB64, encryptedData: encryptedData },
          message: "Subject details retrieved and encrypted (simulated)."
      };
  }

  private async simulateFetchCoursesForDropdownApi(): Promise<FetchCoursesApiResponse> {
    console.log("AdminSubjectService: SIMULATING API call to fetch courses for dropdown");
    await new Promise(resolve => setTimeout(resolve, 500));
    const mockRawCoursesList: FullCourseDetailsBackend[] = [
        // { _id: 'c001', CourseName: 'Introduction to Algebra', CourseDescription: 'Desc1', created_at: "2023-01-01", updated_at: "2023-01-01", is_published: true, subjects: [{id:"subj_math", name:"Mathematics"}], email_verified:true, mobile_verified:true, is_active:true, roles:[] },
        // { _id: 'c002', CourseName: 'Classical Mechanics', CourseDescription: 'Desc2', created_at: "2023-01-01", updated_at: "2023-01-01", is_published: false, subjects: [{id:"subj_physics", name:"Physics"}], email_verified:true, mobile_verified:true, is_active:true, roles:[] },
        // { _id: 'c003', CourseName: 'Web Development Basics', CourseDescription: 'Desc3', created_at: "2023-01-01", updated_at: "2023-01-01", is_published: true, subjects: [{id:"subj_cs", name:"Computer Science"}], email_verified:true, mobile_verified:true, is_active:true, roles:[] },
        // { _id: 'c004', CourseName: 'Organic Chemistry', CourseDescription: 'Desc4', created_at: "2023-01-01", updated_at: "2023-01-01", is_published: true, subjects: [{id:"subj_chem", name:"Chemistry"}], email_verified:true, mobile_verified:true, is_active:true, roles:[] },

    ];
    const tempAesKey = await this.encryptionService.generateAesGcmKey();
    const responseAesKeyB64 = await this.encryptionService.exportRawAesKeyAsBase64(tempAesKey);
    const encryptedData = await this.encryptionService.encryptLoginPayloadAesGcm(mockRawCoursesList, tempAesKey);
    return { success: true, statusCode: 200, data: { responseAesKeyB64, encryptedData }, message: "Simulated courses for dropdown fetch success."};
  }

  async getSubjectDetailsForView(subjectId: string): Promise<SubjectDetailsBackend | null> { // Renamed for clarity
    // This would fetch the Subject AND potentially its associated module stubs or course names directly
    // For now, it reuses getSubjectById simulation logic.
    // Backend for /view/:subjectId might need to populate 'AssociatedCourses' with { _id, CourseName }
    // and potentially 'SubjectModules' with { _id, ModuleName, (topic_count if available) }
    console.log(`AdminSubjectService: Fetching DETAILED subject view for ID: ${subjectId}`);
    return this.getSubjectById(subjectId); // Re-use existing for now, backend needs to be rich
  }

  async getModulesForSubject(subjectId: string): Promise<ModuleListItemFE[]> {
    // SIMULATED: This would be GET /api/v1/admin/subjects/:subjectId/modules or /api/v1/admin/modules?subjectId=...
    // The backend would query its 'modules' collection.
    console.log(`AdminSubjectService: SIMULATING fetch modules for subjectId: ${subjectId}`);
    await new Promise(resolve => setTimeout(resolve, 300));
    // Mock data - this data should ideally include topicCount from backend if possible
    const mockModules: ModuleListItemFE[] = [
      { _id: `mod_${subjectId}_1`, moduleName: `Module 1 for ${subjectId}`, moduleDescription: "Introductory concepts", topicCount: Math.floor(Math.random() * 5) + 1, importance: "High" },
      { _id: `mod_${subjectId}_2`, moduleName: `Module 2 for ${subjectId}`, moduleDescription: "Advanced topics", topicCount: Math.floor(Math.random() * 8) + 2, importance: "Medium" },
      { _id: `mod_${subjectId}_3`, moduleName: `Module 3 (Optional) for ${subjectId}`, topicCount: Math.floor(Math.random() * 3), importance: "Low" },
    ];
    return mockModules;
  }

  async addModuleToSubject(subjectId: string, moduleData: ModuleBasicInfo): Promise<SubjectMutationResponse> { // Re-using SubjectMutationResponse for simplicity
    // SIMULATED: POST /api/v1/admin/subjects/:subjectId/modules or /api/v1/admin/modules
    // Backend creates Module, links to SubjectID, creates initial Topics, links Module to ReqForCourses.
    const addModuleEndpoint = `${this.baseApiUrl}/${subjectId}/modules/create`; // Example
    console.log(`AdminSubjectService: SIMULATING add module to subject ${subjectId}`, moduleData, `via ${addModuleEndpoint}`);

    try {
      // Full encryption flow would be here for 'moduleData'
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      const rsaEncryptedAesKeyB64 = await this.encryptionService.encryptAesKeyBase64WithRsa(aesKeyBase64ForRsa, rsaPublicKeyCryptoKey);
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(moduleData, aesCryptoKey);
      const encryptedRequest = { encryptedAesKeyB64: rsaEncryptedAesKeyB64, encryptedPayloadB64: aesEncryptedPayloadB64 };
      const headers = this.getAuthHeaders();

      console.log("AdminSubjectService: SIMULATED encrypted request for add module:", encryptedRequest);
      await new Promise(resolve => setTimeout(resolve, 1000));
      return {
        success: true,
        message: `Module "${moduleData.moduleName}" (simulated) added to subject ${subjectId}.`,
        // Backend might return the created module details
        data: { _id: 'new_module_id', SubjectName: '', SubjectDescription: '', ...moduleData } as any, // Cast for simulation
        statusCode: 201
      };
    } catch (error) {
       console.error("Error in AdminSubjectService.addModuleToSubject:", error);
      const err = error as Error;
      return Promise.reject({
        success: false, message: err.message || 'Client-side error adding module.',
        statusCode: 0
      } as SubjectMutationResponse);
    }
  }

  

}