import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-settings-page',
  imports: [],
  templateUrl: './admin-settings-page.component.html',
  styleUrl: './admin-settings-page.component.css'
})
export class AdminSettingsPageComponent {

}
