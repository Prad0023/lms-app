import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeacherMailPreviewPageComponent } from './teacher-mail-preview-page.component';

describe('TeacherMailPreviewPageComponent', () => {
  let component: TeacherMailPreviewPageComponent;
  let fixture: ComponentFixture<TeacherMailPreviewPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TeacherMailPreviewPageComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TeacherMailPreviewPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
