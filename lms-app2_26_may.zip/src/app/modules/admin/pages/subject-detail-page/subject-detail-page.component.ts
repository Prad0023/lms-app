import { Component, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { switchMap, tap, map } from 'rxjs/operators';
import { Observable, of, forkJoin, from } from 'rxjs';

import { AdminSubjectService } from '../../services/admin-subject.service';
import { SubjectDetailsBackend, SubjectDetailViewFE, ModuleListItemFE, ModuleBasicInfo } from '../../models/subject.model';
import { MinimalCourseInfo } from '../../models/course.model'; // For displaying associated course names
import { SubjectModuleAddComponent } from '../../components/subject-module-add-modal/subject-module-add-modal.component'; // We will create this

@Component({
  selector: 'app-subject-detail-page',
  standalone: true,
  imports: [CommonModule, RouterModule, DatePipe, SubjectModuleAddComponent],
  templateUrl: './subject-detail-page.component.html',
  // styleUrls: ['./subject-detail-page.component.css']
})
export class SubjectDetailPageComponent implements OnInit {
  subjectId: string | null = null;
  subjectViewData: SubjectDetailViewFE | null = null;
  isLoading = true;
  errorMessage: string | null = null;
  isAddModuleModalOpen = false;

  // Store all courses for the "Add Module" form's course selector
  allAvailableCourses: MinimalCourseInfo[] = [];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private adminSubjectService: AdminSubjectService
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.subjectId = params.get('id'); // Assuming route is 'subjects/:id'
      if (this.subjectId) {
        this.loadSubjectDetailsAndModules();
        this.loadAllCoursesForModal(); // Pre-fetch courses for "Add Module" modal
      } else {
        this.errorMessage = "Subject ID not found in route.";
        this.isLoading = false;
      }
    });
  }

  async loadAllCoursesForModal(): Promise<void> {
      try {
          this.allAvailableCourses = await this.adminSubjectService.getCoursesForSelection();
      } catch (e) {
          console.error("Failed to load courses for modal", e);
          // Handle error, maybe show a toast
      }
  }

  async loadSubjectDetailsAndModules(): Promise<void> {
    if (!this.subjectId) return;
    this.isLoading = true;
    this.errorMessage = null;
    try {
      // Fetch subject details and modules in parallel
      const [subjectDetailsBackend, modulesList] = await Promise.all([
        this.adminSubjectService.getSubjectDetailsForView(this.subjectId), // Returns SubjectDetailsBackend
        this.adminSubjectService.getModulesForSubject(this.subjectId)   // Returns ModuleListItemFE[] (or raw module data to be mapped)
      ]);

      if (subjectDetailsBackend) {
        // Map SubjectDetailsBackend to SubjectDetailViewFE
        // For AssociatedCourses, we need to fetch their names if backend only sends IDs.
        // Assuming getSubjectDetailsForView or backend populates AssociatedCourses with MinimalCourseInfo.
        // If not, an additional call to get all courses and filter would be needed here.
        let associatedCourseObjects: MinimalCourseInfo[] = [];
        if (subjectDetailsBackend.AssociatedCourses && subjectDetailsBackend.AssociatedCourses.length > 0) {
            if (typeof subjectDetailsBackend.AssociatedCourses[0] === 'string') {
                // If IDs, we need to fetch course names (this implies allAvailableCourses should be loaded first or fetched here)
                // This part can be complex if not pre-loading all courses or if list is huge
                // For simplicity now, assume backend can populate it or we use a placeholder if only IDs
                associatedCourseObjects = (subjectDetailsBackend.AssociatedCourses as string[]).map(id => {
                    const course = this.allAvailableCourses.find(c => c._id === id);
                    return course ? course : { _id: id, name: `Course ID: ${id}`};
                });
            } else {
                associatedCourseObjects = subjectDetailsBackend.AssociatedCourses as MinimalCourseInfo[];
            }
        }


        this.subjectViewData = {
          _id: subjectDetailsBackend._id,
          name: subjectDetailsBackend.SubjectName,
          description: subjectDetailsBackend.SubjectDescription || 'N/A',
          credits: subjectDetailsBackend.SubjectCredits,
          subjectLevel: subjectDetailsBackend.SubjectLevel,
          subjectType: subjectDetailsBackend.SubjectType,
          createdAt: new Date(subjectDetailsBackend.created_at),
          associatedCourses: associatedCourseObjects,
          modules: modulesList || [], // Directly use modulesList if it's already ModuleListItemFE[]
           // these are for TeacherDetailsFE, adjust or ensure SubjectDetailsFE has similar
          // isActive: subjectDetailsBackend.is_active ?? true, // Assuming default for Subject
          // isPublished: false, // Subjects might not have a direct published state like courses
        };
        console.log("Formatted Subject View Data:", this.subjectViewData);
      } else {
        this.errorMessage = `Subject with ID ${this.subjectId} not found.`;
      }
    } catch (error: any) {
      this.errorMessage = error.message || "Failed to load subject data.";
      console.error("Error in loadSubjectDetailsAndModules:", error);
    } finally {
      this.isLoading = false;
    }
  }


  openAddModuleModal(): void {
    if (!this.subjectViewData) return;
    // Pass current subject's associated courses to the modal for pre-selection or context
    this.isAddModuleModalOpen = true;
  }

  closeAddModuleModal(): void {
    this.isAddModuleModalOpen = false;
  }

  async handleModuleAdded(moduleData: ModuleBasicInfo): Promise<void> {
    if (!this.subjectId) return;
    console.log("SubjectDetailPage: New module data received:", moduleData);
    this.isLoading = true; // Indicate loading for the page while module is added
    try {
        const response = await this.adminSubjectService.addModuleToSubject(this.subjectId, moduleData);
        if (response.success) {
            alert(response.message || "Module added successfully!");
            this.loadSubjectDetailsAndModules(); // Refresh modules list
        } else {
            alert("Failed to add module: " + response.message);
        }
    } catch(error: any) {
        alert("Error adding module: " + error.message);
    } finally {
        this.isLoading = false;
        this.closeAddModuleModal();
    }
  }

  editSubject(): void {
    if(this.subjectId) {
      this.router.navigate(['/admin/subjects', this.subjectId, 'edit']);
    }
  }

  goBack(): void {
    this.router.navigate(['/admin/subjects']);
  }
}