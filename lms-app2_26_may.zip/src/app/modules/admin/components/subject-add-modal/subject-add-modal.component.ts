import { Component, EventEmitter, Output, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormArray } from '@angular/forms';

// Models needed for this component
import { SubjectBasicInfo } from '../../models/subject.model'; // Payload to emit
import { MinimalCourseInfo } from '../../models/course.model'; // For listing courses in multi-select

// Service needed to fetch courses
import { AdminSubjectService } from '../../services/admin-subject.service'; // To fetch all courses

@Component({
  selector: 'app-subject-add-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './subject-add-modal.component.html',
  // styleUrls: ['./subject-add-modal.component.css'] // If you create one
})
export class SubjectAddModalComponent implements OnInit {
  @Output() closeModal = new EventEmitter<void>();
  @Output() subjectAdded = new EventEmitter<SubjectBasicInfo>(); // Emits data for a new subject

  addSubjectForm: FormGroup; // This form is for Subject Name, Description, and Course IDs
  isLoading = false; // For the submit button
  isLoadingCourses = false; // For loading courses into the multi-select
  allAvailableCourses: MinimalCourseInfo[] = []; // To populate the multi-select

  constructor(
    private fb: FormBuilder,
    private adminSubjectService: AdminSubjectService // Used to get all courses
  ) {
    this.addSubjectForm = this.fb.group({
      name: ['', Validators.required],             // Subject Name
      description: ['', Validators.required],       // Subject Description
      assignedCourseIds: [[]]                     // FormControl to hold selected course IDs
    });
  }

  ngOnInit(): void {
    this.loadAllCoursesForSelection();
  }

  async loadAllCoursesForSelection(): Promise<void> {
    this.isLoadingCourses = true;
    try {
      // This service method should fetch ALL courses suitable for selection
      this.allAvailableCourses = await this.adminSubjectService.getCoursesForSelection();
    } catch (error) {
      console.error("SubjectAddModal: Error loading courses for selection:", error);
      // Optionally, display an error to the user within the modal
    } finally {
      this.isLoadingCourses = false;
    }
  }

  // Getter for easy form control access in the template
  get f() { return this.addSubjectForm.controls; }

  // No specific onCourseSelectionChange needed if formControlName handles multi-select value
  // The 'assignedCourseIds' FormControl will hold an array of the selected course IDs.

  onSubmit(): void {
    if (this.addSubjectForm.invalid) {
      this.addSubjectForm.markAllAsTouched();
      return;
    }
    this.isLoading = true;
    const formValue = this.addSubjectForm.value;

    const newSubjectPayload: SubjectBasicInfo = {
      name: formValue.name,
      description: formValue.description,
      assignedCourseIds: formValue.assignedCourseIds || [] // Get array of selected course IDs
    };

    console.log("SubjectAddModal: Submitting new subject payload:", newSubjectPayload);

    // The service call is now expected to be made by the PARENT component (SubjectManagementPageComponent)
    // This modal just emits the data.
    this.subjectAdded.emit(newSubjectPayload);
    // Reset isLoading and close the modal often happens in the parent after successful emission and processing.
    // However, for better UX in the modal, we can reset loading here if the emit itself is considered the "end" of its job.
    // this.isLoading = false; // Parent will typically handle closing
  }

  onCancel(): void {
    this.closeModal.emit();
  }
}