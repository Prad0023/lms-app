// src/app/modules/admin/components/subject-module-add-modal/subject-module-add-modal.component.ts
import { Component, EventEmitter, Input, OnInit, Output, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormArray, AbstractControl, ValidationErrors } from '@angular/forms';
import { ModuleBasicInfo } from '../../models/subject.model'; // Contains { moduleName, description, appliesToCourseIds, initialTopics }
import { MinimalCourseInfo } from '../../models/course.model';   // Contains { _id, name, description? }

@Component({
  selector: 'app-subject-module-add-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './subject-module-add-modal.component.html',
  // styleUrls: ['./subject-module-add-modal.component.css'] // Create if you have specific styles
})
export class SubjectModuleAddComponent implements OnInit, OnChanges {
  @Input() subjectId!: string; // ID of the parent subject
  @Input() subjectName!: string; // Name of the parent subject (for display in modal title)

  // Courses ALREADY associated with the PARENT SUBJECT.
  // These are the ONLY options for this new module's 'ReqForCourses' (appliesToCourseIds) selection.
  @Input() coursesAssociatedWithParentSubject: MinimalCourseInfo[] = [];

  @Output() closeModal = new EventEmitter<void>();
  @Output() moduleAdded = new EventEmitter<ModuleBasicInfo>(); // Emits the new module data

  addModuleForm: FormGroup;
  isLoading = false; // For the main submit button

  constructor(private fb: FormBuilder) {
    this.addModuleForm = this.fb.group({
      moduleName: ['', Validators.required],
      moduleDescription: [''], // Optional
      appliesToCourseIds: this.fb.array([]), // FormArray to hold selected course IDs for this module
      initialTopics: this.fb.array([], { validators: this.requireAtLeastOneValidTopicInArray }) // Start empty, add one in ngOnInit
    });
  }

  ngOnInit(): void {
    // Ensure at least one topic input field is present when the modal initializes
    if (this.initialTopicsArray.length === 0) {
      this.addTopicInputInternal();
    }
    console.log("SubjectModuleAddModal: Initialized. Parent Subject's Courses:", this.coursesAssociatedWithParentSubject);
    // If you want to pre-select all parent's associated courses for this module by default:
    // this.preselectParentAssociatedCourses();
  }

  ngOnChanges(changes: SimpleChanges): void {
    // React if the input courses list changes after initialization
    if (changes['coursesAssociatedWithParentSubject'] && !changes['coursesAssociatedWithParentSubject'].firstChange) {
      console.log("SubjectModuleAddModal: coursesAssociatedWithParentSubject input updated:", this.coursesAssociatedWithParentSubject);
      // Decide if you need to update `appliesToCourseIds` FormArray based on new parent subject course list.
      // For example, clear and pre-select if that's the desired behavior:
      // this.preselectParentAssociatedCourses();
    }
  }

  // Getters for easier access in template and component
  get f() { return this.addModuleForm.controls; }
  get initialTopicsArray() { return this.addModuleForm.get('initialTopics') as FormArray; }
  get appliesToCourseIds() { return this.addModuleForm.get('appliesToCourseIds') as FormArray; }

  // Custom validator for the initialTopics FormArray
  private requireAtLeastOneValidTopicInArray(formArray: AbstractControl): ValidationErrors | null {
    if (formArray instanceof FormArray && formArray.controls.length > 0) {
      const hasAtLeastOneValidTopic = formArray.controls.some(
        control => control.get('topicName')?.value?.trim() !== ''
      );
      return hasAtLeastOneValidTopic ? null : { requireAtLeastOneValidTopic: true };
    }
    // If formArray is empty (which it shouldn't be due to ngOnInit logic), no error from this validator.
    // The FormGroup for individual topics will handle their own 'required' for topicName.
    return null;
  }


  // Creates a new FormGroup for a single topic
  createTopicGroup(): FormGroup {
    return this.fb.group({
      topicName: ['', Validators.required]
      // Future: Add other topic fields like description, content type, etc.
    });
  }

  // Internal method to add a topic without the 'canAddMoreTopics' check (used by ngOnInit)
  private addTopicInputInternal(): void {
    this.initialTopicsArray.push(this.createTopicGroup());
  }

  // Called by the "Add Another Topic" button in the template
  addTopicInput(): void {
    if (this.canAddMoreTopics()) {
      this.addTopicInputInternal();
    }
  }

  // Called by the "Remove Topic" button in the template
  removeTopicInput(index: number): void {
    // Prevent removing the last topic input field
    if (this.initialTopicsArray.length > 1) {
      this.initialTopicsArray.removeAt(index);
    } else {
      // Optionally clear the value, or simply prevent removal.
      // An alert here can be annoying, disabling the button is better.
      // this.initialTopicsArray.at(0).get('topicName')?.reset('');
      console.warn("Cannot remove the last topic field.");
    }
  }

  // Logic for the "Add Another Topic" button's disabled state
   canAddMoreTopics(): boolean {
    if (this.initialTopicsArray.length === 0) {
      // This case should ideally not be hit if ngOnInit always adds one.
      // If it can be hit, deciding if "more topics can be added" is true or false depends on desired UX.
      // Assuming we always want at least one topic input to become visible via "Add topic" if none exist:
      return true; // Or false if the user MUST interact with the first one before adding more
    }
    const lastTopicGroup = this.initialTopicsArray.at(this.initialTopicsArray.length - 1);
    if (!lastTopicGroup) { // Should not happen if length > 0
        return false;
    }
    const topicNameControl = lastTopicGroup.get('topicName');
    // Ensure topicNameControl exists, is valid, and its value (trimmed) is not empty.
    // The 'valid' check covers the 'required' validator.
    // `!!` converts the potentially undefined/nullish result of the expression to a boolean.
    return !!(topicNameControl && topicNameControl.valid && topicNameControl.value?.trim() !== '');
  }


  // --- Course Selection Logic for this Module ---
  // This determines which of the PARENT SUBJECT's associated courses this new MODULE will also apply to.
  onCourseSelectionChange(event: Event, courseId: string): void {
    const isChecked = (event.target as HTMLInputElement).checked;
    const courseIdsFormArray = this.appliesToCourseIds;

    if (isChecked) {
      // Add courseId if it's not already there
      if (!courseIdsFormArray.controls.find(ctrl => ctrl.value === courseId)) {
        courseIdsFormArray.push(this.fb.control(courseId));
      }
    } else {
      // Remove courseId if it exists
      const index = courseIdsFormArray.controls.findIndex(ctrl => ctrl.value === courseId);
      if (index > -1) {
        courseIdsFormArray.removeAt(index);
      }
    }
    console.log("Module will apply to selected Course IDs:", courseIdsFormArray.value);
  }

  isCourseSelectedForModule(courseId: string): boolean {
    return !!this.appliesToCourseIds.controls.find(ctrl => ctrl.value === courseId);
  }
  // --- End Course Selection Logic ---


  // Helper to convert strings to Title Case (e.g., "my topic" -> "My Topic")
  toTitleCase(str: string): string {
    if (!str) return '';
    return str.toLowerCase().split(' ').map(word => {
      return word.charAt(0).toUpperCase() + word.slice(1);
    }).join(' ');
  }

  onSubmit(): void {
    this.addModuleForm.markAllAsTouched(); // Show validation errors

    if (this.addModuleForm.invalid) {
      console.log("Add Module Form is invalid. Errors:", this.addModuleForm.errors);
      if (this.initialTopicsArray.hasError('requireAtLeastOneValidTopic')) {
          // This alert is a bit redundant if individual topicName fields show 'required'
          // alert("Please ensure at least one topic has a name.");
      }
      return;
    }
    this.isLoading = true;

    const formValue = this.addModuleForm.value;

    // Process topics: title case and filter out any that are still empty after trim (though validator should prevent this)
    const processedTopics = formValue.initialTopics
        .map((topic: { topicName: string }) => ({
            topicName: this.toTitleCase(topic.topicName.trim())
        }))
        .filter((topic: { topicName: string }) => topic.topicName !== '');

    // Double check if, after filtering, there are no topics left (should be caught by formarray validator)
    if (processedTopics.length === 0 && formValue.initialTopics.length > 0) {
        console.error("Module submission error: No valid topics provided.");
        alert("At least one topic must have a valid name.");
        this.isLoading = false;
        return;
    }


    const modulePayload: ModuleBasicInfo = {
      moduleName: this.toTitleCase(formValue.moduleName.trim()),
      moduleDescription: formValue.moduleDescription?.trim() || undefined, // Ensure empty string becomes undefined if desired
      appliesToCourseIds: formValue.appliesToCourseIds || [],
      initialTopics: processedTopics
    };

    console.log("SubjectModuleAddModal: Submitting processed module payload:", modulePayload);
    this.moduleAdded.emit(modulePayload);
    // The parent component (SubjectDetailPageComponent) will handle the service call and closing the modal.
    // It will also reset its own isLoading state for the page.
    // We can reset this modal's isLoading here, but parent usually handles closure.
    // For a better UX, parent sets modal's isLoading to false when service call in parent resolves/rejects
  }

  onCancel(): void {
    this.closeModal.emit();
  }
}