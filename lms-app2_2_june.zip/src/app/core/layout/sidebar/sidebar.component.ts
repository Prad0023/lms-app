import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';

import { AuthService, User } from '../../services/auth.service';
import { NavigationItem } from '../../models/navigation-item.model';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit, OnDestroy {
  @Input() isSidebarOpen = true;

  currentUser: User | null = null;
  navItems: NavigationItem[] = [];
  private userSubscription!: Subscription;
  private routerSubscription!: Subscription;

  // Define all possible navigation items here
  private allNavItems: NavigationItem[] = [
    // --- Admin Specific ---
    { label: 'Dashboard', icon: 'fas fa-tachometer-alt', route: '/admin/dashboard', roles: ['admin'] },
    { label: 'Teachers', icon: 'fas fa-chalkboard-teacher', route: '/admin/teachers', roles: ['admin'] }, // Changed from "TEACHER"
    { label: 'Students', icon: 'fas fa-user-graduate', route: '/admin/students', roles: ['admin'] }, // Changed from "STUDENT"
    { label: 'Batches', icon: 'fas fa-users', route: '/admin/batches', roles: ['admin'] },        // New: BATCH
    { label: 'Courses', icon: 'fas fa-book-open', route: '/admin/courses', roles: ['admin'] },      // Changed from "COURSES"
    { label: 'Subjects', icon: 'fas fa-swatchbook', route: '/admin/subjects', roles: ['admin'] },
    // Example for a section with sub-items (we can implement dropdown later)
    // {
    //   label: 'Content',
    //   icon: 'fas fa-folder-open',
    //   roles: ['admin'],
    //   children: [
    //     { label: 'Lessons', route: '/admin/content/lessons', roles: ['admin'] },
    //     { label: 'Quizzes', route: '/admin/content/quizzes', roles: ['admin'] },
    //   ]
    // },
    { label: 'Settings', icon: 'fas fa-cogs', route: '/admin/settings', roles: ['admin'] }, // Kept settings

    // --- Teacher Specific (Keep these for when we implement Teacher role) ---
    { label: 'My Dashboard', icon: 'fas fa-chalkboard-teacher', route: '/teacher/dashboard', roles: ['teacher'] },
    { label: 'My Courses', icon: 'fas fa-book-reader', route: '/teacher/courses', roles: ['teacher'] },
    // ... other teacher items

    // --- Student Specific (Keep these for when we implement Student role) ---
    { label: 'My Dashboard', icon: 'fas fa-user-graduate', route: '/student/dashboard', roles: ['student'] },
    { label: 'Enrolled Courses', icon: 'fas fa-graduation-cap', route: '/student/courses', roles: ['student'] },
    // ... other student items

    // --- Common ---
    { label: 'Profile', icon: 'fas fa-user-circle', route: '/profile', roles: ['admin', 'teacher', 'student']},
    { label: 'Separator', isSeparator: true, roles: ['admin', 'teacher', 'student'] },
  ];

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {
    this.userSubscription = this.authService.currentUser.subscribe(user => {
      this.currentUser = user;
      this.filterNavItems();
      this.updateActiveLink(this.router.url);
    });

    this.routerSubscription = this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: any) => {
      this.updateActiveLink(event.urlAfterRedirects || event.url);
    });
  }

  private filterNavItems(): void {
    if (this.currentUser && this.currentUser.roles) {
      const userRoles = this.currentUser.roles.map(role => role.toLowerCase());
      this.navItems = this.allNavItems.filter(item =>
        item.roles?.some(role => userRoles.includes(role.toLowerCase()))
      );
    } else {
      this.navItems = [];
    }
  }

  private updateActiveLink(currentUrl: string): void {
    this.navItems = this.navItems.map(item => ({
      ...item,
      isActive: item.route ? currentUrl.startsWith(item.route) : false, // Simpler active check for now
      children: item.children?.map(child => ({
        ...child,
        isActive: child.route ? currentUrl.startsWith(child.route) : false
      }))
    }));
    // For more precise active link (e.g. dashboard only active for /admin/dashboard exactly):
    // isActive: item.route ? (item.route === '/admin/dashboard' ? currentUrl === item.route : currentUrl.startsWith(item.route)) : false,
  }


  handleLogout(): void {
    this.authService.logout();
  }

  ngOnDestroy(): void {
    if (this.userSubscription) {
      this.userSubscription.unsubscribe();
    }
    if (this.routerSubscription) {
      this.routerSubscription.unsubscribe();
    }
  }
}