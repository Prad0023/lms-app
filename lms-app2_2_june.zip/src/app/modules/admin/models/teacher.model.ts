// src/app/modules/admin/models/teacher.model.ts

// For forms (typically camelCase for Angular forms)
export interface TeacherBasicInfo {
  fullName: string;
  email: string;
  mobile: string;
  designation: string;
}

// Interface for the raw data structure coming from the backend AFTER decryption
// This is what AdminTeacherService.getTeachers() will return in its Promise.
export interface TeacherDetailsBackend {
  _id: string;
  email: string;
  mobile_number?: string; // snake_case from backend, make optional if it can be missing
  full_name: string;     // snake_case from backend
  email_verified: boolean;
  mobile_verified?: boolean; // make optional if it can be missing
  is_active: boolean;
  created_by?: string; // make optional if it can be missing
  roles: { role_id: string }[];
  created_at: string;
  updated_at: string;
  __v?: number;
  // Backend data might NOT have these or they might be optional:
  designation?: string;
  status?: string; // This will be the raw status string from backend
  onboardingLinkSentAt?: string; // String from backend
  profileCompletedAt?: string;   // String from backend
  hiredAt?: string;              // String from backend
  leftAt?: string;               // String from backend
  assignedBatches?: string[];
}

// Interface for the frontend view model (used by TeacherManagementPageComponent.teachers)
// This is what your component and template will primarily interact with.
export interface TeacherDetailsFE {
  _id: string;
  fullName: string;    // camelCase for frontend
  email: string;
  mobile: string;      // camelCase for frontend
  designation: string; // Will have a default if missing from backend
  status: 'pending_onboarding' | 'pending_verification' | 'hired' | 'marked_for_review' | 'left' | 'unknown' | string; // Typed status
  isActive: boolean;
  // Dates are converted to Date objects for easier manipulation/display in frontend
  onboardingLinkSentAt?: Date;
  profileCompletedAt?: Date;
  hiredAt?: Date;
  leftAt?: Date;
  // Add any other transformed or frontend-specific fields
  // e.g., formattedRoles?: string;
}


// For the API response containing encrypted data
export interface EncryptedListPayload {
  responseAesKeyB64: string;
  encryptedData: string;
}

// For the overall API response structure when fetching lists
export interface FetchTeachersApiResponse { // Keep this specific for now
  success: boolean;
  statusCode: number;
  data?: EncryptedListPayload;
  message: string;
}