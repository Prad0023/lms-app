import { Component, EventEmitter, Output, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormArray } from '@angular/forms';
import {
  Subject as RxJsSubject, // Renamed to avoid conflict with your CourseSubject
  Subscription,          // For unsubscribing
  debounceTime,
  distinctUntilChanged,
  switchMap,
  tap,                   // Import tap
  catchError,            // Import catchError
  of,                    // Import of (for returning an Observable in catchError)
  from                   // Import from (to convert Promise to Observable)
} from 'rxjs';

import { CourseBasicInfo, Subject as CourseSubject } from '../../models/course.model'; // Your model
import { AdminCourseService } from '../../services/admin-course.service';

@Component({
  selector: 'app-course-add-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './course-add-modal.component.html',
  // styleUrls: ['./course-add-modal.component.css'] // Create if needed
})
export class CourseAddModalComponent implements OnInit, OnDestroy {
  @Output() closeModal = new EventEmitter<void>();
  @Output() courseAdded = new EventEmitter<CourseBasicInfo>();

  addCourseForm: FormGroup;
  isLoading = false; // For main form submission
  isLoadingSubjects = false; // For subject search loader

  subjectSearchTerm$ = new RxJsSubject<string>();
  availableSubjects: CourseSubject[] = [];
  selectedSubjects: CourseSubject[] = [];
  showSubjectDropdown = false;

  private subjectSubscription!: Subscription; // To store the subscription for cleanup

  constructor(
    private fb: FormBuilder,
    private adminCourseService: AdminCourseService
  ) {
    this.addCourseForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required],
      subjects: this.fb.array([]) // Stores selected subject IDs
    });
  }

  ngOnInit(): void {
    this.subjectSubscription = this.subjectSearchTerm$.pipe(
      debounceTime(300),
      distinctUntilChanged(),
      tap(() => {
        this.isLoadingSubjects = true;
        // console.log('Subject search: Loading true');
      }),
      // switchMap will take the 'term' and expects an Observable as a return
      // We convert the Promise from getSubjects to an Observable using 'from'
      switchMap((term: string) => // Explicitly type term, though usually inferred
        from(this.adminCourseService.getSubjects(term)).pipe( // <<< Convert Promise to Observable
          catchError((err) => {
            console.error('Error fetching subjects:', err);
            this.isLoadingSubjects = false; // Ensure loader stops on error
            return of([]); // Return an Observable of an empty array on error
          })
        )
      ),
      tap(() => {
        this.isLoadingSubjects = false;
        // console.log('Subject search: Loading false');
      })
    ).subscribe((subjects: CourseSubject[]) => { // 'subjects' should now be correctly typed as CourseSubject[]
      // console.log('Received subjects:', subjects);
      this.availableSubjects = subjects.filter(
        availSubj => !this.selectedSubjects.find(selSubj => selSubj.id === availSubj.id)
      );
      // Decide to show dropdown based on whether search input has value and there are results, or if loading
      const searchInputVal = (document.getElementById('subjectSearchInput') as HTMLInputElement)?.value;
      if (searchInputVal && (this.availableSubjects.length > 0 || this.isLoadingSubjects)) {
          this.showSubjectDropdown = true;
      } else if (!searchInputVal) {
          this.showSubjectDropdown = false; // Hide if search term is empty
      }
      // If term exists but no results & not loading, keep dropdown open to show "No results"
      // This logic might need slight adjustment based on desired UX for showing "No subjects found"
    });
  }

  get f() { return this.addCourseForm.controls; }
  get subjectsArray() { return this.addCourseForm.get('subjects') as FormArray; }

  onSubjectSearch(event: Event): void {
    const searchTerm = (event.target as HTMLInputElement).value;
    this.subjectSearchTerm$.next(searchTerm); // This triggers the RxJS pipe
    // Dropdown visibility is now handled within the subscribe block based on results/loading
  }

  selectSubject(subject: CourseSubject, searchInput: HTMLInputElement): void {
    if (!this.selectedSubjects.find(s => s.id === subject.id)) {
      this.selectedSubjects.push(subject);
      this.subjectsArray.push(this.fb.control(subject.id)); // Store ID
    }
    this.availableSubjects = []; // Clear available to hide list or prepare for new search
    this.showSubjectDropdown = false;
    searchInput.value = ''; // Clear search input
    // this.subjectSearchTerm$.next(''); // Optionally trigger a refresh with empty term to hide dropdown fully
  }

  removeSelectedSubject(subjectToRemove: CourseSubject): void {
    this.selectedSubjects = this.selectedSubjects.filter(s => s.id !== subjectToRemove.id);
    const index = this.subjectsArray.controls.findIndex(control => control.value === subjectToRemove.id);
    if (index > -1) {
      this.subjectsArray.removeAt(index);
    }
  }

  onSubmit(): void {
    if (this.addCourseForm.invalid) {
      this.addCourseForm.markAllAsTouched();
      return;
    }
    this.isLoading = true;
    const formValue = this.addCourseForm.value;
    const coursePayload: CourseBasicInfo = {
      name: formValue.name,
      description: formValue.description,
      subjectIds: formValue.subjects // This is an array of subject IDs
    };

    console.log("CourseAddModal: Submitting course payload:", coursePayload);
    this.adminCourseService.addCourse(coursePayload).then(response => {
      if (response.success) {
        this.courseAdded.emit(coursePayload);
        alert(response.message || 'Course added successfully!');
        this.closeModal.emit();
      } else {
        alert(`Failed to add course: ${response.message || 'Unknown error'}`);
      }
    }).catch(err => {
      alert(`Error adding course: ${err.message || err.toString() || 'Please try again.'}`);
    }).finally(() => {
      this.isLoading = false;
    });
  }

  onCancel(): void {
    this.closeModal.emit();
  }

  onSearchFocus(): void {
    const searchInputVal = (document.getElementById('subjectSearchInput') as HTMLInputElement)?.value;
    if (searchInputVal && this.availableSubjects.length > 0) {
         this.showSubjectDropdown = true;
    } else if (searchInputVal && !this.isLoadingSubjects && this.availableSubjects.length === 0) {
         this.showSubjectDropdown = true; // To show "No results"
    }
    // If no search term, keep it hidden until typing starts.
  }
  onSearchBlur(): void {
    setTimeout(() => { // Delay to allow click on dropdown items
      if (!(document.activeElement?.closest('.subject-dropdown-list') || document.activeElement === document.getElementById('subjectSearchInput'))) {
          this.showSubjectDropdown = false;
      }
    }, 200);
  }

  ngOnDestroy(): void {
    // Unsubscribe from the RxJs Subject subscription to prevent memory leaks
    if (this.subjectSubscription) {
      this.subjectSubscription.unsubscribe();
    }
  }
}