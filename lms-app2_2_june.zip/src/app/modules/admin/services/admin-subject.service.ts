import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { firstValueFrom, Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { environment } from '../../../../environments/environments'; // Corrected path from environments/environments
import { EncryptionService } from '../../../core/services/encryption.service';
import { AuthService } from '../../../core/services/auth.service';
import {
  SubjectDetailsBackend,
  FetchSubjectsApiResponse,
  SubjectBasicInfo,
  EncryptedSubjectRequest,
  SubjectMutationResponse,
  SubjectUpdatePayload,
  ModuleBasicInfo,      // Payload for adding a module
  BulkModuleAddResponse,
  // TopicListItemFE,       // Used by getTopicsForModule simulation (which is likely removed)
  // TopicDetailsBackend,   // From your imports, but TopicDetailsBackendNested is used more specifically.
                           // If this specific one is not used directly, it can be removed from this service's imports.
  ModuleDetailsBackendNested, // For the nested structure if returned by backend
  TopicDetailsBackendNested   // For the nested structure if returned by backend
} from '../models/subject.model';
import {
  MinimalCourseInfo,
  FetchCoursesApiResponse as GenericFetchListApiResponse, // Use an alias for clarity
  CourseDetailsBackend as FullCourseDetailsBackend
} from '../models/course.model';


@Injectable({
  providedIn: 'root'
})
export class AdminSubjectService {
  private baseApiUrl = `${environment.apiUrl}/admin/subjects`;
  private coursesApiUrl = `${environment.apiUrl}/admin/courses`;

  constructor(
    private http: HttpClient,
    private encryptionService: EncryptionService,
    private authService: AuthService
  ) {}

  private getAuthHeaders() {
    const token = this.authService.token;
    if (!token) {
      console.error(`${this.constructor.name}: Admin token not found for API call.`);
      throw new Error("Authentication token is missing. Please log in again.");
    }
    return {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };
  }

  private handleHttpError(error: HttpErrorResponse, context: string = 'operation'): Observable<never> {
    console.error(`AdminSubjectService HTTP Error during ${context}:`, error.status, error.message, error.error);
    let userMessage = `An unexpected error occurred during ${context}.`;
    if (error.error && typeof error.error === 'object' && error.error.message) {
      userMessage = error.error.message;
    } else if (typeof error.error === 'string' && error.error.length > 0 && error.error.length < 300) {
        userMessage = error.error;
    } else if (error.message) {
      userMessage = `Error ${error.status}: ${error.statusText || 'Server communication error'}`;
    }
    return throwError(() => ({
        success: false, message: userMessage, statusCode: error.status, errorDetail: error.error
    }));
  }

  // --- Add New Subject ---
  async addSubject(subjectPayloadToEncrypt: SubjectBasicInfo): Promise<SubjectMutationResponse> {
    const addSubjectEndpoint = `${this.baseApiUrl}/create`;
    console.log(`AdminSubjectService: Adding new subject via ${addSubjectEndpoint}`, subjectPayloadToEncrypt);
    try {
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      const rsaEncryptedValue = await this.encryptionService.encryptAesKeyBase64WithRsa(aesKeyBase64ForRsa, rsaPublicKeyCryptoKey); // Renamed variable
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(subjectPayloadToEncrypt, aesCryptoKey);
      const encryptedRequest: EncryptedSubjectRequest = { encryptedAesKeyB64: rsaEncryptedValue, encryptedPayloadB64: aesEncryptedPayloadB64 }; // Corrected assignment
      const headers = this.getAuthHeaders();

      return await firstValueFrom(
        this.http.post<SubjectMutationResponse>(addSubjectEndpoint, encryptedRequest, { headers })
          .pipe(
            tap(res => console.log("AdminSubjectService: Response from add subject API:", res)),
            catchError(err => this.handleHttpError(err, 'add subject'))
          )
      );
    } catch (error) { /* ... client-side error handling ... */
        const err = error as Error;
        return Promise.reject({ success: false, message: err.message || 'Client-side error adding subject.', statusCode: 0 } as SubjectMutationResponse);
    }
  }

  // --- Fetch All Subjects ---
  async getSubjects(filters?: { searchTerm?: string }): Promise<SubjectDetailsBackend[]> {
    const viewSubjectsEndpoint = `${this.baseApiUrl}/view-subjects`;
    console.log(`AdminSubjectService: Fetching subjects from ${viewSubjectsEndpoint} with filters:`, filters);
    let httpParams = new HttpParams();
    if (filters?.searchTerm) httpParams = httpParams.set('search', filters.searchTerm);

    try {
      const headers = this.getAuthHeaders();
      const apiResponse = await firstValueFrom(
        this.http.get<FetchSubjectsApiResponse>(viewSubjectsEndpoint, { params: httpParams, headers })
          .pipe(catchError(err => this.handleHttpError(err, 'fetch subjects list')))
      );
      console.log("AdminSubjectService: Received API response from /view-subjects:", apiResponse);
      if (apiResponse && apiResponse.success && apiResponse.data) {
        const { responseAesKeyB64, encryptedData } = apiResponse.data;
        const decryptedJsonString = await this.encryptionService.decryptAesGcmPayload(encryptedData, responseAesKeyB64);
        const subjectsFromBackend: SubjectDetailsBackend[] = JSON.parse(decryptedJsonString);
        return subjectsFromBackend;
      } else {
        throw new Error(apiResponse?.message || "Failed to fetch subjects: Server indicated failure or no data.");
      }
    } catch (error: any) { /* ... error handling ... */
        const message = (error instanceof HttpErrorResponse && error.error?.message) || error.message || "Could not fetch or decrypt subjects.";
        throw new Error(message);
    }
  }


  // --- Fetch Single Subject by ID (with nested Modules/Topics as per backend log) ---
  async getSubjectDetailsWithNestedData(subjectId: string): Promise<SubjectDetailsBackend | null> {
    const subjectDetailEndpoint = `${this.baseApiUrl}/${subjectId}`;
    console.log(`AdminSubjectService: Fetching subject (with nested data) for ID: ${subjectId} from ${subjectDetailEndpoint}`);
    try {
      const headers = this.getAuthHeaders();
      // Backend returns a single subject object encrypted, wrapped in FetchSubjectsApiResponse
      const apiResponse = await firstValueFrom(
        this.http.get<FetchSubjectsApiResponse>(subjectDetailEndpoint, { headers })
          .pipe(catchError(err => this.handleHttpError(err, `fetch subject ${subjectId} details`)))
      );
      console.log("AdminSubjectService: Raw API response for single subject details:", JSON.stringify(apiResponse).substring(0,300)+"...");
      if (apiResponse && apiResponse.success && apiResponse.data) {
        const { responseAesKeyB64, encryptedData } = apiResponse.data;
        if (!responseAesKeyB64 || !encryptedData) {
            throw new Error("Invalid encrypted data structure for single subject.");
        }
        const decryptedJsonString = await this.encryptionService.decryptAesGcmPayload(encryptedData, responseAesKeyB64);
        console.log("AdminSubjectService: Decrypted JSON for single subject:", decryptedJsonString.substring(0, 400) + "...");
        const subjectWithNestedData: SubjectDetailsBackend = JSON.parse(decryptedJsonString);
        return subjectWithNestedData;
      } else if (apiResponse && apiResponse.statusCode === 404) {
        return null;
      } else {
        throw new Error(apiResponse?.message || `Failed to fetch subject details for ${subjectId}.`);
      }
    } catch (error: any) { /* ... error handling ... */
        if ((error as any).statusCode === 404 || error.message?.toLowerCase().includes('not found')) return null;
        const message = (error instanceof HttpErrorResponse && error.error?.message) || error.message || "Could not fetch/decrypt subject.";
        throw new Error(message);
    }
  }

  // --- Update Subject ---
  async updateSubject(subjectId: string, payload: SubjectUpdatePayload): Promise<SubjectMutationResponse> {
    const updateSubjectEndpoint = `${this.baseApiUrl}/update/${subjectId}`;
    console.log(`AdminSubjectService: Updating subject ID ${subjectId}:`, payload);
    try {
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      const rsaEncryptedValue = await this.encryptionService.encryptAesKeyBase64WithRsa(aesKeyBase64ForRsa, rsaPublicKeyCryptoKey);
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(payload, aesCryptoKey);
      const encryptedRequest: EncryptedSubjectRequest = { encryptedAesKeyB64: rsaEncryptedValue, encryptedPayloadB64: aesEncryptedPayloadB64 };
      const headers = this.getAuthHeaders();

      return await firstValueFrom(
        this.http.put<SubjectMutationResponse>(updateSubjectEndpoint, encryptedRequest, { headers })
          .pipe(catchError(err => this.handleHttpError(err, `update subject ${subjectId}`)))
      );
    } catch (error) { /* ... error handling ... */
        const err = error as Error;
        return Promise.reject({ success: false, message: err.message || 'Client-side error updating subject.', statusCode: 0 } as SubjectMutationResponse);
    }
  }

  // --- Add SINGLE Module to Subject ---
  async addModuleToSubject(subjectId: string, moduleDataToEncrypt: ModuleBasicInfo): Promise<SubjectMutationResponse> {
    const addModuleEndpoint = `${this.baseApiUrl}/${subjectId}/modules/create`;
    console.log(`AdminSubjectService: Adding SINGLE module to subject ${subjectId} via ${addModuleEndpoint}`, moduleDataToEncrypt);
    try {
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      const rsaEncryptedValue = await this.encryptionService.encryptAesKeyBase64WithRsa(aesKeyBase64ForRsa, rsaPublicKeyCryptoKey);
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(moduleDataToEncrypt, aesCryptoKey);
      const encryptedRequest: EncryptedSubjectRequest = { encryptedAesKeyB64: rsaEncryptedValue, encryptedPayloadB64: aesEncryptedPayloadB64 };
      const headers = this.getAuthHeaders();

      return await firstValueFrom(
        this.http.post<SubjectMutationResponse>(addModuleEndpoint, encryptedRequest, { headers })
          .pipe(
            tap(res => console.log("AdminSubjectService: Response from actual add single module API:", res)),
            catchError(err => this.handleHttpError(err, `add module to subject ${subjectId}`))
          )
      );
    } catch (error) { /* ... error handling ... */
      const err = error as Error;
      return Promise.reject({ success: false, message: err.message || 'Client-side error adding module.', statusCode: 0 } as SubjectMutationResponse);
    }
  }

  // --- Add MULTIPLE Modules to Subject (for JSON Upload) ---
  async addMultipleModulesToSubject(subjectId: string, modulesArray: ModuleBasicInfo[]): Promise<BulkModuleAddResponse> {
    const bulkAddModulesEndpoint = `${this.baseApiUrl}/${subjectId}/modules/bulk-create`; // Note: Your prev log had .../modules-create/:subjectId
    console.log(`AdminSubjectService: Adding ${modulesArray.length} modules to subject ${subjectId} via ${bulkAddModulesEndpoint}`);
    if (!modulesArray || modulesArray.length === 0) {
      return Promise.resolve({ success: true, message: "No modules provided.", statusCode: 200 });
    }
    try {
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      const rsaEncryptedValue = await this.encryptionService.encryptAesKeyBase64WithRsa(aesKeyBase64ForRsa, rsaPublicKeyCryptoKey);
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(modulesArray, aesCryptoKey); // Encrypt array
      const encryptedRequest: EncryptedSubjectRequest = { encryptedAesKeyB64: rsaEncryptedValue, encryptedPayloadB64: aesEncryptedPayloadB64 };
      const headers = this.getAuthHeaders();

      return await firstValueFrom(
        this.http.post<BulkModuleAddResponse>(bulkAddModulesEndpoint, encryptedRequest, { headers })
          .pipe(
            tap(res => console.log("AdminSubjectService: Response from bulk add modules API:", res)),
            catchError(err => this.handleHttpError(err, `bulk add modules to subject ${subjectId}`))
          )
      );
    } catch (error) { /* ... error handling ... */
        const err = error as Error;
        return Promise.reject({ success: false, message: err.message || 'Client-side error bulk adding modules.', statusCode: 0, data: {errors:[]} } as BulkModuleAddResponse);
    }
  }

  // --- Fetch Courses for Dropdown (e.g., in Add/Edit Subject or Add Module Modals) ---
  async getCoursesForSelection(): Promise<MinimalCourseInfo[]> {
    const viewCoursesEndpoint = `${this.coursesApiUrl}/view-courses`;
    try {
      const headers = this.getAuthHeaders();
      const apiResponse = await firstValueFrom(
        this.http.get<GenericFetchListApiResponse>(viewCoursesEndpoint, { headers }) // Use GenericFetchListApiResponse
          .pipe(catchError(err => this.handleHttpError(err, 'fetch courses for selection')))
      );
      if (apiResponse.success && apiResponse.data) {
        const { responseAesKeyB64, encryptedData } = apiResponse.data;
        const decryptedJsonString = await this.encryptionService.decryptAesGcmPayload(encryptedData, responseAesKeyB64);
        const fullCourses: FullCourseDetailsBackend[] = JSON.parse(decryptedJsonString);
        // Ensure MinimalCourseInfo { _id, name, description? } matches the mapping
        return fullCourses.map(course => ({
          _id: course._id,
          name: course.CourseName, // Map CourseName to name
          description: course.CourseDescription || undefined // Ensure description is string or undefined
        }));
      } else {
        throw new Error(apiResponse.message || "Failed to fetch courses for selection.");
      }
    } catch (error: any) { /* ... error handling ... */
        const message = (error instanceof HttpErrorResponse && error.error?.message) || error.message || "Could not fetch courses for selection.";
        throw new Error(message);
    }
  }

  // --- (Optional) Fetch Topics for a Module if not always nested (for SubjectDetailPage) ---
  // async getTopicsForModule(moduleId: string): Promise<TopicListItemFE[]> {
  //   // This is still simulated as your GET subject detail log included topics nested.
  //   // If you have a separate API endpoint, implement it here.
  //   console.log(`AdminSubjectService: SIMULATING fetch topics for moduleId: ${moduleId}`);
  //   await new Promise(resolve => setTimeout(resolve, 200));
  //   const topics: TopicListItemFE[] = [];
  //   for (let i = 0; i < Math.floor(Math.random() * 5) + 1; i++) {
  //     topics.push({ _id: `topic_${moduleId}_${i}`, topicName: `Simulated Topic ${i + 1} for ${moduleId}` });
  //   }
  //   return topics;
  // }

  // Removed simulation methods like simulateFetchSubjectsApi, getMockSubjectsData etc. for brevity
  // as we are moving towards actual API calls. Keep them if you need for testing.
}