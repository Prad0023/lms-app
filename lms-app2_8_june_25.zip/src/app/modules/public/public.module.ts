import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PublicRoutingModule } from './public-routing.module';

// Landing Page and its sections (assuming they are all standalone)
import { LandingPageComponent } from './pages/landing-page/landing-page.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { HeroSectionComponent } from './components/hero-section/hero-section.component';
import { ProblemStatementSectionComponent } from './components/problem-statement-section/problem-statement-section.component';
import { FeaturesSectionComponent } from './components/features-section/features-section.component';
import { ProcessSectionComponent } from './components/process-section/process-section.component';
import { TechnologiesSectionComponent } from './components/technologies-section/technologies-section.component';
import { TestimonialsSectionComponent } from './components/testimonials-section/testimonials-section.component';
import { BlogsPreviewSectionComponent } from './components/blogs-preview-section/blogs-preview-section.component';
import { PageFooterComponent } from './components/page-footer/page-footer.component';
import { ScrollAnimationDirective } from '../../directives/scroll-animation.directive'; // Shared directive
import { SafeHtmlPipe } from '../../shared/pipes/safe-html.pipe'; // Shared pipe

@NgModule({
  declarations: [
    // Declare non-standalone components here
  ],
  imports: [
    CommonModule,
    PublicRoutingModule,
    // Import all standalone components used by this module or its routes
    LandingPageComponent,
    NavbarComponent,
    HeroSectionComponent,
    ProblemStatementSectionComponent,
    FeaturesSectionComponent,
    ProcessSectionComponent,
    TechnologiesSectionComponent,
    TestimonialsSectionComponent,
    BlogsPreviewSectionComponent,
    PageFooterComponent,
    ScrollAnimationDirective, // Directives and Pipes also need to be imported if standalone
    SafeHtmlPipe
  ]
})
export class PublicModule { }