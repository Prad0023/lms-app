import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ScrollAnimationDirective } from '../../../../directives/scroll-animation.directive';

interface BlogPostPreview {
  id: string;
  title: string;
  imageUrl: string;
  excerpt: string;
  date: string;
  author: string;
}

@Component({
  selector: 'app-blogs-preview-section',
  standalone: true,
  imports: [CommonModule, RouterLink, ScrollAnimationDirective],
  templateUrl: './blogs-preview-section.component.html',
})
export class BlogsPreviewSectionComponent {
  blogPosts: BlogPostPreview[] = [
    {
      id: '1',
      title: 'Mastering JavaScript Async/Await',
      imageUrl: 'https://images.pexels.com/photos/577585/pexels-photo-577585.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      excerpt: 'Dive deep into asynchronous JavaScript and learn how to write cleaner, more readable code with async/await.',
      date: 'October 26, 2023',
      author: 'Jane Doe'
    },
    {
      id: '2',
      title: 'The Future of AI in Education',
      imageUrl: 'https://images.pexels.com/photos/3861958/pexels-photo-3861958.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      excerpt: 'Explore how Artificial Intelligence is revolutionizing learning platforms and personalizing education for everyone.',
      date: 'October 20, 2023',
      author: 'John Smith'
    },
    {
      id: '3',
      title: 'Top 5 Python Libraries for Data Science',
      imageUrl: 'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      excerpt: 'A curated list of essential Python libraries that every aspiring data scientist should know.',
      date: 'October 15, 2023',
      author: 'Alice Brown'
    }
  ];
}