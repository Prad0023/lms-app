import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { firstValueFrom, Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { environment } from '../../../../environments/environments';
import { EncryptionService } from '../../../core/services/encryption.service';
import { AuthService } from '../../../core/services/auth.service';

// Import from MODELS
import { EncryptedGenericRequest } from '../models/subject.model'; // Using generic wrappers
import {
  TopicDetailsWithResourcesBackend,
  TopicSimpleCreatePayload,
  AssessmentItem,
  BulkTopicAddPayload, // From subject.model but could be in topic.model
  BulkTopicAddResponse,
  FetchSingleTopicWithResourcesApiResponse, // From subject.model but could be in topic.mode // From topic.model
} from '../models/topic.model'; // Reusing for generic encrypted body

// Generic response for resource updates or simple mutations
export interface GenericMutationResponse {
  success: boolean;
  message: string;
  statusCode?: number;
  data?: any;
}


@Injectable({
  providedIn: 'root'
})
export class AdminTopicService {
  private baseApiUrl = `${environment.apiUrl}/admin/topics`; // Base URL for topic-specific actions
  private subjectsApiUrl = `${environment.apiUrl}/admin/subjects`; // Needed for nested topic creation path

  constructor(
    private http: HttpClient,
    private encryptionService: EncryptionService,
    private authService: AuthService
  ) {}

  private getAuthHeaders() {
    const token = this.authService.token;
    if (!token) {
      console.error(`${this.constructor.name}: Admin token not found for API call.`);
      throw new Error("Authentication token is missing. Please log in again.");
    }
    return {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };
  }

  private handleHttpError(error: HttpErrorResponse, context: string = 'operation'): Observable<never> {
    console.error(`AdminTopicService HTTP Error during ${context}:`, error.status, error.message, error.error);
    let userMessage = `An unexpected error occurred during ${context}.`;
    if (error.error && typeof error.error === 'object' && error.error.message) userMessage = error.error.message;
    else if (typeof error.error === 'string' && error.error.length > 0 && error.error.length < 300) userMessage = error.error;
    else if (error.message) userMessage = `Error ${error.status}: ${error.statusText || 'Server error'}`;
    return throwError(() => ({ success: false, message: userMessage, statusCode: error.status, errorDetail: error.error } as GenericMutationResponse));
  }


  // --- Fetch Single Topic with all its Resources ---
async getTopicWithResources(topicId: string): Promise<TopicDetailsWithResourcesBackend | null> {
    const endpoint = `${this.baseApiUrl}/${topicId}/resources_with_details`;
    console.log(`AdminTopicService: Fetching topic (ID: ${topicId}) resources from ${endpoint}`);
    try {
      const headers = this.getAuthHeaders();
      const apiResponse = await firstValueFrom(
        this.http.get<FetchSingleTopicWithResourcesApiResponse>(endpoint, { headers })
          .pipe(catchError(err => this.handleHttpError(err, `fetch topic ${topicId} resources`)))
      );
      // const apiResponse = await this.simulateFetchTopicWithResourcesApi(topicId); // SIMULATION

      console.log("AdminTopicService: Raw API response for single topic:", apiResponse);

      if (apiResponse && apiResponse.success && apiResponse.data) {
        // apiResponse.data IS of type EncryptedGenericRequest (or similar containing the two keys)
        const encryptedPayloadContainer: EncryptedGenericRequest = apiResponse.data;
        const responseAesKeyB64 = encryptedPayloadContainer.encryptedAesKeyB64; // CORRECT ACCESS
        const encryptedData = encryptedPayloadContainer.encryptedPayloadB64;   // CORRECT ACCESS

        if (!responseAesKeyB64 || !encryptedData) {
             throw new Error("Invalid encrypted data structure from server for topic resources.");
        }
        const decryptedJsonString = await this.encryptionService.decryptAesGcmPayload(encryptedData, responseAesKeyB64);
        const topicData: TopicDetailsWithResourcesBackend = JSON.parse(decryptedJsonString);
        return topicData;
      } else if (apiResponse && apiResponse.statusCode === 404) { return null; }
      else { throw new Error(apiResponse?.message || "Failed to fetch topic resources."); }
    } catch (error: any) { /* ... error handling ... */ throw error; }
  }


  // --- Update/Replace Assessments for a Topic ---
  async updateTopicAssessments(topicId: string, assessments: AssessmentItem[]): Promise<GenericMutationResponse> {
    const endpoint = `${this.baseApiUrl}/${topicId}/assessments`; // Example: PUT or POST
    console.log(`AdminTopicService: Updating all assessments for topic ${topicId}`);
    try {
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      const rsaEncryptedValue = await this.encryptionService.encryptAesKeyBase64WithRsa(aesKeyBase64ForRsa, rsaPublicKeyCryptoKey);
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(assessments, aesCryptoKey);
      const encryptedRequest: EncryptedGenericRequest = { encryptedAesKeyB64: rsaEncryptedValue, encryptedPayloadB64: aesEncryptedPayloadB64 };
      const headers = this.getAuthHeaders();

      // Replace with actual API call
      // return await firstValueFrom(
      //   this.http.put<GenericMutationResponse>(endpoint, encryptedRequest, { headers })
      //     .pipe(catchError(err => this.handleHttpError(err, `update topic assessments ${topicId}`)))
      // );
      // SIMULATION:
      console.log("AdminTopicService: SIMULATING API call to update assessments:", encryptedRequest);
      await new Promise(resolve => setTimeout(resolve, 1000));
      return { success: true, message: "Assessments updated successfully (simulated).", statusCode: 200 };

    } catch (error: any) {
        console.error(`Error in updateTopicAssessments (client-side/encryption for topic ${topicId}):`, error);
        const err = error as Error;
        return Promise.reject({ success: false, message: err.message || 'Client-side error updating assessments.', statusCode: 0 } as GenericMutationResponse);
    }
  }
  // TODO: Add similar methods for updateTopicNotes, updateTopicAssignments, updateTopicRevisionMaterials


  // --- Add MULTIPLE Topics to a specific Module (used by ModuleContentManagementPage) ---
  // This was in AdminSubjectService before, makes more sense here or in a dedicated AdminModuleService
  async addTopicsToModule(subjectId: string, moduleId: string, topicsPayload: TopicSimpleCreatePayload[]): Promise<BulkTopicAddResponse> {
    // Backend endpoint: POST /api/v1/admin/subjects/{subjectId}/modules/{moduleId}/topics/bulk-create
    const bulkAddTopicsEndpoint = `${this.subjectsApiUrl}/${subjectId}/modules/${moduleId}/topics/bulk-create`;
    console.log(`AdminTopicService: Bulk adding ${topicsPayload.length} topics to module ${moduleId} via ${bulkAddTopicsEndpoint}`);

    if (!topicsPayload || topicsPayload.length === 0) {
      return Promise.resolve({ success: true, message: "No topics provided.", statusCode: 200 });
    }
    try {
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      const rsaEncryptedValue = await this.encryptionService.encryptAesKeyBase64WithRsa(aesKeyBase64ForRsa, rsaPublicKeyCryptoKey);
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(topicsPayload, aesCryptoKey);
      const encryptedRequest: EncryptedGenericRequest = { encryptedAesKeyB64: rsaEncryptedValue, encryptedPayloadB64: aesEncryptedPayloadB64 };
      const headers = this.getAuthHeaders();

      return await firstValueFrom(
        this.http.post<BulkTopicAddResponse>(bulkAddTopicsEndpoint, encryptedRequest, { headers })
          .pipe(
            tap(res => console.log("AdminTopicService: Response from bulk add topics API:", res)),
            catchError(err => this.handleHttpError(err, `bulk add topics to module ${moduleId}`))
          )
      );
    } catch (error: any) { /* ... client-side error handling for bulk topic add ... */
        const err = error as Error;
        return Promise.reject({ success: false, message: err.message || 'Client-side error bulk adding topics.', statusCode: 0, data: {errors: []}} as BulkTopicAddResponse);
    }
  }

  // --- SIMULATION for fetching single topic with resources ---

}