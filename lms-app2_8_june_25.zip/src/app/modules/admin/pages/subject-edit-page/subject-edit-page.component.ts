import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormArray } from '@angular/forms';
import {
  Subject as RxJsSubject,
  Subscription,
  debounceTime,
  distinctUntilChanged,
  switchMap,
  map,
  filter,
  tap,
  catchError,
  of,
  from,
  startWith
} from 'rxjs';

import { AdminSubjectService } from '../../services/admin-subject.service';
import { SubjectDetailsBackend, SubjectUpdatePayload } from '../../models/subject.model';
import { MinimalCourseInfo } from '../../models/course.model';

@Component({
  selector: 'app-subject-edit-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './subject-edit-page.component.html',
})
export class SubjectEditPageComponent implements OnInit, OnDestroy {
  subjectId: string | null = null;
  subjectForm: FormGroup;
  currentSubject: SubjectDetailsBackend | null = null;
  isLoading = false;
  isFetchingDetails = true;
  errorMessage: string | null = null;

  courseSearchTerm$ = new RxJsSubject<string | null>();
  availableCoursesForSearch: MinimalCourseInfo[] = [];
  selectedCourses: MinimalCourseInfo[] = [];
  allSystemCourses: MinimalCourseInfo[] = [];
  showCourseDropdown = false;
  isLoadingCourses = false;

  private subscriptions = new Subscription();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    private adminSubjectService: AdminSubjectService
  ) {
    this.subjectForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required],
      assignedCourseIds: this.fb.array([])
    });
  }

  ngOnInit(): void {
    this.adminSubjectService.getCoursesForSelection().then(courses => {
      this.allSystemCourses = courses;
      const idParam = this.route.snapshot.paramMap.get('subjectId');
      if (idParam) {
        this.subjectId = idParam;
        this.loadSubjectDetails(); // This method call is what we are focusing on
      } else {
        this.errorMessage = "Subject ID not found in route.";
        this.isFetchingDetails = false;
      }
    }).catch(err => {
      console.error("Failed to load initial course list for dropdowns:", err);
      this.errorMessage = "Could not load necessary course data for editing.";
      this.isFetchingDetails = false;
    });

    this.subscriptions.add(
      this.courseSearchTerm$.pipe(
        startWith(''),
        debounceTime(300),
        distinctUntilChanged(),
        tap(() => this.isLoadingCourses = true),
        map((term: string | null) => {
          if (!term || term.trim() === '') {
            return this.allSystemCourses;
          }
          const lowerTerm = term.toLowerCase();
          return this.allSystemCourses.filter(c => c.name.toLowerCase().includes(lowerTerm));
        }),
        tap(() => this.isLoadingCourses = false)
      ).subscribe((filteredCourses: MinimalCourseInfo[]) => {
        this.availableCoursesForSearch = filteredCourses.filter(
          (ac: MinimalCourseInfo) => !this.selectedCourses.find(sc => sc._id === ac._id)
        );
        const courseSearchInputEl = document.getElementById('courseSearchEditInput') as HTMLInputElement;
        const currentSearchVal = courseSearchInputEl ? courseSearchInputEl.value : '';
        if (currentSearchVal && (this.availableCoursesForSearch.length > 0 || this.isLoadingCourses)) {
            this.showCourseDropdown = true;
        } else if (!currentSearchVal) {
             this.showCourseDropdown = false;
        } else if (currentSearchVal && this.availableCoursesForSearch.length === 0 && !this.isLoadingCourses) {
            this.showCourseDropdown = true;
        }
      })
    );
  }

  async loadSubjectDetails(): Promise<void> {
    if (!this.subjectId) return;
    this.isFetchingDetails = true;
    this.errorMessage = null;
    try {
      // vvvvvvvvvvvv CORRECT METHOD NAME HERE vvvvvvvvvvvvv
      const subject = await this.adminSubjectService.getSubjectDetailsWithNestedData(this.subjectId);
      // ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
      if (subject) {
        this.currentSubject = subject;
        this.subjectForm.patchValue({
          name: subject.SubjectName,
          description: subject.SubjectDescription,
        });

        this.selectedCourses = [];
        this.assignedCourseIdsFormArray.clear();

        // Ensure subject.AssociatedCourses exists and is an array of MinimalCourseInfo
        if (subject.AssociatedCourses && Array.isArray(subject.AssociatedCourses)) {
          (subject.AssociatedCourses as MinimalCourseInfo[]).forEach(courseInfo => {
            this.selectedCourses.push(courseInfo);
            this.assignedCourseIdsFormArray.push(this.fb.control(courseInfo._id));
          });
        }
        this.courseSearchTerm$.next((document.getElementById('courseSearchEditInput') as HTMLInputElement)?.value || '');
      } else {
        this.errorMessage = "Subject not found.";
      }
    } catch (error: any) {
      this.errorMessage = error.message || "Failed to load subject details.";
      console.error("Error loading subject details:", error);
    } finally {
      this.isFetchingDetails = false;
    }
  }

  // ... (rest of the component: f, assignedCourseIdsFormArray getters, onCourseSearch, selectCourse, removeSelectedCourse, onSubmit, onSearchFocus, onSearchBlur, ngOnDestroy) ...
  get f() { return this.subjectForm.controls; }
  get assignedCourseIdsFormArray() { return this.subjectForm.get('assignedCourseIds') as FormArray; }

  onCourseSearch(event: Event): void {
    const searchTerm = (event.target as HTMLInputElement).value;
    this.courseSearchTerm$.next(searchTerm);
  }

  selectCourse(course: MinimalCourseInfo, searchInput: HTMLInputElement): void {
    if (!this.selectedCourses.find(c => c._id === course._id)) {
      this.selectedCourses.push(course);
      this.assignedCourseIdsFormArray.push(this.fb.control(course._id));
      this.availableCoursesForSearch = this.availableCoursesForSearch.filter(ac => ac._id !== course._id);
    }
    searchInput.value = '';
    this.showCourseDropdown = false;
    this.courseSearchTerm$.next('');
  }

  removeSelectedCourse(courseToRemove: MinimalCourseInfo): void {
    this.selectedCourses = this.selectedCourses.filter(c => c._id !== courseToRemove._id);
    const index = this.assignedCourseIdsFormArray.controls.findIndex(control => control.value === courseToRemove._id);
    if (index > -1) {
      this.assignedCourseIdsFormArray.removeAt(index);
    }
    this.courseSearchTerm$.next((document.getElementById('courseSearchEditInput') as HTMLInputElement)?.value || '');
  }

  async onSubmit(): Promise<void> {
    if (this.subjectForm.invalid || !this.subjectId) {
      this.subjectForm.markAllAsTouched();
      return;
    }
    this.isLoading = true;
    this.errorMessage = null;

    const formValue = this.subjectForm.value;
    const updatePayload: SubjectUpdatePayload = {
      name: formValue.name,
      description: formValue.description,
      assignedCourseIds: formValue.assignedCourseIds
    };

    try {
      const response = await this.adminSubjectService.updateSubject(this.subjectId, updatePayload);
      if (response.success) {
        alert(response.message || 'Subject updated successfully!');
        this.router.navigate(['/admin/subjects']);
      } else {
        this.errorMessage = response.message || 'Failed to update subject.';
      }
    } catch (error: any) {
      this.errorMessage = error.message || 'An error occurred while updating the subject.';
    } finally {
      this.isLoading = false;
    }
  }

  onSearchFocus(): void {
    const courseSearchInputEl = document.getElementById('courseSearchEditInput') as HTMLInputElement;
    if ((courseSearchInputEl && courseSearchInputEl.value) || this.availableCoursesForSearch.length > 0) {
        this.showCourseDropdown = true;
    }
  }
  onSearchBlur(): void {
    setTimeout(() => {
      if (!document.activeElement?.closest('.subject-dropdown-list')) {
         this.showCourseDropdown = false;
      }
    }, 200);
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }
}