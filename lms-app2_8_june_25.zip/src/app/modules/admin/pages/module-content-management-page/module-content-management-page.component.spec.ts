import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModuleContentManagementPageComponent } from './module-content-management-page.component';

describe('ModuleContentManagementPageComponent', () => {
  let component: ModuleContentManagementPageComponent;
  let fixture: ComponentFixture<ModuleContentManagementPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ModuleContentManagementPageComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ModuleContentManagementPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
