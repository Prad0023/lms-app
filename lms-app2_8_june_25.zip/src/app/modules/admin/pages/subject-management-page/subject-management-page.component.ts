// src/app/modules/admin/pages/subject-management-page/subject-management-page.component.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { SubjectMutationResponse } from '../../models/subject.model'; // Assuming this is defined in subject.model.ts
import { AdminSubjectService } from '../../services/admin-subject.service';
import { SubjectListItem, SubjectDetailsBackend, SubjectBasicInfo } from '../../models/subject.model';
import { SubjectAddModalComponent } from '../../components/subject-add-modal/subject-add-modal.component';

@Component({
  selector: 'app-subject-management-page',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    SubjectAddModalComponent
  ],
  templateUrl: './subject-management-page.component.html',
})
export class SubjectManagementPageComponent implements OnInit {
  isAddSubjectModalOpen = false;
  subjects: SubjectListItem[] = [];
  isLoadingSubjects = false;
  isAddingSubject = false; // For the "Add Subject" operation
  errorMessage: string | null = null;
  filterForm: FormGroup;

  constructor(
    private router: Router,
    private adminSubjectService: AdminSubjectService,
    private fb: FormBuilder
  ) {
    this.filterForm = this.fb.group({
      searchTerm: [''],
    });
  }

  ngOnInit(): void {
    this.loadSubjects();
    this.filterForm.valueChanges.subscribe(() => {
      this.loadSubjects();
    });
  }

  async loadSubjects(): Promise<void> {
    this.isLoadingSubjects = true;
    this.errorMessage = null;
    try {
      const filters = this.filterForm.value;
      const subjectsFromBackend: SubjectDetailsBackend[] = await this.adminSubjectService.getSubjects(filters);

      this.subjects = subjectsFromBackend.map(sBackend => ({
        _id: sBackend._id,
        name: sBackend.SubjectName,
        description: (sBackend.SubjectDescription || '').substring(0, 100) + ((sBackend.SubjectDescription || '').length > 100 ? '...' : ''),
        courseCount: Array.isArray(sBackend.AssociatedCourses) ? sBackend.AssociatedCourses.length : 0,
        isActive: sBackend.is_active // Ensure SubjectDetailsBackend has is_active
      }));
    } catch (error: any) {
      this.errorMessage = error.message || 'Failed to load subjects.';
      console.error("Error loading subjects in SubjectManagementPage:", error);
    } finally {
      this.isLoadingSubjects = false;
    }
  }

  openAddSubjectModal(): void {
    this.isAddSubjectModalOpen = true;
  }

  closeAddSubjectModal(): void {
    this.isAddSubjectModalOpen = false;
  }

  async handleSubjectAdded(newSubjectData: SubjectBasicInfo): Promise<void> {
    console.log('SubjectManagementPage: Received new subject data from modal:', newSubjectData);
    this.isAddingSubject = true;
    this.errorMessage = null;

    try {
      const response: SubjectMutationResponse = await this.adminSubjectService.addSubject(newSubjectData);
      if (response.success) {
        alert(response.message || 'Subject added successfully!');
        this.loadSubjects(); // Refresh
      } else {
        this.errorMessage = response.message || 'Failed to add subject.';
        alert(this.errorMessage);
      }
    } catch (error: any) {
      const err = error as {message?: string};
      this.errorMessage = err.message || 'An unexpected error occurred.';
      alert(this.errorMessage);
    } finally {
      this.isAddingSubject = false;
      this.closeAddSubjectModal();
    }
  }

  viewSubjectDetails(subjectId: string): void {
    if (subjectId) this.router.navigate(['/admin/subjects', subjectId]);
  }

  editSubject(subjectId: string): void {
    if (subjectId) this.router.navigate(['/admin/subjects', subjectId, 'edit']);
  }
}