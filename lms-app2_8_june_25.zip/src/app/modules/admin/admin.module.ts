import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { ModuleContentManagementPageComponent } from './pages/module-content-management-page/module-content-management-page.component';

// Import Standalone Page Components
import { AdminDashboardPageComponent } from './pages/admin-dashboard-page/admin-dashboard-page.component';
// Import other admin page/components as needed
import { TeacherHireModalComponent } from './components/teacher-hire-modal/teacher-hire-modal.component';
import { TeacherManagementPageComponent } from './pages/teacher-management-page/teacher-management-page.component';
import { ReactiveFormsModule } from '@angular/forms'; // For reactive forms in modals
import { TeacherMailPreviewPageComponent } from './pages/teacher-mail-preview-page/teacher-mail-preview-page.component';
import { StudentManagementPageComponent } from './pages/student-management-page/student-management-page.component';
import { StudentEnrollModalComponent } from './components/student-enroll-modal/student-enroll-modal.component';
import { StudentMailPreviewPageComponent } from './pages/student-mail-preview-page/student-mail-preview-page.component'; // <<< ADD THIS
import { CourseManagementPageComponent } from './pages/course-management-page/course-management-page.component';
import { CourseAddModalComponent } from './components/course-add-modal/course-add-modal.component';
import { CourseDetailPageComponent } from './pages/course-detail-page/course-detail-page.component';
import { SubjectManagementPageComponent } from './pages/subject-management-page/subject-management-page.component';
import { SubjectAddModalComponent } from './components/subject-add-modal/subject-add-modal.component';
import { SubjectEditPageComponent } from './pages/subject-edit-page/subject-edit-page.component';

import { SubjectModuleAddComponent } from './components/subject-module-add-modal/subject-module-add-modal.component';
import { TopicResourceModalComponent } from './components/topic-resource-modal/topic-resource-modal.component';

@NgModule({
  declarations: [
    // Declare non-standalone components here
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    ReactiveFormsModule,
    // Import standalone components routed to by AdminRoutingModule
    AdminDashboardPageComponent, // Assuming it's standalone
    TeacherManagementPageComponent,
    TeacherHireModalComponent,   
    TeacherMailPreviewPageComponent, 
    StudentManagementPageComponent,
    StudentEnrollModalComponent,
    StudentMailPreviewPageComponent,
    CourseManagementPageComponent,
    CourseAddModalComponent,
    CourseDetailPageComponent,
    SubjectManagementPageComponent,
    SubjectAddModalComponent,
    SubjectEditPageComponent,
    SubjectModuleAddComponent,
    ModuleContentManagementPageComponent,
    TopicResourceModalComponent
  ]
})
export class AdminModule { }