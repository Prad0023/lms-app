import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TopicResourceModalComponent } from './topic-resource-modal.component';

describe('TopicResourceModalComponent', () => {
  let component: TopicResourceModalComponent;
  let fixture: ComponentFixture<TopicResourceModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TopicResourceModalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TopicResourceModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
