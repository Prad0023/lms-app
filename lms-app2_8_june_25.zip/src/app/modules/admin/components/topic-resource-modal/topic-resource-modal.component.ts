import { Component, EventEmitter, Input, OnInit, Output, OnChanges, SimpleChanges, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; // Needed for [(ngModel)]

// Import necessary models from topic.model.ts
import {
  AssessmentItem,
  McqQuestionData, // If used directly, or it's part of AssessmentItem
  TopicNote,
  TopicAssignment,
  TopicRevisionMaterial
} from '../../models/topic.model';
@Component({
  selector: 'app-topic-resource-modal',
  standalone: true,
  imports: [CommonModule, FormsModule], // FormsModule is important for [(ngModel)]
  templateUrl: './topic-resource-modal.component.html',
})
export class TopicResourceModalComponent implements OnInit, OnChanges {
  @Input() topicName!: string; // Input for displaying topic name in modal
  @Input() resourceType!: 'Assessments' | 'Notes' | 'Assignments' | 'Revision' | null;
  @Input() existingResources: any[] = []; // Input: current resources for the topic

  @Output() closeModal = new EventEmitter<void>();
  @Output() saveResources = new EventEmitter<any[]>(); // Emits the updated array

  isLoading = false; // For save button
  resourcesToEdit: any[] = []; // Internal mutable copy of resources

  // For Assessment JSON Upload/Edit (as per your HTML template)
  assessmentJsonString: string = '';
  jsonParseError: string | null = null;
  jsonFileName: string | null = null; // Property for uploaded JSON file name
  @ViewChild('assessmentJsonFileInpt') assessmentJsonFileInputRef!: ElementRef<HTMLInputElement>;


  constructor() {}

  ngOnInit(): void {
    this.initializeResources();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['existingResources'] || changes['resourceType']) {
      this.initializeResources();
    }
  }

  private initializeResources(): void {
    // Deep copy for safe editing
    this.resourcesToEdit = this.existingResources ? JSON.parse(JSON.stringify(this.existingResources)) : [];
    console.log(`TopicResourceModal: Initialized for ${this.resourceType} with resources:`, this.resourcesToEdit);

    if (this.resourceType === 'Assessments') {
      this.assessmentJsonString = JSON.stringify(this.resourcesToEdit, null, 2);
      this.jsonParseError = null;
    }
  }

  // --- Specific for Assessments (JSON handling, as per your HTML) ---
  onAssessmentJsonChange(): void {
    this.jsonParseError = null;
    try {
      const parsed = JSON.parse(this.assessmentJsonString);
      // TODO: Add more robust validation for AssessmentItem[] structure
      if (!Array.isArray(parsed)) {
          throw new Error("JSON must be an array of assessment items.");
      }
      // Add further checks for each item in 'parsed' to see if it looks like AssessmentItem
      this.resourcesToEdit = parsed;
      console.log("Valid JSON for assessments parsed:", this.resourcesToEdit);
    } catch (e: any) {
      this.jsonParseError = `Invalid JSON: ${e.message || 'Unknown parsing error.'}`;
      console.error("JSON Parse Error for Assessments:", e);
    }
  }

  onAssessmentFileSelected(event: Event): void { // <<< ADDED THIS METHOD
    const fileInput = event.target as HTMLInputElement;
    if (fileInput.files && fileInput.files.length > 0) {
      const file = fileInput.files[0];
      this.jsonFileName = file.name;
      this.jsonParseError = null;
      this.assessmentJsonString = ''; // Clear textarea if file is selected
      this.resourcesToEdit = [];    // Clear current edits

      if (file.type === "application/json") {
        const reader = new FileReader();
        reader.onload = (e) => {
          try {
            const jsonContent = e.target?.result as string;
            // Attempt to parse and immediately put into textarea for further editing/validation by onAssessmentJsonChange
            JSON.parse(jsonContent); // Just to validate it's JSON initially
            this.assessmentJsonString = jsonContent; // Load into textarea
            this.onAssessmentJsonChange(); // Trigger parsing and update of resourcesToEdit
            if(this.jsonParseError) { // if onAssessmentJsonChange found errors
                 this.jsonFileName = null; // Clear filename on error
                 if(this.assessmentJsonFileInputRef) this.assessmentJsonFileInputRef.nativeElement.value = '';
            }
          } catch (error: any) {
            this.jsonParseError = `Error parsing uploaded JSON: ${error.message || 'Invalid JSON format.'}`;
            this.clearAssessmentJsonFile();
          }
        };
        reader.onerror = () => {
            this.jsonParseError = "Error reading the selected file.";
            this.clearAssessmentJsonFile();
        };
        reader.readAsText(file);
      } else {
        this.jsonParseError = "Invalid file type. Please upload a .json file.";
        this.clearAssessmentJsonFile();
      }
    }
  }

  clearAssessmentJsonFile(): void { // <<< ADDED THIS METHOD
    this.jsonFileName = null;
    this.jsonParseError = null; // Also clear parse error related to the file
    if (this.assessmentJsonFileInputRef) {
      this.assessmentJsonFileInputRef.nativeElement.value = '';
    }
    // Decide if you want to reset assessmentJsonString and resourcesToEdit here
    // this.assessmentJsonString = JSON.stringify(this.existingResources.filter(r=>r.type==='assessment'), null, 2) ; // Revert to original for assessments
    // this.initializeResources(); // This will revert to original existingResources
  }

  downloadAssessmentDemoJson(): void { // Renamed slightly for clarity
    const demoAssessmentData: AssessmentItem[] = [
        { /* ... your example AssessmentItem structure ... */
            id: "mcq_demo_001", type: "mcq", title: "Sample Variables MCQ",
            instruction: "Choose the correct answer.", timeLimit: 5,
            questions: [ { id: "q_demo_1", question: "Demo Python int variable?",
                options: [{text:"int x=5", isCorrect:false}, {text:"x=5",isCorrect:true}], correctAnswerIndex:1, explanation:"..." } ]
        },
        {
            id: "story_builder_demo_001", type: "code_story_builder", title: "Demo Morning Routine",
            instruction: "Arrange code blocks.", timeLimit: 8,
            exercises: [ { id: "sb_demo_1", scenario: "Demo Scenario", storyContext: "Context",
                           codeBlocks: [{id:"cb1", code:"print('Hello')", description:"Greet"}], correctOrder:["cb1"], explanation:"..."}]
        }
    ];
    const jsonString = JSON.stringify(demoAssessmentData, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a');
    a.href = url; a.download = `demo-assessments-template.json`;
    document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
  }
  // --- End Assessments ---


  // --- Placeholder for adding individual resource items (Notes, Assignments etc.) ---
  addResourceItem(type: 'Notes' | 'Assignments' | 'Revision'): void { // <<< ADDED THIS METHOD
    console.log(`Add new item of type: ${type}`);
    // This is highly dependent on the structure of each resource type
    // For now, let's just push a generic placeholder if needed, or open another form.
    if (type === 'Notes') {
      this.resourcesToEdit.push({ title: 'New Note', content: '' } as TopicNote);
    }
    // Implement similar for Assignments and Revision
  }


  // --- Generic Save/Cancel ---
  onSave(): void {
    if (this.resourceType === 'Assessments' && this.jsonParseError) {
      alert("Cannot save: Invalid JSON format for assessments. Please correct the errors.");
      return;
    }
    this.isLoading = true; // For save button
    console.log(`TopicResourceModal: Emitting saveResources for ${this.resourceType}`, this.resourcesToEdit);
    this.saveResources.emit(this.resourcesToEdit);
    // The parent component (ModuleContentManagementPage) will handle the actual API call
    // and then close this modal by setting isResourceModalOpen = false on the parent.
    // It will also set parent's isLoadingPage to false.
    // So, this modal can reset its own isLoading state after emitting.
    // this.isLoading = false; // Parent controls overall flow; modal just emits.
  }

  onCancel(): void {
    this.closeModal.emit();
  }
}