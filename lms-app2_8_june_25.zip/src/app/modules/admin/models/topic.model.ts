// src/app/modules/admin/models/topic.model.ts OR can be added to subject.model.ts

import { TopicDetailsBackendNested,EncryptedGenericRequest } from "./subject.model";

// Interface for the resource types within a topic
export interface McqQuestion {
  _id?: string; // Optional if new
  questionText: string;
  options: { text: string; isCorrect: boolean }[];
  explanation?: string;
}

export interface InterviewQuestion {
  _id?: string; // Optional if new
  question: string;
  answer?: string; // Admin might provide an ideal answer
  keywords?: string[];
  difficulty?: 'Easy' | 'Medium' | 'Hard';
}

export interface TopicNote {
  _id?: string; // Optional if new
  title?: string;
  content: string; // Could be Markdown, HTML, or plain text
  order?: number;
}

export interface PracticeSession { // This is very conceptual, depends on what a "session" entails
    _id?: string;
    title: string;
    description?: string;
    type: 'coding_challenge' | 'simulation' | 'interactive_exercise';
    instructions?: string;
    session_data?: any; // Could be link to external tool, embedded content, or structured data
}

// More comprehensive Topic structure for when we manage its content
export interface TopicFullDetailsFE {
  _id: string;
  topicName: string;
  moduleName?: string; // For context
  subjectName?: string; // For context
  topicVideos?: string[];
  topicContent?: string;
  sequenceOrder?: number;
  isActive?: boolean;
  mcqs?: McqQuestion[];
  interviewQuestions?: InterviewQuestion[];
  notes?: TopicNote[];
  practiceSessions?: PracticeSession[];
}

// The structure your backend provides for a single topic with all its resources
export interface TopicDetailsWithResourcesBackend {
  _id: string;
  TopicName: string;
  ModuleID: string;
  TopicVideos?: string[];
  TopicContent?: string;
  sequence_order?: number;
  is_active?: boolean;
  created_by?: { _id: string; full_name: string; email: string }; // CreatedByInfo
  CreatedAt?: string;
  UpdatedAt?: string;
  MCQs?: McqQuestion[]; // From your questions collection, filtered by this TopicID
  InterviewQuestions?: InterviewQuestion[]; // From your questions collection, filtered/typed differently
  Notes?: TopicNote[]; // From a new "notes" collection or embedded
  PracticeSessions?: PracticeSession[]; // From a new "practice_sessions" collection or embedded
}

export interface TopicBasicInfo {
  topicName: string;
  topicVideos?: string[];
  topicContent?: string;
  sequenceOrder?: number;
  // ModuleID will be part of the URL or main payload if not nested
}

export interface TopicSimpleCreatePayload {
  topicName: string;
  // topicContent?: string; // Optional: from form
  // topicVideos?: string[]; // Optional: from form
  // sequenceOrder?: number; // Optional: frontend might calculate or backend assigns
}

// Payload for BULK adding topics to a module
export interface BulkTopicAddPayload {
  moduleId: string; // The ID of the module these topics belong to
  subjectId: string; // The ID of the parent subject (for endpoint construction or backend verification)
  topics: TopicSimpleCreatePayload[]; // Array of topics to create
}

// Response from backend after bulk adding topics
export interface BulkTopicAddResponse {
  success: boolean;
  message: string;
  statusCode?: number;
  data?: {
    createdTopicsCount?: number;
    createdTopicIds?: string[]; // IDs of successfully created topics
    errors?: { topicNameAttempted: string, error: string }[]; // For partial success/failure
  };
}

// Response for adding/mutating a SINGLE topic (if you keep that separate)
export interface TopicMutationResponse { // Can be generic
  success: boolean;
  message: string;
  data?: TopicDetailsBackendNested; // The created/updated topic
  statusCode?: number;
}

// src/app/modules/admin/models/topic.model.ts (or combine in subject.model.ts)

// --- Assessment Structures (from your JSON example) ---
export interface McqOption {
  text: string; // Changed from your example's direct array of strings for options to allow {text, isCorrect}
  isCorrect: boolean;
}
export interface McqQuestionData {
  id: string;
  question: string;
  code?: string;
  options: McqOption[]; // Changed to array of McqOption
  correctAnswerIndex: number; // Changed from correctAnswer which was the index
  explanation?: string;
}
export interface CodeStoryBuilderExercise {
  id: string;
  scenario: string;
  storyContext: string;
  codeBlocks: { id: string; code: string; description: string }[];
  correctOrder: string[];
  explanation?: string;
}
export interface CodeDetectiveMysterySuspect {
    id: string;
    code: string;
    description: string;
}
export interface CodeDetectiveMystery {
    id: string;
    mysteryOutput: string;
    clue: string;
    suspects: CodeDetectiveMysterySuspect[];
    correctSuspect: string; // ID of the correct suspect
    explanation?: string;
}
export interface CodeRecipeCardIngredient {
    id: string;
    name: string;
    type: string;
    description: string;
}
export interface CodeRecipeCardStep {
    id: string;
    action: string;
    description: string;
}
export interface CodeRecipeCardRecipe {
    id: string;
    dishName: string;
    description: string;
    ingredients: CodeRecipeCardIngredient[];
    cookingSteps: CodeRecipeCardStep[];
    finalDish: string;
    correctMatching?: { [ingredientId: string]: string }; // ingredientId maps to stepId
}
export interface CodeCharadesChallenge {
    id: string;
    code: string;
    difficulty: string;
    hints: string[];
    acceptableAnswers: string[]; // Keywords or phrases
    sampleAnswer: string;
}
export interface AssessmentItem {
  id: string; // e.g., "mcq_001", "story_builder_001"
  type: 'mcq' | 'code_story_builder' | 'code_detective' | 'code_recipe_cards' | 'code_charades' | string; // Add more types as needed
  title: string;
  instruction?: string;
  timeLimit?: number; // in minutes
  questions?: McqQuestionData[]; // For 'mcq' type
  exercises?: CodeStoryBuilderExercise[]; // For 'code_story_builder' type
  mysteries?: CodeDetectiveMystery[]; // For 'code_detective'
  recipes?: CodeRecipeCardRecipe[]; // For 'code_recipe_cards'
  challenges?: CodeCharadesChallenge[]; // For 'code_charades'
}
// This is the structure we'll use for managing a Topic's detailed content
export interface TopicResourceManagementFE {
  _id: string;
  topicName: string;
  // Arrays for each resource type
  assessments: AssessmentItem[];
  notes: any[]; // Define TopicNote interface later
  assignments: any[]; // Define Assignment interface later
  revisionMaterials: any[]; // Define RevisionMaterial interface later
}
// ----- For new Topic Creation ------
// From subject.model.ts - what the basic topic creation form provides
export interface TopicSimpleCreatePayload {
  topicName: string;
  // Potentially other simple fields:
  // topicContent?: string;
  // sequenceOrder?: number;
}
// --- Backend Data Structures (What backend sends for a topic's details including resources) ---
export interface TopicDetailsWithResourcesBackend { // Matches TopicFullDetailsFE from before
  _id: string;
  TopicName: string;
  ModuleID: string;
  TopicVideos?: string[];
  TopicContent?: string;
  sequence_order?: number;
  is_active?: boolean;
  created_by?: { _id: string; full_name: string; email: string };
  CreatedAt?: string;
  UpdatedAt?: string;
  // The backend now needs to populate these resource arrays.
  // The structure within each array should match the *backend's representation*
  // which might be slightly different from AssessmentItem (e.g., 'correctAnswer' vs 'correctAnswerIndex')
  Assessments?: any[]; // Array of raw assessment objects from DB
  Notes?: TopicNote[] | undefined;       // Array of raw note objects from DB
  Assignments?: any[];   // Array of raw assignment objects from DB
  RevisionMaterials?: any[]; // Array of raw revision objects from DB
}


export interface TopicAssignment { // Ensure EXPORTED
  _id?: string;
  title: string;
  description?: string;
  dueDate?: string;
  fileUrl?: string;
}

export interface TopicRevisionMaterial { // Ensure EXPORTED
  _id?: string;
  title: string;
  type: 'link' | 'document' | 'video_summary';
  urlOrContent: string;
}

// --- Topic Structures ---
export interface TopicSimpleCreatePayload {
  topicName: string;
  // topicContent?: string;
  // sequenceOrder?: number;
}

// For API response fetching a single topic with resources
export interface FetchSingleTopicWithResourcesApiResponse { // Ensure EXPORTED
  success: boolean;
  statusCode: number;
  data?: EncryptedGenericRequest; // Where data.encryptedData contains ONE TopicDetailsWithResourcesBackend object
  message: string;
}