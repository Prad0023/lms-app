// src/app/modules/admin/models/student.model.ts

// Interface for the data admin initially provides to enroll/invite a student
export interface StudentBasicEnrollInfo {
  fullName: string;
  email: string;
  mobile?: string;        // Optional
  course?: string;        // Changed from designation, make it optional or required as needed
                           // This could be a course name (string) or later a course ID
}

// Interface for the raw data structure coming from the backend after decryption
export interface StudentDetailsBackend {
  _id: string;
  email: string;
  mobile_number?: string;
  full_name: string;
  email_verified: boolean;
  mobile_verified?: boolean;
  is_active: boolean;
  created_by?: string;
  roles: { role_id: string }[];
  created_at: string;
  updated_at: string;
  __v?: number;
  enrollment_status?: 'pending_payment' | 'enrolled' | 'suspended' | 'completed_profile' | string;
  // Fields that might come from backend (make them optional if not guaranteed)
  course_info?: string; // If backend sends course info associated with the student
  date_of_birth?: string;
  parent_guardian_name?: string;
  current_grade_level?: string;
  enrolled_courses?: { course_id: string, course_name: string }[];
}

// Interface for the frontend representation (View Model)
export interface StudentDetailsFE {
  _id: string;
  fullName: string;
  email: string;
  mobile: string; // Will have 'N/A' default
  status: 'Pending Payment' | 'Enrolled' | 'Suspended' | 'Profile Complete' | 'Unknown' | string;
  isActive: boolean;
  course?: string; // To display in the table, with 'N/A' default
  enrolledCourseCount?: number;
  // Add other fields as needed for the view
}


// For the API response containing encrypted data
// (Can be reused from teacher.model.ts or a generic model if identical)
export interface EncryptedListPayload {
  responseAesKeyB64: string;
  encryptedData: string;
}

export interface FetchStudentsApiResponse {
  success: boolean;
  statusCode: number;
  data?: EncryptedListPayload;
  message: string;
}