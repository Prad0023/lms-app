import mongoose from 'mongoose';

const topicSchema = new mongoose.Schema({
    TopicName: { type: String, required: true, trim: true },
    ModuleID: { type: mongoose.Schema.Types.ObjectId, ref: 'Module', required: true, index: true },
    // TopicAssignments: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Assignment' }],
    // TopicGames: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Game' }],
    TopicVideos: [{ type: String, trim: true }], // Array of video URLs or IDs
    TopicContent: { type: String }, // Could be HTML, Markdown, or plain text
    sequence_order: { type: Number, default: 0 }, // For ordering topics within a module
    is_active: { type: Boolean, default: true },
    created_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
}, { timestamps: { createdAt: 'CreatedAt', updatedAt: 'UpdatedAt' } });

topicSchema.index({ ModuleID: 1, TopicName: 1 });

const Topic = mongoose.model('Topic', topicSchema);
export default Topic;