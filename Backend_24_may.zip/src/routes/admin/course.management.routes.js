// src/routes/admin/course.management.routes.js
import { Router } from 'express';
import { courseController } from '../../controllers/course/course.controller.js'; // Adjust path
import { protect } from '../../middlewares/auth.middleware.js';
import { authorizePermission } from '../../middlewares/role.middleware.js';

const router = Router();

/**
 * @route   POST /api/v1/admin/courses/create
 * @desc    Admin creates a new course.
 *          Encrypted Payload: { name, description, subjectIds, ... }
 * @access  Private (Admin with 'course_create' permission)
 */
router.post(
    '/create',
    protect,
    authorizePermission('course', 'create'), // Ensure admin role has this permission
    courseController.createCourse
);

/**
 * @route   GET /api/v1/admin/courses/view-all
 * @desc    Admin views all courses (response is encrypted).
 * @access  Private (Admin with 'course_read_all' permission)
 */
router.get(
    '/view-courses',
    protect,
    authorizePermission('course', 'read_all'), // Ensure admin role has this permission
    courseController.getAllCourses
);

// Other routes: /:courseId (GET), /:courseId (PUT), /:courseId (DELETE)
// /:courseId/subjects (POST to add subject, DELETE to remove)

export default router;