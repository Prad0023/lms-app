// src/services/subject/subject.service.js
import Subject from '../../models/subject.model.js';
import Course from '../../models/course.model.js'; // Needed if assigning to courses immediately
import { ApiError } from '../../utils/apiResponse.utils.js';
import { logAuditEvent } from '../common/audit.service.js'; // Assuming path

export const subjectService = {
    createSubject: async (subjectInputData, adminUserId) => {
        const {
            SubjectName,
            SubjectDescription,
            SubjectCredits,
            SubjectLevel,
            SubjectType,
            assignedCourseIds, // Expecting this from the controller now
            // ... other subject fields
        } = subjectInputData;

        if (!SubjectName) {
            throw new ApiError(400, 'SubjectName is required.');
        }

        const existingSubject = await Subject.findOne({ SubjectName });
        if (existingSubject) {
            throw new ApiError(409, `Subject with name '${SubjectName}' already exists.`);
        }

        // Validate provided course IDs if any
        let validCourseObjectIds = [];
        if (assignedCourseIds && assignedCourseIds.length > 0) {
            // Ensure IDs are valid MongoDB ObjectIds
            try {
                validCourseObjectIds = assignedCourseIds.map(id => new mongoose.Types.ObjectId(id));
            } catch (e) {
                throw new ApiError(400, 'One or more assignedCourseIds are not valid ObjectIds.');
            }

            const coursesExist = await Course.find({ '_id': { $in: validCourseObjectIds } }).select('_id');
            if (coursesExist.length !== validCourseObjectIds.length) {
                // Find which IDs are invalid
                const existingCourseIdsSet = new Set(coursesExist.map(c => c._id.toString()));
                const invalidIds = assignedCourseIds.filter(id => !existingCourseIdsSet.has(id));
                throw new ApiError(400, `One or more assigned courses do not exist. Invalid IDs: ${invalidIds.join(', ')}`);
            }
        }

        // Create the new subject
        const newSubject = new Subject({
            SubjectName,
            SubjectDescription,
            SubjectCredits,
            SubjectLevel,
            SubjectType,
            AssociatedCourses: validCourseObjectIds, // Store valid course ObjectIds
            created_by: adminUserId,
        });

        await newSubject.save(); // Save the new subject to get its _id

        // If there are courses to associate, update them
        if (validCourseObjectIds.length > 0) {
            try {
                const courseUpdateResult = await Course.updateMany(
                    { _id: { $in: validCourseObjectIds } },
                    { $addToSet: { CourseSubjects: newSubject._id } } // Add new subject's ID to each course
                );
                console.log(`[SubjectService] Updated ${courseUpdateResult.modifiedCount} courses to include subject ${newSubject._id}`);
            } catch (courseUpdateError) {
                console.error(`[SubjectService] Error updating courses with new subject ${newSubject._id}:`, courseUpdateError);
                // This is a tricky situation. The subject is created, but linking failed.
                // For now, we'll log and proceed. Could implement rollback or a retry mechanism.
                // Or, make it transactional if your MongoDB setup supports it (replica sets).
                // For now, let the subject creation be the primary success.
                // The admin might need to manually link later or we provide a repair tool.
            }
        }

        await logAuditEvent({
            userId: adminUserId,
            event_type: 'subject_management',
            resource: 'subjects',
            resource_id: newSubject._id,
            action: 'create',
            status: 'success',
            details: {
                subject_name: newSubject.SubjectName,
                associated_courses_count: validCourseObjectIds.length
            }
        });

        // Populate for response (optional, but good to show what was done)
        await newSubject.populate({ path: 'AssociatedCourses', select: 'CourseName _id' });
        await newSubject.populate({ path: 'created_by', select: 'full_name email' });


        return newSubject;
    },

    
    getAllSubjects: async () => {
        const subjects = await Subject.find({})
            .populate({ path: 'created_by', select: 'full_name email _id' })
            // Add other populates if needed (e.g., SubjectInstructor)
            .sort({ CreatedAt: -1 });
        return subjects;
    }
    // ... other subject service methods (getById, update, delete)
};