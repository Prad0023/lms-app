// src/services/course/course.service.js
import Course from '../../models/course.model.js';
import Subject from '../../models/subject.model.js'; // For populating subject names
import { ApiError } from '../../utils/apiResponse.utils.js';
import { logAuditEvent } from '../common/audit.service.js'; // Assuming path
import { v4 as uuidv4 } from 'uuid';

export const courseService = {
    createCourse: async (courseData, adminUserId) => {
        // Destructure what you know won't change or what you'll use directly
        const {
            CourseName,
            CourseDescription,
            // course_code, // Remove from const destructuring if you might modify it
            Credits,
            CourseLevel,
            CourseType,
            subjectIds,
        } = courseData;

        // Declare course_code with let so it can be reassigned
        let effective_course_code = courseData.course_code; // Get initial value

        if (!effective_course_code) { // Check the mutable variable
            effective_course_code = `COURSE-${uuidv4().slice(0, 8).toUpperCase()}`;
            console.log(`[CourseService] Generated course_code: ${effective_course_code} for course: ${CourseName}`); // Use CourseName from destructuring
        }

        // Validate if subjectIds are valid (this part was fine)
        if (subjectIds && subjectIds.length > 0) {
            const validSubjects = await Subject.find({ '_id': { $in: subjectIds } }).select('_id');
            if (validSubjects.length !== subjectIds.length) {
                throw new ApiError(400, 'One or more provided subject IDs are invalid or do not exist.');
            }
        }
        
        // Check if course with the same name or code already exists
        if (CourseName) {
            const existingCourseByName = await Course.findOne({ CourseName });
            if (existingCourseByName) {
                throw new ApiError(409, `Course with name '${CourseName}' already exists.`);
            }
        }
        // Use the potentially modified 'effective_course_code' for checks and saving
        if (effective_course_code) { // Check if it's not null/undefined before querying
            const existingCourseByCode = await Course.findOne({ course_code: effective_course_code });
            if (existingCourseByCode) {
                throw new ApiError(409, `Course with code '${effective_course_code}' already exists.`);
            }
        }

        const newCourse = new Course({
            CourseName,
            CourseDescription,
            course_code: effective_course_code, // Use the final value
            Credits,
            CourseLevel,
            CourseType,
            CourseSubjects: subjectIds || [],
            created_by: adminUserId,
            is_published: false,
        });

        await newCourse.save();

        // Populate details (this part was fine)
        await newCourse.populate({
            path: 'CourseSubjects',
            select: 'SubjectName SubjectDescription'
        });
        await newCourse.populate({ path: 'created_by', select: 'full_name email' });

        await logAuditEvent({
            userId: adminUserId,
            event_type: 'course_management',
            resource: 'courses',
            resource_id: newCourse._id,
            action: 'create',
            status: 'success',
            details: { course_name: newCourse.CourseName, course_code: newCourse.course_code } // Log the actual code used
        });

        return newCourse;
    },  

    getAllCourses: async () => {
        const courses = await Course.find({})
            .populate({
                path: 'CourseSubjects', // Populate actual subject documents
                select: 'SubjectName SubjectDescription _id' // Select specific fields from Subject
            })
            .populate({
                path: 'CourseInstructor', // Populate instructor details
                select: 'full_name email _id' // Select specific fields from User (Teacher)
            })
            .populate({
                path: 'created_by',
                select: 'full_name email _id'
            })
            .sort({ CreatedAt: -1 });
        return courses;
    },

    // getCourseById: async (courseId) => { ... }
    // updateCourse: async (courseId, updateData, adminUserId) => { ... }
    // deleteCourse: async (courseId, adminUserId) => { ... }
    // addSubjectToCourse: async (courseId, subjectId, adminUserId) => { ... }
    // removeSubjectFromCourse: async (courseId, subjectId, adminUserId) => { ... }
};