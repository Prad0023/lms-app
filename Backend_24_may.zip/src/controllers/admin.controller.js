// src/controllers/admin.controller.js
import asyncHandler from '../utils/asyncHandler.utils.js';
import { ApiResponse, ApiError } from '../utils/apiResponse.utils.js';
import { teacherService } from '../services/teacher.service.js';
import {
    decryptAesKeyWithRsa,
    decryptPayloadWithAesGcm
} from '../utils/crypto.utils.js';
import cryptoNode from 'crypto'; // For generating the response AES key
import {encryptPayloadWithAesGcm} from '../utils/crypto.utils.js';



export const adminController = {
    initiateTeacherHire: asyncHandler(async (req, res) => {
        const { encryptedAesKeyB64, encryptedPayloadB64 } = req.body;

        // console.log('[Controller] Received encryptedAesKeyB64 for hire:', encryptedAesKeyB64 ? 'Exists' : 'Missing');
        // console.log('[Controller] Received encryptedPayloadB64 for hire:', encryptedPayloadB64 ? 'Exists' : 'Missing');

        if (!encryptedAesKeyB64 || !encryptedPayloadB64) {
            throw new ApiError(400, 'Encrypted AES key and payload are required for hiring.');
        }

        let aesKeyBuffer;
        try {
            aesKeyBuffer = decryptAesKeyWithRsa(encryptedAesKeyB64);
        } catch (rsaError) {
            // console.error('[Controller] Error during RSA decryption of AES key for hire:', rsaError.message);
            throw rsaError; // Re-throw, asyncHandler will catch it
        }

        if (typeof aesKeyBuffer === 'undefined') { // Should not happen if decryptAesKeyWithRsa throws on error
            // console.error('[Controller] CRITICAL: aesKeyBuffer is undefined AFTER RSA decryption for hire.');
            throw new ApiError(500, 'Internal server error: AES key became undefined unexpectedly during hire.');
        }
        
        let decryptedHireRequestData;
        try {
            decryptedHireRequestData = decryptPayloadWithAesGcm(encryptedPayloadB64, aesKeyBuffer);
        } catch (aesError) {
            // console.error('[Controller] Error during AES decryption of payload for hire:', aesError.message);
            throw aesError; // Re-throw
        }
        
        // decryptedHireRequestData should be { teacherInfo: { ... }, sendEmail: true/false }
        if (!decryptedHireRequestData || !decryptedHireRequestData.teacherInfo || typeof decryptedHireRequestData.sendEmail === 'undefined') {
            throw new ApiError(400, 'Decrypted payload for teacher hire is malformed or missing teacherInfo/sendEmail field.');
        }

        const adminUserId = req.user.id;
        const ipAddress = req.ip;
        const userAgent = req.headers['user-agent'];

        // Pass the whole decrypted object to the service
        const result = await teacherService.initiateTeacherHiring(
            decryptedHireRequestData,
            adminUserId,
            ipAddress,
            userAgent
        );

        res.status(201).json(new ApiResponse(201, result, result.message));
    }),



    // ... (initiateTeacherHire)

    viewAllTeachers: asyncHandler(async (req, res) => {
        // console.log('[AdminController] viewAllTeachers called by user:', req.user.id);

        const teachers = await teacherService.getAllTeachers();

        if (!teachers || teachers.length === 0) {
            return res.status(200).json(new ApiResponse(200, [], 'No teachers found.'));
        }

        // --- Encrypt the response ---
        // 1. Generate a new temporary AES key for this response
        const responseAesKeyBuffer = cryptoNode.randomBytes(32); // 32 bytes for AES-256

        // 2. Encrypt the teacher data with this AES key
        const encryptedTeachersDataB64 = encryptPayloadWithAesGcm(teachers, responseAesKeyBuffer);

        // 3. Prepare the response
        // **WARNING: Sending the AES key in plaintext like this is INSECURE for the key itself without HTTPS.**
        // **In a real robust system, this responseAesKeyBuffer would be encrypted using a pre-exchanged
        // client public key or a derived session key.**
        // For this example, we send it alongside, assuming HTTPS protects it in transit.
        const responsePayload = {
            responseAesKeyB64: responseAesKeyBuffer.toString('base64'), // Key for client to decrypt
            encryptedData: encryptedTeachersDataB64                     // Encrypted teacher list
        };

        // console.log('[AdminController] Sending encrypted teacher list.');
        res.status(200).json(new ApiResponse(200, responsePayload, 'Teachers list retrieved and encrypted.'));
    }),

    // ... other admin controllers
};