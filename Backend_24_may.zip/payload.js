
import forge from 'node-forge';
import axios from 'axios'; // Make sure you have axios installed

// Function to get the server's public key
async function fetchPublicKey() {
  console.log('Fetching RSA public key from http://localhost:5000/api/v1/auth/public-key ...');
  try {
    const response = await axios.get('http://localhost:5000/api/v1/auth/public-key');
    console.log('Successfully fetched RSA public key.');
    return response.data.data.publicKey;
  } catch (error) {
    console.error('Failed to fetch public key:', error.message);
    throw error;
  }
}

// Function to encrypt login credentials
async function encryptLoginCredentials(email, password) {
  // Fetch the public key
  const publicKeyPem = await fetchPublicKey();
  
  // Parse the PEM format public key
  const publicKey = forge.pki.publicKeyFromPem(publicKeyPem);
  
  // Generate a random AES key
  const aesKey = forge.random.getBytesSync(32); // 256 bits
  
  // Convert credential to JSON and then to bytes
  const credentialsJson = JSON.stringify({ email, password });
  const credentialsBytes = forge.util.encodeUtf8(credentialsJson);
  
  // Generate random IV for AES-GCM
  const iv = forge.random.getBytesSync(12); // 96 bits for GCM
  
  // Encrypt the credentials with AES-GCM
  const cipher = forge.cipher.createCipher('AES-GCM', aesKey);
  cipher.start({ iv });
  cipher.update(forge.util.createBuffer(credentialsBytes));
  cipher.finish();
  
  // Get encrypted payload and auth tag
  const encrypted = cipher.output.getBytes();
  const authTag = cipher.mode.tag.getBytes();
  
  // Combine IV + encrypted payload + auth tag and convert to Base64
  const combinedEncrypted = iv + encrypted + authTag;
  const encryptedPayloadB64 = forge.util.encode64(combinedEncrypted);
  
  // First convert AES key to Base64
  const aesKeyBase64 = forge.util.encode64(aesKey);
  
  // Then RSA encrypt the Base64 AES key string using OAEP with SHA-256
  const encryptedAesKey = publicKey.encrypt(aesKeyBase64, 'RSA-OAEP', {
    md: forge.md.sha256.create(),
    mgf1: {
      md: forge.md.sha256.create()
    }
  });
  
  // Convert encrypted AES key to Base64
  const encryptedAesKeyB64 = forge.util.encode64(encryptedAesKey);
  
  // Return the encrypted data
  return {
    encryptedAesKeyB64,
    encryptedPayloadB64
  };
}

// Example usage
async function main() {
  try {
    // Replace with actual credentials
    const email = 'maria@school.edu';
    const password = 'YourNewSecurePassword123!';
    
    const payload = await encryptLoginCredentials(email, password);
    
    console.log('\n--- Login Payload for Postman (or direct API call) ---');
    console.log(JSON.stringify(payload, null, 2));
    console.log('--- End of Payload ---\n');
    
    // Make the login API call with the encrypted payload
    console.log('Attempting to login with the generated payload...\n');
    try {
      const loginResponse = await axios.post('http://localhost:5000/api/v1/auth/login', payload);
      console.log('--- Login API Call SUCCESS ---');
      console.log('Status:', loginResponse.status);
      console.log('Data:', JSON.stringify(loginResponse.data, null, 2));
      console.log('--- End of Login API Response ---');
    } catch (error) {
      console.log('--- Login API Call FAILED ---');
      console.log('Status:', error.response?.status);
      console.log('Data:', JSON.stringify(error.response?.data, null, 2));
      console.log('--- End of Login API Error ---');
    }
  } catch (error) {
    console.error('Error:', error.message);
  }
}

// Run the script
main();