// src/app/modules/admin/models/topic.model.ts OR can be added to subject.model.ts

import { TopicDetailsBackendNested } from "./subject.model";

// Interface for the resource types within a topic
export interface McqQuestion {
  _id?: string; // Optional if new
  questionText: string;
  options: { text: string; isCorrect: boolean }[];
  explanation?: string;
}

export interface InterviewQuestion {
  _id?: string; // Optional if new
  question: string;
  answer?: string; // Admin might provide an ideal answer
  keywords?: string[];
  difficulty?: 'Easy' | 'Medium' | 'Hard';
}

export interface TopicNote {
  _id?: string; // Optional if new
  title?: string;
  content: string; // Could be Markdown, HTML, or plain text
  order?: number;
}

export interface PracticeSession { // This is very conceptual, depends on what a "session" entails
    _id?: string;
    title: string;
    description?: string;
    type: 'coding_challenge' | 'simulation' | 'interactive_exercise';
    instructions?: string;
    session_data?: any; // Could be link to external tool, embedded content, or structured data
}

// More comprehensive Topic structure for when we manage its content
export interface TopicFullDetailsFE {
  _id: string;
  topicName: string;
  moduleName?: string; // For context
  subjectName?: string; // For context
  topicVideos?: string[];
  topicContent?: string;
  sequenceOrder?: number;
  isActive?: boolean;
  mcqs?: McqQuestion[];
  interviewQuestions?: InterviewQuestion[];
  notes?: TopicNote[];
  practiceSessions?: PracticeSession[];
}

// The structure your backend provides for a single topic with all its resources
export interface TopicDetailsWithResourcesBackend {
  _id: string;
  TopicName: string;
  ModuleID: string;
  TopicVideos?: string[];
  TopicContent?: string;
  sequence_order?: number;
  is_active?: boolean;
  created_by?: { _id: string; full_name: string; email: string }; // CreatedByInfo
  CreatedAt?: string;
  UpdatedAt?: string;
  MCQs?: McqQuestion[]; // From your questions collection, filtered by this TopicID
  InterviewQuestions?: InterviewQuestion[]; // From your questions collection, filtered/typed differently
  Notes?: TopicNote[]; // From a new "notes" collection or embedded
  PracticeSessions?: PracticeSession[]; // From a new "practice_sessions" collection or embedded
}

export interface TopicBasicInfo {
  topicName: string;
  topicVideos?: string[];
  topicContent?: string;
  sequenceOrder?: number;
  // ModuleID will be part of the URL or main payload if not nested
}

export interface TopicSimpleCreatePayload {
  topicName: string;
  // topicContent?: string; // Optional: from form
  // topicVideos?: string[]; // Optional: from form
  // sequenceOrder?: number; // Optional: frontend might calculate or backend assigns
}

// Payload for BULK adding topics to a module
export interface BulkTopicAddPayload {
  moduleId: string; // The ID of the module these topics belong to
  subjectId: string; // The ID of the parent subject (for endpoint construction or backend verification)
  topics: TopicSimpleCreatePayload[]; // Array of topics to create
}

// Response from backend after bulk adding topics
export interface BulkTopicAddResponse {
  success: boolean;
  message: string;
  statusCode?: number;
  data?: {
    createdTopicsCount?: number;
    createdTopicIds?: string[]; // IDs of successfully created topics
    errors?: { topicNameAttempted: string, error: string }[]; // For partial success/failure
  };
}

// Response for adding/mutating a SINGLE topic (if you keep that separate)
export interface TopicMutationResponse { // Can be generic
  success: boolean;
  message: string;
  data?: TopicDetailsBackendNested; // The created/updated topic
  statusCode?: number;
}