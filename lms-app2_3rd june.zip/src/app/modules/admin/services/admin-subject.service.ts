import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { firstValueFrom, Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { environment } from '../../../../environments/environments'; // Corrected path from environments/environments
import { EncryptionService } from '../../../core/services/encryption.service';
import { AuthService } from '../../../core/services/auth.service';
import {
  SubjectDetailsBackend,
  FetchSubjectsApiResponse,
  SubjectBasicInfo,
  EncryptedSubjectRequest,
  SubjectMutationResponse,
  SubjectUpdatePayload,
  ModuleBasicInfo,
  BulkModuleAddResponse,      // IMPORTED
  TopicSimpleCreatePayload, // IMPORTED
  TopicDetailsBackendNested,  // Use this for nested topics
  BulkTopicAddResponse,    // IMPORTED
  TopicMutationResponse,    // IMPORTED
  ModuleMutationResponse,   // IMPORTED
  BulkTopicAddPayload
} from '../models/subject.model';

import {
  MinimalCourseInfo,
  FetchCoursesApiResponse as GenericFetchListApiResponse, // Use an alias for clarity
  CourseDetailsBackend as FullCourseDetailsBackend
} from '../models/course.model';
import { TopicBasicInfo } from '../models/topic.model';


@Injectable({
  providedIn: 'root'
})
export class AdminSubjectService {
  private baseApiUrl = `${environment.apiUrl}/admin/subjects`;
  private coursesApiUrl = `${environment.apiUrl}/admin/courses`;

  constructor(
    private http: HttpClient,
    private encryptionService: EncryptionService,
    private authService: AuthService
  ) {}

  private getAuthHeaders() {
    const token = this.authService.token;
    if (!token) {
      console.error(`${this.constructor.name}: Admin token not found for API call.`);
      throw new Error("Authentication token is missing. Please log in again.");
    }
    return {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };
  }

  private handleHttpError(error: HttpErrorResponse, context: string = 'operation'): Observable<never> {
    console.error(`AdminSubjectService HTTP Error during ${context}:`, error.status, error.message, error.error);
    let userMessage = `An unexpected error occurred during ${context}.`;
    if (error.error && typeof error.error === 'object' && error.error.message) {
      userMessage = error.error.message;
    } else if (typeof error.error === 'string' && error.error.length > 0 && error.error.length < 300) {
        userMessage = error.error;
    } else if (error.message) {
      userMessage = `Error ${error.status}: ${error.statusText || 'Server communication error'}`;
    }
    return throwError(() => ({
        success: false, message: userMessage, statusCode: error.status, errorDetail: error.error
    }));
  }

  // --- Add New Subject ---
  async addSubject(subjectPayloadToEncrypt: SubjectBasicInfo): Promise<SubjectMutationResponse> {
    const addSubjectEndpoint = `${this.baseApiUrl}/create`;
    console.log(`AdminSubjectService: Adding new subject via ${addSubjectEndpoint}`, subjectPayloadToEncrypt);
    try {
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      const rsaEncryptedValue = await this.encryptionService.encryptAesKeyBase64WithRsa(aesKeyBase64ForRsa, rsaPublicKeyCryptoKey); // Renamed variable
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(subjectPayloadToEncrypt, aesCryptoKey);
      const encryptedRequest: EncryptedSubjectRequest = { encryptedAesKeyB64: rsaEncryptedValue, encryptedPayloadB64: aesEncryptedPayloadB64 }; // Corrected assignment
      const headers = this.getAuthHeaders();

      return await firstValueFrom(
        this.http.post<SubjectMutationResponse>(addSubjectEndpoint, encryptedRequest, { headers })
          .pipe(
            tap(res => console.log("AdminSubjectService: Response from add subject API:", res)),
            catchError(err => this.handleHttpError(err, 'add subject'))
          )
      );
    } catch (error) { /* ... client-side error handling ... */
        const err = error as Error;
        return Promise.reject({ success: false, message: err.message || 'Client-side error adding subject.', statusCode: 0 } as SubjectMutationResponse);
    }
  }

  // --- Fetch All Subjects ---
  async getSubjects(filters?: { searchTerm?: string }): Promise<SubjectDetailsBackend[]> {
    const viewSubjectsEndpoint = `${this.baseApiUrl}/view-subjects`;
    console.log(`AdminSubjectService: Fetching subjects from ${viewSubjectsEndpoint} with filters:`, filters);
    let httpParams = new HttpParams();
    if (filters?.searchTerm) httpParams = httpParams.set('search', filters.searchTerm);

    try {
      const headers = this.getAuthHeaders();
      const apiResponse = await firstValueFrom(
        this.http.get<FetchSubjectsApiResponse>(viewSubjectsEndpoint, { params: httpParams, headers })
          .pipe(catchError(err => this.handleHttpError(err, 'fetch subjects list')))
      );
      console.log("AdminSubjectService: Received API response from /view-subjects:", apiResponse);
      if (apiResponse && apiResponse.success && apiResponse.data) {
        const { responseAesKeyB64, encryptedData } = apiResponse.data;
        const decryptedJsonString = await this.encryptionService.decryptAesGcmPayload(encryptedData, responseAesKeyB64);
        const subjectsFromBackend: SubjectDetailsBackend[] = JSON.parse(decryptedJsonString);
        return subjectsFromBackend;
      } else {
        throw new Error(apiResponse?.message || "Failed to fetch subjects: Server indicated failure or no data.");
      }
    } catch (error: any) { /* ... error handling ... */
        const message = (error instanceof HttpErrorResponse && error.error?.message) || error.message || "Could not fetch or decrypt subjects.";
        throw new Error(message);
    }
  }


  // --- Fetch Single Subject by ID (with nested Modules/Topics as per backend log) ---
  async getSubjectDetailsWithNestedData(subjectId: string): Promise<SubjectDetailsBackend | null> {
    const subjectDetailEndpoint = `${this.baseApiUrl}/${subjectId}`;
    console.log(`AdminSubjectService: Fetching subject (with nested data) for ID: ${subjectId} from ${subjectDetailEndpoint}`);
    try {
      const headers = this.getAuthHeaders();
      // Backend returns a single subject object encrypted, wrapped in FetchSubjectsApiResponse
      const apiResponse = await firstValueFrom(
        this.http.get<FetchSubjectsApiResponse>(subjectDetailEndpoint, { headers })
          .pipe(catchError(err => this.handleHttpError(err, `fetch subject ${subjectId} details`)))
      );
      console.log("AdminSubjectService: Raw API response for single subject details:", JSON.stringify(apiResponse).substring(0,300)+"...");
      if (apiResponse && apiResponse.success && apiResponse.data) {
        const { responseAesKeyB64, encryptedData } = apiResponse.data;
        if (!responseAesKeyB64 || !encryptedData) {
            throw new Error("Invalid encrypted data structure for single subject.");
        }
        const decryptedJsonString = await this.encryptionService.decryptAesGcmPayload(encryptedData, responseAesKeyB64);
        console.log("AdminSubjectService: Decrypted JSON for single subject:", decryptedJsonString.substring(0, 400) + "...");
        const subjectWithNestedData: SubjectDetailsBackend = JSON.parse(decryptedJsonString);
        return subjectWithNestedData;
      } else if (apiResponse && apiResponse.statusCode === 404) {
        return null;
      } else {
        throw new Error(apiResponse?.message || `Failed to fetch subject details for ${subjectId}.`);
      }
    } catch (error: any) { /* ... error handling ... */
        if ((error as any).statusCode === 404 || error.message?.toLowerCase().includes('not found')) return null;
        const message = (error instanceof HttpErrorResponse && error.error?.message) || error.message || "Could not fetch/decrypt subject.";
        throw new Error(message);
    }
  }

  // --- Update Subject ---
  async updateSubject(subjectId: string, payload: SubjectUpdatePayload): Promise<SubjectMutationResponse> {
    const updateSubjectEndpoint = `${this.baseApiUrl}/update/${subjectId}`;
    console.log(`AdminSubjectService: Updating subject ID ${subjectId}:`, payload);
    try {
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      const rsaEncryptedValue = await this.encryptionService.encryptAesKeyBase64WithRsa(aesKeyBase64ForRsa, rsaPublicKeyCryptoKey);
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(payload, aesCryptoKey);
      const encryptedRequest: EncryptedSubjectRequest = { encryptedAesKeyB64: rsaEncryptedValue, encryptedPayloadB64: aesEncryptedPayloadB64 };
      const headers = this.getAuthHeaders();

      return await firstValueFrom(
        this.http.put<SubjectMutationResponse>(updateSubjectEndpoint, encryptedRequest, { headers })
          .pipe(catchError(err => this.handleHttpError(err, `update subject ${subjectId}`)))
      );
    } catch (error) { /* ... error handling ... */
        const err = error as Error;
        return Promise.reject({ success: false, message: err.message || 'Client-side error updating subject.', statusCode: 0 } as SubjectMutationResponse);
    }
  }

  // --- Add SINGLE Module to Subject ---
  async addModuleToSubject(subjectId: string, moduleDataToEncrypt: ModuleBasicInfo): Promise<SubjectMutationResponse> {
    const addModuleEndpoint = `${this.baseApiUrl}/${subjectId}/modules/create`;
    console.log(`AdminSubjectService: Adding SINGLE module to subject ${subjectId} via ${addModuleEndpoint}`, moduleDataToEncrypt);
    try {
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      const rsaEncryptedValue = await this.encryptionService.encryptAesKeyBase64WithRsa(aesKeyBase64ForRsa, rsaPublicKeyCryptoKey);
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(moduleDataToEncrypt, aesCryptoKey);
      const encryptedRequest: EncryptedSubjectRequest = { encryptedAesKeyB64: rsaEncryptedValue, encryptedPayloadB64: aesEncryptedPayloadB64 };
      const headers = this.getAuthHeaders();

      return await firstValueFrom(
        this.http.post<SubjectMutationResponse>(addModuleEndpoint, encryptedRequest, { headers })
          .pipe(
            tap(res => console.log("AdminSubjectService: Response from actual add single module API:", res)),
            catchError(err => this.handleHttpError(err, `add module to subject ${subjectId}`))
          )
      );
    } catch (error) { /* ... error handling ... */
      const err = error as Error;
      return Promise.reject({ success: false, message: err.message || 'Client-side error adding module.', statusCode: 0 } as SubjectMutationResponse);
    }
  }

  // --- Add MULTIPLE Modules to Subject (for JSON Upload) ---
  async addMultipleModulesToSubject(subjectId: string, modulesArray: ModuleBasicInfo[]): Promise<BulkModuleAddResponse> {
    const bulkAddModulesEndpoint = `${this.baseApiUrl}/modules-create/${subjectId}`; // Note: Your prev log had .../modules-create/:subjectId
    console.log(`AdminSubjectService: Adding ${modulesArray.length} modules to subject ${subjectId} via ${bulkAddModulesEndpoint}`);
    if (!modulesArray || modulesArray.length === 0) {
      return Promise.resolve({ success: true, message: "No modules provided.", statusCode: 200 });
    }
    try {
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      const rsaEncryptedValue = await this.encryptionService.encryptAesKeyBase64WithRsa(aesKeyBase64ForRsa, rsaPublicKeyCryptoKey);
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(modulesArray, aesCryptoKey); // Encrypt array
      const encryptedRequest: EncryptedSubjectRequest = { encryptedAesKeyB64: rsaEncryptedValue, encryptedPayloadB64: aesEncryptedPayloadB64 };
      const headers = this.getAuthHeaders();

      return await firstValueFrom(
        this.http.post<BulkModuleAddResponse>(bulkAddModulesEndpoint, encryptedRequest, { headers })
          .pipe(
            tap(res => console.log("AdminSubjectService: Response from bulk add modules API:", res)),
            catchError(err => this.handleHttpError(err, `bulk add modules to subject ${subjectId}`))
          )
      );
    } catch (error) { /* ... error handling ... */
        const err = error as Error;
        return Promise.reject({ success: false, message: err.message || 'Client-side error bulk adding modules.', statusCode: 0, data: {errors:[]} } as BulkModuleAddResponse);
    }
  }

  // --- Fetch Courses for Dropdown (e.g., in Add/Edit Subject or Add Module Modals) ---
  async getCoursesForSelection(): Promise<MinimalCourseInfo[]> {
    const viewCoursesEndpoint = `${this.coursesApiUrl}/view-courses`;
    try {
      const headers = this.getAuthHeaders();
      const apiResponse = await firstValueFrom(
        this.http.get<GenericFetchListApiResponse>(viewCoursesEndpoint, { headers }) // Use GenericFetchListApiResponse
          .pipe(catchError(err => this.handleHttpError(err, 'fetch courses for selection')))
      );
      if (apiResponse.success && apiResponse.data) {
        const { responseAesKeyB64, encryptedData } = apiResponse.data;
        const decryptedJsonString = await this.encryptionService.decryptAesGcmPayload(encryptedData, responseAesKeyB64);
        const fullCourses: FullCourseDetailsBackend[] = JSON.parse(decryptedJsonString);
        // Ensure MinimalCourseInfo { _id, name, description? } matches the mapping
        return fullCourses.map(course => ({
          _id: course._id,
          name: course.CourseName, // Map CourseName to name
          description: course.CourseDescription || undefined // Ensure description is string or undefined
        }));
      } else {
        throw new Error(apiResponse.message || "Failed to fetch courses for selection.");
      }
    } catch (error: any) { /* ... error handling ... */
        const message = (error instanceof HttpErrorResponse && error.error?.message) || error.message || "Could not fetch courses for selection.";
        throw new Error(message);
    }
  }

  async addTopicToModule(moduleId: string, subjectId: string, topicData: TopicBasicInfo): Promise<SubjectMutationResponse> { // Reusing SubjectMutationResponse
    // Backend endpoint: POST /api/v1/admin/modules/:moduleId/topics/create
    // OR POST /api/v1/admin/subjects/:subjectId/modules/:moduleId/topics/create
    // OR POST /api/v1/admin/topics  (with moduleId and subjectId in payload)
    // Let's use a nested approach for clarity for now:
    const addTopicEndpoint = `${this.baseApiUrl}/${subjectId}/modules/${moduleId}/topics/create`;
    console.log(`AdminSubjectService: Adding topic to module ${moduleId} (subject ${subjectId})`, topicData);

    try {
      // Encryption flow for topicData
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      const rsaEncryptedValue = await this.encryptionService.encryptAesKeyBase64WithRsa(aesKeyBase64ForRsa, rsaPublicKeyCryptoKey);
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(topicData, aesCryptoKey);
      const encryptedRequest = { encryptedAesKeyB64: rsaEncryptedValue, encryptedPayloadB64: aesEncryptedPayloadB64 }; // Re-use EncryptedSubjectRequest for generic encrypted payload
      const headers = this.getAuthHeaders();

      // SIMULATE API Call
      console.log("AdminSubjectService: Sending encrypted 'add topic' request:", encryptedRequest);
      await new Promise(resolve => setTimeout(resolve, 800));
      const newTopicSimulated: Partial<TopicDetailsBackendNested> = { // The backend would return full details
        _id: `topic_new_${Date.now()}`,
        TopicName: topicData.topicName,
        ModuleID: moduleId,
        // ... other fields
      };
      return {
        success: true,
        message: `Topic "${topicData.topicName}" (simulated) added to module ${moduleId}.`,
        data: newTopicSimulated as any, // Cast for simulation; backend would return proper structure
        statusCode: 201
      };
      /*
      // ACTUAL API CALL:
      return await firstValueFrom(
        this.http.post<SubjectMutationResponse>(addTopicEndpoint, encryptedRequest, { headers })
          .pipe(
            tap(res => console.log("Response from add topic API:", res)),
            catchError(err => this.handleHttpError(err, `add topic to module ${moduleId}`))
          )
      );
      */
    } catch (error) { /* ... client-side error handling ... */
      console.error("Error adding topic:", error);
      const err = error as Error;
      return Promise.reject({ success: false, message: err.message || 'Client-side error adding topic.', statusCode: 0 } as SubjectMutationResponse);
    }
  }

  async addSingleTopicToModule(moduleId: string, subjectId: string, topicData: TopicSimpleCreatePayload): Promise<TopicMutationResponse> {
    const addTopicEndpoint = `${this.baseApiUrl}/${subjectId}/modules/${moduleId}/topics/create`; // Or simply /admin/topics
    console.log(`AdminSubjectService: Adding SINGLE topic to module ${moduleId}`, topicData);
    try {
      // Encryption logic for topicData
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      const rsaEncryptedValue = await this.encryptionService.encryptAesKeyBase64WithRsa(aesKeyBase64ForRsa, rsaPublicKeyCryptoKey);
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(topicData, aesCryptoKey);
      const encryptedRequest = { encryptedAesKeyB64: rsaEncryptedValue, encryptedPayloadB64: aesEncryptedPayloadB64 };
      const headers = this.getAuthHeaders();

      // Replace with actual API call if your backend has a single topic add endpoint
      // For now, this will simulate. The bulk one below is what we are focusing on.
      console.log("AdminSubjectService: SIMULATING encrypted request for add single topic:", encryptedRequest);
      await new Promise(resolve => setTimeout(resolve, 700));
      return {
        success: true,
        message: `Topic "${topicData.topicName}" (simulated) added.`,
        data: { _id: `new_topic_${Date.now()}`, TopicName: topicData.topicName, ModuleID: moduleId } as TopicDetailsBackendNested,
        statusCode: 201
      };
      /*
      return await firstValueFrom(
        this.http.post<TopicMutationResponse>(addTopicEndpoint, encryptedRequest, { headers })
          .pipe(catchError(err => this.handleHttpError(err, 'add single topic')))
      );
      */
    } catch (error) { /* ... client-side error handling ... */
      const err = error as Error;
      return Promise.reject({ success: false, message: err.message || 'Client-side error.', statusCode:0 } as TopicMutationResponse);
    }
  }


  // --- Add MULTIPLE Topics to a Module (for JSON Upload or multi-input form) ---
  async addMultipleTopicsToModule(payload: BulkTopicAddPayload): Promise<BulkTopicAddResponse> {
    // Backend endpoint: POST /api/v1/admin/subjects/{subjectId}/modules/{moduleId}/topics/bulk-create
    // OR POST /api/v1/admin/topics/bulk (and payload contains moduleId/subjectId)
    // Let's assume the nested one for this example.
    const bulkAddTopicsEndpoint = `${this.baseApiUrl}/${payload.subjectId}/modules/${payload.moduleId}/topics/bulk-create`;
    console.log(`AdminSubjectService: Bulk adding ${payload.topics.length} topics to module ${payload.moduleId} (subject ${payload.subjectId})`);

    try {
      // Encrypt the ENTIRE payload (which includes the array of topics)
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      const rsaEncryptedValue = await this.encryptionService.encryptAesKeyBase64WithRsa(aesKeyBase64ForRsa, rsaPublicKeyCryptoKey);
      
      // The payload to encrypt is the BulkTopicAddPayload object itself
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(payload, aesCryptoKey);
      
      const encryptedRequest = { // Using a generic encrypted request structure
        encryptedAesKeyB64: rsaEncryptedValue,
        encryptedPayloadB64: aesEncryptedPayloadB64
      };
      const headers = this.getAuthHeaders();

      console.log("AdminSubjectService: Sending ACTUAL encrypted request for BULK add topics:", JSON.stringify(encryptedRequest).substring(0, 200) + "...");

      // ACTUAL API CALL (replace simulation when backend is ready)
      // return await firstValueFrom(
      //   this.http.post<BulkTopicAddResponse>(bulkAddTopicsEndpoint, encryptedRequest, { headers })
      //     .pipe(
      //       tap(res => console.log("AdminSubjectService: Response from actual bulk add topics API:", res)),
      //       catchError(err => this.handleHttpError(err, `bulk add topics to module ${payload.moduleId}`))
      //     )
      // );

      // SIMULATION:
      await new Promise(resolve => setTimeout(resolve, 1200));
      const createdIds = payload.topics.map((_, i) => `sim_topic_${Date.now()}_${i}`);
      return {
        success: true,
        message: `${payload.topics.length} topics (simulated) added to module ${payload.moduleId}.`,
        statusCode: 201,
        data: {
          createdTopicsCount: payload.topics.length,
          createdTopicIds: createdIds
        }
      };

    } catch (error) { // Catches errors from encryption or if token not found
      console.error(`Error in AdminSubjectService.addMultipleTopicsToModule (client-side/encryption):`, error);
      const err = error as Error;
      return Promise.reject({
        success: false,
        message: err.message || 'Client-side error bulk adding topics.',
        statusCode: 0,
        data: { errors: payload.topics.map(t => ({ topicNameAttempted: t.topicName, error: "Client-side processing failed."}))}
      } as BulkTopicAddResponse);
    }
  }
  // --- (Optional) Fetch Topics for a Module if not always nested (for SubjectDetailPage) ---
  // async getTopicsForModule(moduleId: string): Promise<TopicListItemFE[]> {
  //   // This is still simulated as your GET subject detail log included topics nested.
  //   // If you have a separate API endpoint, implement it here.
  //   console.log(`AdminSubjectService: SIMULATING fetch topics for moduleId: ${moduleId}`);
  //   await new Promise(resolve => setTimeout(resolve, 200));
  //   const topics: TopicListItemFE[] = [];
  //   for (let i = 0; i < Math.floor(Math.random() * 5) + 1; i++) {
  //     topics.push({ _id: `topic_${moduleId}_${i}`, topicName: `Simulated Topic ${i + 1} for ${moduleId}` });
  //   }
  //   return topics;
  // }

  // Removed simulation methods like simulateFetchSubjectsApi, getMockSubjectsData etc. for brevity
  // as we are moving towards actual API calls. Keep them if you need for testing.
}