import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';

import { AdminStudentService, StudentEnrollmentInitiationPayload } from '../../services/admin-student.service';
import { StudentDetailsFE, StudentDetailsBackend, StudentBasicEnrollInfo } from '../../models/student.model';
import { StudentEnrollModalComponent } from '../../components/student-enroll-modal/student-enroll-modal.component';

@Component({
  selector: 'app-student-management-page',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    StudentEnrollModalComponent // This is used in the template below
  ],
  templateUrl: './student-management-page.component.html',
  // styleUrls: ['./student-management-page.component.css']
})
export class StudentManagementPageComponent implements OnInit {
  isEnrollModalOpen = false;
  students: StudentDetailsFE[] = [];
  isLoadingStudents = false;
  errorMessage: string | null = null;

  filterForm: FormGroup;
  studentStatusOptions = [
    { value: '', label: 'All Statuses' },
    { value: 'enrolled', label: 'Enrolled' },
    { value: 'pending_payment', label: 'Pending Payment' },
    { value: 'suspended', label: 'Suspended' },
    { value: 'completed_profile', label: 'Profile Complete' },
    { value: 'unknown', label: 'Unknown' } // Added for completeness
  ];

  constructor(
    private router: Router,
    private adminStudentService: AdminStudentService,
    private fb: FormBuilder
  ) {
    this.filterForm = this.fb.group({
      searchTerm: [''],
      status: [''] // Corresponds to enrollment_status from backend (after mapping for display)
    });
  }

  ngOnInit(): void {
    this.loadStudents();
    this.filterForm.valueChanges.subscribe(() => {
      this.loadStudents();
    });
  }

  async loadStudents(): Promise<void> {
    this.isLoadingStudents = true;
    this.errorMessage = null;
    try {
      // Get filter values, ensuring status matches backend expected values if service sends it raw
      const backendFilters = {
        searchTerm: this.filterForm.value.searchTerm,
        // The filter form uses 'enrolled', 'pending_payment' etc. for status,
        // which matches our StudentDetailsBackend enrollment_status values.
        status: this.filterForm.value.status
      };
      const studentsFromBackend: StudentDetailsBackend[] = await this.adminStudentService.getStudents(backendFilters);

      this.students = studentsFromBackend.map(sBackend => ({
        _id: sBackend._id,
        fullName: sBackend.full_name,
        email: sBackend.email,
        mobile: sBackend.mobile_number || 'N/A',
        // Use the formatStudentStatus to get the display-friendly status string
        // and type it as StudentDetailsFE['status']
        status: this.formatStudentStatus(sBackend.enrollment_status),
        isActive: sBackend.is_active,
        course: sBackend.course_info || 'N/A',
        enrolledCourseCount: sBackend.enrolled_courses?.length || 0
        // dateOfBirth: sBackend.date_of_birth ? new Date(sBackend.date_of_birth) : undefined, // if needed
      }));
      console.log("StudentManagementPage: Mapped students for template:", JSON.stringify(this.students, null, 2));
    } catch (error: any) {
      this.errorMessage = error.message || 'Failed to load students.';
      console.error("Error loading students:", error);
    } finally {
      this.isLoadingStudents = false;
    }
  }

  openEnrollStudentModal(): void {
    this.isEnrollModalOpen = true;
  }

  closeEnrollStudentModal(): void {
    this.isEnrollModalOpen = false;
  }

  
   async handleStudentEnrolled(studentBasicInfo: StudentBasicEnrollInfo): Promise<void> {
    // This method is called when StudentEnrollModalComponent emits (studentEnrolled)
    console.log('StudentManagementPageComponent: Received student basic info from modal:', studentBasicInfo);
    this.closeEnrollStudentModal(); // Close the enrollment modal

    // Navigate to the student mail preview page, passing the studentData
    this.router.navigate(['/admin/students/mail-preview'], { state: { studentData: studentBasicInfo } });
  }

  

  // Fully implemented formatStudentStatus
  formatStudentStatus(statusKey?: string): StudentDetailsFE['status'] {
    if (!statusKey) return 'Unknown'; // Default for missing status
    switch (statusKey.toLowerCase()) { // Make comparison case-insensitive
      case 'enrolled': return 'Enrolled';
      case 'pending_payment': return 'Pending Payment';
      case 'suspended': return 'Suspended';
      case 'completed_profile': return 'Profile Complete';
      // Add other backend statuses and their display versions here
      default:
        // Try to format unknown statuses gracefully
        return statusKey.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ') as StudentDetailsFE['status'];
    }
  }

  // Fully implemented getStatusClass
  getStatusClass(displayStatus: StudentDetailsFE['status']): string {
    // This function now receives the already formatted displayStatus
    if (!displayStatus) return 'bg-gray-100 text-gray-800';

    switch (displayStatus.toLowerCase()) { // Use the formatted status for class mapping
      case 'enrolled': return 'bg-green-100 text-green-800';
      case 'pending payment': return 'bg-yellow-100 text-yellow-800';
      case 'suspended': return 'bg-red-100 text-red-800';
      case 'profile complete': return 'bg-blue-100 text-blue-800';
      case 'unknown': return 'bg-gray-300 text-gray-700';
      default: return 'bg-gray-100 text-gray-800';
    }
  }

  viewStudentDetails(studentId: string): void {
    console.log("View student details for ID:", studentId);
    // Navigate to a detail page: this.router.navigate(['/admin/students', studentId]);
  }

  editStudent(studentId: string): void {
    console.log("Edit student with ID:", studentId);
    // Navigate to an edit page: this.router.navigate(['/admin/students', studentId, 'edit']);
  }
}