// src/app/modules/admin/pages/module-content-management-page/module-content-management-page.component.ts
import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common'; // DatePipe is part of CommonModule for template usage if needed
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators, FormArray, AbstractControl, ValidationErrors } from '@angular/forms';

import { AdminSubjectService } from '../../services/admin-subject.service';
import {
  ModuleDetailsBackendNested,   // Represents the structure from backend for the current module
  TopicDetailsBackendNested,  // Represents existing topics from backend
  TopicSimpleCreatePayload,   // For items in the 'topics' FormArray when adding new
  BulkTopicAddPayload  ,
  BulkTopicAddResponse     // Payload for bulk adding topics
} from '../../models/subject.model';

@Component({
  selector: 'app-module-content-management-page',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule
    // DatePipe, // Removed as not directly used by this component's template
  ],
  templateUrl: './module-content-management-page.component.html',
})
export class ModuleContentManagementPageComponent implements OnInit {
  subjectId: string | null = null;
  moduleId: string | null = null;
  moduleDetails: ModuleDetailsBackendNested | null = null; // Holds current module's data including existing topics

  isLoadingPage = true;           // For initial loading of module details
  errorMessage: string | null = null;

  showAddTopicsSection = false; // To toggle the add topics UI
  addTopicsForm: FormGroup;     // The form group for adding new topics (manual or from JSON)
  isAddingTopics = false;       // Loading state for when "Add Topics" button is clicked

  // For JSON file upload specifically for topics
  @ViewChild('topicJsonFileInput') topicJsonFileInputRef!: ElementRef<HTMLInputElement>; // Corrected name
  uploadedTopics: TopicSimpleCreatePayload[] | null = null; // Stores topics parsed from uploaded JSON
  jsonFileName: string | null = null;
  jsonError: string | null = null;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private adminSubjectService: AdminSubjectService,
    private fb: FormBuilder
  ) {
    // Form for adding NEW topics
    this.addTopicsForm = this.fb.group({
      // This FormArray will hold multiple topic input groups for manual entry
      topics: this.fb.array([], { validators: this.requireAtLeastOneValidTopicInFormArray })
    });
  }

  ngOnInit(): void {
    this.subjectId = this.route.snapshot.paramMap.get('subjectId');
    this.moduleId = this.route.snapshot.paramMap.get('moduleId');

    if (this.subjectId && this.moduleId) {
      this.loadModuleAndItsExistingTopics();
      if (this.newTopicsFormArray.length === 0) { // Ensure one field on init for manual entry
        this.addNewTopicFieldToForm();
      }
    } else {
      this.errorMessage = "Subject ID or Module ID not found in route parameters.";
      this.isLoadingPage = false;
    }
  }

  async loadModuleAndItsExistingTopics(): Promise<void> {
    if (!this.subjectId || !this.moduleId) return;
    this.isLoadingPage = true;
    this.errorMessage = null;
    try {
      // Assumes getSubjectDetailsWithNestedData fetches the parent subject,
      // which contains the Modules array, and within that, the specific module with its Topics.
      const subjectBackendData = await this.adminSubjectService.getSubjectDetailsWithNestedData(this.subjectId);
      if (subjectBackendData && subjectBackendData.Modules) {
        const foundModule = subjectBackendData.Modules.find(m => m._id === this.moduleId);
        if (foundModule) {
          this.moduleDetails = foundModule; // moduleDetails now has nested Topics
          console.log("ModuleContentManagementPage: Loaded module details with topics:", this.moduleDetails);
        } else {
          this.errorMessage = `Module with ID ${this.moduleId} not found within subject ${this.subjectId}.`;
        }
      } else {
        this.errorMessage = `Subject with ID ${this.subjectId} not found or does not contain modules.`;
      }
    } catch (error: any) {
      this.errorMessage = error.message || "Failed to load module and topic data.";
      console.error("Error loading module/topic data:", error);
    } finally {
      this.isLoadingPage = false;
    }
  }

  // --- Logic for the "Add New Topics" dynamic form ---
  get newTopicsFormArray() { // Getter for the topics FormArray in addTopicsForm
    return this.addTopicsForm.get('topics') as FormArray;
  }

  createTopicFormGroup(): FormGroup {
    return this.fb.group({
      topicName: ['', Validators.required],
      // topicContent: [''], // Example of other fields
      // topicVideos: this.fb.array([])
    });
  }

  addNewTopicFieldToForm(): void { // Renamed for clarity
    if (this.canAddNewTopicField()) {
      this.newTopicsFormArray.push(this.createTopicFormGroup());
    }
  }

  removeNewTopicField(index: number): void {
    if (this.newTopicsFormArray.length > 1) { // Always keep at least one form group
      this.newTopicsFormArray.removeAt(index);
    }
  }

  canAddNewTopicField(): boolean {
    if (this.newTopicsFormArray.length === 0) return true; // Allow adding the first one
    const lastTopicGroup = this.newTopicsFormArray.at(this.newTopicsFormArray.length - 1);
    if (!lastTopicGroup) return false; // Should not happen if length > 0
    const topicNameControl = lastTopicGroup.get('topicName');
    // Only allow adding a new field if the last one is valid (i.e., has a name)
    return !!(topicNameControl && topicNameControl.valid && topicNameControl.value?.trim() !== '');
  }

  // Custom validator for the topics FormArray
  private requireAtLeastOneValidTopicInFormArray(formArray: AbstractControl): ValidationErrors | null {
    if (formArray instanceof FormArray && formArray.controls.length > 0) {
      const hasAtLeastOneValidTopic = formArray.controls.some(
        control => control.get('topicName')?.value?.trim() !== ''
      );
      return hasAtLeastOneValidTopic ? null : { requireAtLeastOneValidTopicInFormArray: true };
    }
    // If form array is empty (e.g. after JSON upload disabled it and it was cleared) then no error here.
    // The onSubmit will check if topicsToSubmit is empty.
    return null;
  }

  toggleAddTopicsSection(): void {
    this.showAddTopicsSection = !this.showAddTopicsSection;
    if (!this.showAddTopicsSection) {
      this.clearAddTopicsFormAndFile(); // Clear form and file when hiding
    } else if (this.addTopicsForm.get('topics')?.disabled && this.newTopicsFormArray.length === 0) {
      // If form was disabled by JSON upload and then upload cleared, ensure one field is present
      this.addTopicsForm.get('topics')?.enable(); // Make sure it's enabled
      this.addNewTopicFieldToForm();
    } else if (this.newTopicsFormArray.length === 0) {
      this.addNewTopicFieldToForm(); // Ensure at least one field when opening
    }
  }

  clearAddTopicsFormAndFile(): void {
    this.newTopicsFormArray.clear(); // Clear all topic form groups
    this.addTopicsForm.reset();      // Reset main form state (doesn't clear FormArray but resets its value and child values)
    this.newTopicsFormArray.clear(); // Call clear again after reset to ensure it's empty
    this.jsonFileName = null;
    this.jsonError = null;
    this.uploadedTopics = null;
    if (this.topicJsonFileInputRef) {
        this.topicJsonFileInputRef.nativeElement.value = ''; // Reset file input
    }
    this.addTopicsForm.get('topics')?.enable(); // Re-enable FormArray for manual entry
    if (this.newTopicsFormArray.length === 0) { // Add one blank field back
        this.addNewTopicFieldToForm();
    }
  }

  // Main submission handler for adding topics (from form or JSON)
  async onAddTopicsSubmit(): Promise<void> {
    if (!this.moduleId || !this.subjectId) {
      alert("Module or Subject context is missing. Cannot add topics.");
      return;
    }

    let topicsToSubmit: TopicSimpleCreatePayload[] = [];

    if (this.uploadedTopics && this.uploadedTopics.length > 0) {
      // Use data from uploaded JSON file
      topicsToSubmit = this.uploadedTopics;
      console.log("Submitting topics from JSON file:", topicsToSubmit);
    } else {
      // Process manual form data
      this.addTopicsForm.get('topics')?.markAllAsTouched(); // Trigger validation display for FormArray items
      if (this.addTopicsForm.get('topics')?.invalid) {
        console.log("Manual topics form section is invalid. Errors:", this.addTopicsForm.get('topics')?.errors);
        // Alert or indicate error more gracefully
        return;
      }
      topicsToSubmit = (this.addTopicsForm.get('topics') as FormArray).controls
        .map(control => ({
            topicName: this.toTitleCase(control.get('topicName')?.value?.trim()),
            // Map other fields from createTopicFormGroup if they exist
        }))
        .filter(topic => topic.topicName); // Ensure topicName is not empty after trim
      console.log("Submitting topics from manual form:", topicsToSubmit);
    }

    if (topicsToSubmit.length === 0) {
      alert("No topics to add. Please provide topic names or upload a valid JSON file.");
      return;
    }

    this.isAddingTopics = true; // For UI loading state on submit button
    const bulkPayload: BulkTopicAddPayload = {
      moduleId: this.moduleId,
      subjectId: this.subjectId,
      topics: topicsToSubmit
    };

    try {
      const response: BulkTopicAddResponse = await this.adminSubjectService.addMultipleTopicsToModule(bulkPayload);;
      if (response.success) {
        alert(response.message || `${topicsToSubmit.length} topic(s) processed successfully!`);
        this.clearAddTopicsFormAndFile();      // Clear the form/file input
        this.showAddTopicsSection = false; // Hide the add section
        this.loadModuleAndItsExistingTopics(); // Refresh the displayed list of topics for the module
      } else {
        let errorDetail = '';
        if (response.data?.errors && response.data.errors.length > 0) {
            errorDetail = "\nDetails:\n" + response.data.errors.map(
              (e: { topicNameAttempted: string, error: string }) => `- "${e.topicNameAttempted}": ${e.error}` // <<< Type 'e'
            ).join("\n");
        }
        alert(`Failed to add topics: ${response.message || 'Unknown server error.'}${errorDetail}`);
      }
    } catch (error: any) {
      alert(`Error adding topics: ${error.message || 'Please try again.'}`);
      console.error("Error in onAddTopicsSubmit:", error);
    } finally {
      this.isAddingTopics = false;
    }
  }

  // --- JSON File Upload Logic for Topics ---
  onTopicFileSelected(event: Event): void {
    const fileInput = event.target as HTMLInputElement;
    if (fileInput.files && fileInput.files.length > 0) {
      const file = fileInput.files[0];
      this.jsonFileName = file.name;
      this.jsonError = null;
      this.uploadedTopics = null; // Clear previous
      if (file.type === "application/json") {
        const reader = new FileReader();
        reader.onload = (e) => {
          try {
            const jsonContent = e.target?.result as string;
            const parsedData = JSON.parse(jsonContent);
            if (this.isValidTopicSimpleCreatePayloadArray(parsedData)) {
              this.uploadedTopics = parsedData.map((topic: TopicSimpleCreatePayload) => ({ // Ensure TopicSimpleCreatePayload
                topicName: this.toTitleCase(topic.topicName.trim()),
                // Map other potential fields from TopicSimpleCreatePayload
              }));
              console.log("Parsed and title-cased JSON topics:", this.uploadedTopics);
              this.addTopicsForm.get('topics')?.disable(); // Disable manual entry part of form
              this.newTopicsFormArray.clear();           // Clear manual fields
            } else {
              this.jsonError = "Invalid JSON structure for topics. Each topic object must have a 'topicName' (string).";
              this.clearTopicJsonUploadFields();
            }
          } catch (parseError) { this.jsonError = "Error parsing JSON file."; this.clearTopicJsonUploadFields(); }
        };
        reader.onerror = () => { this.jsonError = "Error reading file."; this.clearTopicJsonUploadFields(); };
        reader.readAsText(file);
      } else { this.jsonError = "Invalid file type, please upload a .json file."; this.clearTopicJsonUploadFields(); }
    }
  }

  isValidTopicSimpleCreatePayloadArray(data: any): data is TopicSimpleCreatePayload[] {
    if (!Array.isArray(data)) return false;
    return data.every(item =>
      typeof item === 'object' && item !== null &&
      'topicName' in item && typeof item.topicName === 'string' && item.topicName.trim() !== ''
      // Add validation for other fields if TopicSimpleCreatePayload has them
    );
  }

  clearTopicJsonUploadFields(): void { // Renamed for clarity from previous generic clearJsonUpload
    this.uploadedTopics = null;
    this.jsonFileName = null;
    // Do not clear this.jsonError here, so user sees it
    if (this.topicJsonFileInputRef) {
        this.topicJsonFileInputRef.nativeElement.value = '';
    }
    this.addTopicsForm.get('topics')?.enable();
    if (this.newTopicsFormArray.length === 0) { // If manual entries were cleared due to JSON
        this.addNewTopicFieldToForm();
    }
  }

  downloadTopicDemoJson(): void {
    const demoData: TopicSimpleCreatePayload[] = [
      { topicName: "Understanding Topic A" /*, topicContent: "Content for A..." */ },
      { topicName: "Exploring Topic B" /*, topicVideos: ["http://..."] */ }
    ];
    const jsonString = JSON.stringify(demoData, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a');
    a.href = url; a.download = 'demo-module-topics-template.json';
    document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
  }
  // --- End JSON Logic ---

  toTitleCase(str: string): string {
    if (!str) return '';
    return str.toLowerCase().split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  }

  // Placeholder CRUD methods for resources WITHIN an existing topic
  editTopicDetails(topic: TopicDetailsBackendNested) {
    console.log("Edit topic details clicked for:", topic);
    // This would navigate to a new page/modal: /admin/topics/:topicId/edit
    // Or open a modal for inline editing
    alert(`Editing details for "${topic.TopicName}" not yet implemented.`);
  }

  manageTopicResources(topic: TopicDetailsBackendNested) {
    console.log("Manage resources clicked for topic:", topic);
    // This would navigate to a new page where MCQs, Notes etc. for THIS topic are managed
    // e.g., /admin/topics/:topicId/resources
    alert(`Resource management for "${topic.TopicName}" not yet implemented.`);
  }
  // In module-content-management-page.component.ts

  goBackToSubject(): void {
    if (this.subjectId) {
      this.router.navigate(['/admin/subjects', this.subjectId]);
    } else {
      this.router.navigate(['/admin/subjects']);
    }
  }
    clearTopicJsonUpload(): void { // <<< RENAME THIS METHOD (or change HTML call)
    this.uploadedTopics = null;
    this.jsonFileName = null;
    this.jsonError = null; // Also clear the error when clearing the upload
    if (this.topicJsonFileInputRef) {
        this.topicJsonFileInputRef.nativeElement.value = '';
    }
    this.addTopicsForm.get('topics')?.enable();
    if (this.newTopicsFormArray.length === 0) {
        this.addNewTopicFieldToForm();
    }
  }
}