import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms'; // For filters

import { AdminCourseService } from '../../services/admin-course.service';
import { CourseDetailsFE, CourseDetailsBackend, CourseBasicInfo } from '../../models/course.model';
import { CourseAddModalComponent } from '../../components/course-add-modal/course-add-modal.component';

@Component({
  selector: 'app-course-management-page',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    CourseAddModalComponent
  ],
  templateUrl: './course-management-page.component.html',
  // styleUrls: ['./course-management-page.component.css']
})
export class CourseManagementPageComponent implements OnInit {
  isAddCourseModalOpen = false;
  courses: CourseDetailsFE[] = [];
  isLoadingCourses = false;
  errorMessage: string | null = null;

  filterForm: FormGroup;

  constructor(
    private router: Router,
    private adminCourseService: AdminCourseService,
    private fb: FormBuilder
  ) {
    this.filterForm = this.fb.group({
      searchTerm: [''],
      // Add other filters like subject, status (published/draft) later
    });
  }

  ngOnInit(): void {
    this.loadCourses();
    this.filterForm.valueChanges.subscribe(() => {
      this.loadCourses();
    });
  }

  async loadCourses(): Promise<void> {
    this.isLoadingCourses = true;
    this.errorMessage = null;
    try {
      const filters = this.filterForm.value;
      const coursesFromBackend: CourseDetailsBackend[] = await this.adminCourseService.getCourses(filters);

      this.courses = coursesFromBackend.map(cBackend => {
        let subjectDisplayNames = 'N/A';
        // Check if CourseSubjects exists and is an array before trying to map it
        if (cBackend.CourseSubjects && Array.isArray(cBackend.CourseSubjects) && cBackend.CourseSubjects.length > 0) {
          subjectDisplayNames = cBackend.CourseSubjects.map(subject => {
            if (typeof subject === 'string') return subject;
            if (typeof subject === 'object' && subject !== null) {
              return (subject as any).name || (subject as any).SubjectName || 'Unknown';
            }
            return 'Invalid';
          }).join(', ');
        } else if (cBackend.CourseSubjects && Array.isArray(cBackend.CourseSubjects) && cBackend.CourseSubjects.length === 0) {
          subjectDisplayNames = 'None'; // Or 'N/A' if an empty array means no subjects
        }


        // Ensure all fields expected by CourseDetailsFE are assigned.
        const feCourse: CourseDetailsFE = {
          _id: cBackend._id,
          name: cBackend.CourseName || 'Unnamed Course',
          // Ensure CourseDescription is a string before calling .length or .substring
          description: typeof cBackend.CourseDescription === 'string'
            ? (cBackend.CourseDescription.length > 100 ? cBackend.CourseDescription.substring(0, 97) + '...' : cBackend.CourseDescription)
            : 'No description', // Default if CourseDescription is not a string or undefined
          subjectsDisplay: subjectDisplayNames,
          isPublished: typeof cBackend.is_published === 'boolean' ? cBackend.is_published : false,
          createdAt: cBackend.created_at ? new Date(cBackend.created_at) : new Date(0), // Default to epoch if missing
          // Add any other fields from CourseDetailsFE and ensure they get a value
          // For example, if CourseDetailsFE expects 'updatedAt':
          // updatedAt: cBackend.updated_at ? new Date(cBackend.updated_at) : new Date(0),
        };
        return feCourse;
      });

      console.log("CourseManagementPage: MAPPED courses for template:", JSON.stringify(this.courses, null, 2));
    } catch (error: any) {
      this.errorMessage = error.message || 'Failed to load courses.';
      console.error("Error in loadCourses:", error);
      this.courses = []; // Ensure courses is an empty array on error to prevent template issues
    } finally {
      this.isLoadingCourses = false;
    }
  }

  getStatusClass(isPublished: boolean | undefined): string {
    if (typeof isPublished !== 'boolean') {
      // This could be for when data is still loading or if a course somehow has no publish status
      return 'bg-gray-200 text-gray-700'; // Default for unknown publish state
    }
    return isPublished ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800';
  }

  formatStatus(isPublished: boolean | undefined): string {
    if (typeof isPublished !== 'boolean') {
      return 'N/A';
    }
    return isPublished ? 'Published' : 'Draft';
  }

  openAddCourseModal(): void {
    this.isAddCourseModalOpen = true;
  }

  closeAddCourseModal(): void {
    this.isAddCourseModalOpen = false;
  }

  handleCourseAdded(courseData: CourseBasicInfo): void {
    console.log('CourseManagementPage: Course add initiated from modal:', courseData);
    // The actual API call is in the modal's submit handler calling adminCourseService.addCourse
    // We just need to refresh the list here if successful.
    this.loadCourses(); // Refresh the list after a course is (simulated as) added
    this.closeAddCourseModal();
  }

  viewCourseDetails(courseId: string): void {
    console.log('CourseManagementPageComponent: viewCourseDetails called with ID:', courseId); // <<< ADD THIS
    if (!courseId) {
      console.error('CourseManagementPageComponent: Attempted to view details with no courseId!');
      return;
    }
    // Navigate to the detail page
    this.router.navigate(['/admin/courses', courseId]); // Example: '/admin/courses/someObjectId'
  }

  editCourse(courseId: string): void {
    console.log("Edit course:", courseId);
    // this.router.navigate(['/admin/courses', courseId, 'edit']);
  }

  togglePublishStatus(course: CourseDetailsFE): void {
    console.log("Toggle publish status for:", course.name, "Current:", course.isPublished);
    // TODO: Call service to update publish status, then reload or update locally
    // course.isPublished = !course.isPublished; // Optimistic update
    // this.adminCourseService.updatePublishStatus(course._id, course.isPublished).then(...);
  }
}