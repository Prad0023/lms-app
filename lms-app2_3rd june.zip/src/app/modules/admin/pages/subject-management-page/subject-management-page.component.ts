import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';

import { AdminSubjectService } from '../../services/admin-subject.service';
import { SubjectListItem, SubjectDetailsBackend , SubjectMutationResponse, SubjectBasicInfo } from '../../models/subject.model'; // Using SubjectListItem for the table
import { SubjectAddModalComponent } from '../../components/subject-add-modal/subject-add-modal.component';

@Component({
  selector: 'app-subject-management-page',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    SubjectAddModalComponent
  ],
  templateUrl: './subject-management-page.component.html',
  // styleUrls: ['./subject-management-page.component.css']
})
export class SubjectManagementPageComponent implements OnInit {
  isAddSubjectModalOpen = false;
  subjects: SubjectListItem[] = []; // Use SubjectListItem for display
  isLoadingSubjects = false;
  errorMessage: string | null = null;
  filterForm: FormGroup;
  isAddingSubject = false;

  constructor(
    private router: Router,
    private adminSubjectService: AdminSubjectService,
    private fb: FormBuilder
  ) {
    this.filterForm = this.fb.group({
      searchTerm: [''],
    });
  }

  ngOnInit(): void {
    this.loadSubjects();
    this.filterForm.valueChanges.subscribe(() => {
      this.loadSubjects();
    });
  }

  async loadSubjects(): Promise<void> {
    this.isLoadingSubjects = true;
    this.errorMessage = null;
    try {
      const filters = this.filterForm.value;
      const subjectsFromBackend: SubjectDetailsBackend[] = await this.adminSubjectService.getSubjects(filters);

      this.subjects = subjectsFromBackend.map(sBackend => ({
        _id: sBackend._id,
        name: sBackend.SubjectName,
        description: (sBackend.SubjectDescription || '').substring(0, 100) + ((sBackend.SubjectDescription || '').length > 100 ? '...' : ''),
        courseCount: Array.isArray(sBackend.AssociatedCourses) ? sBackend.AssociatedCourses.length : 0 // Safely access length
      }));
    } catch (error: any) {
      this.errorMessage = error.message || 'Failed to load subjects.';
      console.error("Error loading subjects in SubjectManagementPage:", error);
    } finally {
      this.isLoadingSubjects = false;
    }
  }

  openAddSubjectModal(): void {
    this.isAddSubjectModalOpen = true;
  }

  closeAddSubjectModal(): void {
    this.isAddSubjectModalOpen = false;
  }


    async handleSubjectAdded(newSubjectData: SubjectBasicInfo): Promise<void> {
    console.log('SubjectManagementPage: Received new subject data from modal:', newSubjectData);
    this.isAddingSubject = true; // Indicate processing for adding
    this.errorMessage = null;    // Clear previous errors

    try {
      // Call the service to add the new subject
      const response: SubjectMutationResponse = await this.adminSubjectService.addSubject(newSubjectData);

      if (response.success) {
        alert(response.message || 'Subject added successfully!');
        this.loadSubjects(); // Refresh the list to show the new subject
      } else {
        // If backend indicates failure but HTTP was okay
        this.errorMessage = response.message || 'Failed to add subject due to a server-side issue.';
        alert(this.errorMessage);
      }
    } catch (error: any) { // Catches rejections from the service (e.g., client-side encryption error, or if handleHttpError re-throws)
      console.error('SubjectManagementPage: Error calling addSubject service:', error);
      this.errorMessage = (error && error.message) ? error.message : 'An unexpected error occurred while adding the subject.';
      alert(this.errorMessage);
    } finally {
      this.isAddingSubject = false;
      this.closeAddSubjectModal(); // Close modal regardless of success or failure of API call
    }
  }

  viewSubjectDetails(subjectId: string): void {
    console.log("SubjectManagementPage: Navigating to view details for subject ID:", subjectId);
    if (subjectId) {
      this.router.navigate(['/admin/subjects', subjectId]); // Navigate to the detail page
    } else {
      console.error("SubjectManagementPage: subjectId is undefined, cannot navigate.");
    }
  }
  // ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

  editSubject(subjectId: string): void {
    console.log("SubjectManagementPage: Navigating to edit subject ID:", subjectId);
    if (subjectId) {
      this.router.navigate(['/admin/subjects', subjectId, 'edit']);
    } else {
      console.error("SubjectManagementPage: subjectId is undefined, cannot navigate to edit.");
    }
  }
}