import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubjectManagementPageComponent } from './subject-management-page.component';

describe('SubjectManagementPageComponent', () => {
  let component: SubjectManagementPageComponent;
  let fixture: ComponentFixture<SubjectManagementPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SubjectManagementPageComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SubjectManagementPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
