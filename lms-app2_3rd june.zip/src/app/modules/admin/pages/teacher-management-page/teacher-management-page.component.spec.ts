import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeacherManagementPageComponent } from './teacher-management-page.component';

describe('TeacherManagementPageComponent', () => {
  let component: TeacherManagementPageComponent;
  let fixture: ComponentFixture<TeacherManagementPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TeacherManagementPageComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TeacherManagementPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
