// src/middlewares/auth.middleware.js
import jwt from 'jsonwebtoken';
import config from '../config/env.config.js'; // Correct path needed
import User from '../models/user.model.js';   // Correct path needed
import { ApiError } from '../utils/apiResponse.utils.js'; // Correct path needed
import asyncHandler from '../utils/asyncHandler.utils.js'; // Correct path needed

// NAMED EXPORT
export const protect = asyncHandler(async (req, res, next) => {
    let token;
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
        try {
            token = req.headers.authorization.split(' ')[1];
            const decoded = jwt.verify(token, config.jwtSecret);

            req.user = await User.findById(decoded.user.id).select('-credentials').populate({
                path: 'roles.role_id',
                select: 'name permissions'
            });

            if (!req.user) {
                return next(new ApiError(401, 'Not authorized, user not found for token.')); // Use return next()
            }
            next();
        } catch (error) {
            console.error('Auth middleware error:', error.message);
            if (error.name === 'TokenExpiredError') {
                return next(new ApiError(401, 'Not authorized, token expired.')); // Use return next()
            }
            return next(new ApiError(401, 'Not authorized, token failed verification.')); // Use return next()
        }
    }
    if (!token) {
        return next(new ApiError(401, 'Not authorized, no token provided.')); // Use return next()
    }
});

// If you have other middleware functions in this file, export them similarly:
// export const anotherMiddleware = asyncHandler(async (req, res, next) => { /* ... */ });