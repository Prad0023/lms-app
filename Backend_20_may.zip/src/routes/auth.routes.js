import { Router } from 'express';
// We'll import controllers and middlewares later
import { authController } from '../controllers/auth.controller.js';
const router = Router();

// Placeholder route
router.get('/', (req, res) => {
    res.send('Auth routes are working!');
});
router.get('/public-key', authController.getPublicKey);
router.post('/register-first-admin', authController.registerFirstAdmin); // Correct path and controller method
router.post('/login', authController.login);

export default router;