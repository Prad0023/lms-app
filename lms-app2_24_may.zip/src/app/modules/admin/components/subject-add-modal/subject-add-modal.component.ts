import { Component, EventEmitter, Output, OnInit, ViewChild, ElementRef } from '@angular/core'; // Added ViewChild, ElementRef
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { SubjectBasicInfo } from '../../models/subject.model';
import { MinimalCourseInfo } from '../../models/course.model';
import { AdminSubjectService } from '../../services/admin-subject.service';

@Component({
  selector: 'app-subject-add-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './subject-add-modal.component.html',
})
export class SubjectAddModalComponent implements OnInit {
  @Output() closeModal = new EventEmitter<void>();
  @Output() subjectAdded = new EventEmitter<SubjectBasicInfo>();

  addSubjectForm: FormGroup;
  isLoading = false;
  isLoadingCourses = false;
  availableCourses: MinimalCourseInfo[] = [];

  selectedCourses: MinimalCourseInfo[] = [];
  filteredCourses: MinimalCourseInfo[] = [];
  courseSearchTerm: string = '';
  showCourseSuggestions: boolean = false;
  highlightedIndex: number = -1;
  searchFocusTimeout: any;

  // ViewChild to get a reference to the input element
  @ViewChild('courseSearchTagInput') courseSearchTagInputRef!: ElementRef<HTMLInputElement>;
  @ViewChild('tagInputContainer') tagInputContainerRef!: ElementRef<HTMLDivElement>;


  constructor(
    private fb: FormBuilder,
    private adminSubjectService: AdminSubjectService
  ) {
    this.addSubjectForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required],
      assignedCourseIds: [[]]
    });
  }

  ngOnInit(): void {
    this.loadCoursesForSelection();
  }

  async loadCoursesForSelection(): Promise<void> {
    this.isLoadingCourses = true;
    try {
      this.availableCourses = await this.adminSubjectService.getCoursesForSelection();
      this.filteredCourses = this.getAvailableCourses(); // Initialize based on available and not selected
      // console.log("Available courses for dropdown:", this.availableCourses);
    } catch (error) {
      console.error("Error loading courses for selection in modal:", error);
    } finally {
      this.isLoadingCourses = false;
    }
  }

  get f() { return this.addSubjectForm.controls; }

  focusTagInput(event?: MouseEvent): void {
    // Prevent focusing if the click was on a remove button inside a tag
    if (event && (event.target as HTMLElement).closest('.course-tag-remove')) {
        return;
    }
    if (this.courseSearchTagInputRef) {
        this.courseSearchTagInputRef.nativeElement.focus();
    }
  }

  onCourseSearch(event: any): void {
    const searchTerm = event.target.value.toLowerCase().trim();
    this.courseSearchTerm = searchTerm;
    this.highlightedIndex = -1;

    if (searchTerm === '') {
      this.filteredCourses = this.getAvailableCourses();
    } else {
      this.filteredCourses = this.getAvailableCourses().filter(course =>
        course.name.toLowerCase().includes(searchTerm) ||
        (course.description && course.description.toLowerCase().includes(searchTerm))
      );
    }
    this.showCourseSuggestions = this.filteredCourses.length > 0 || searchTerm !== '';
  }

  onSearchFocus(): void {
    clearTimeout(this.searchFocusTimeout);
    // Refresh suggestions based on currently available (not selected) courses
    this.filteredCourses = this.getAvailableCourses().filter(course =>
        this.courseSearchTerm === '' || // show all available if search is empty
        course.name.toLowerCase().includes(this.courseSearchTerm.toLowerCase()) ||
        (course.description && course.description.toLowerCase().includes(this.courseSearchTerm.toLowerCase()))
    );
    this.showCourseSuggestions = this.filteredCourses.length > 0 || this.courseSearchTerm !== '';
  }

  onSearchBlur(): void {
    this.searchFocusTimeout = setTimeout(() => {
      this.showCourseSuggestions = false;
      this.highlightedIndex = -1;
    }, 150); // Delay to allow click on suggestion
  }

  onTagInputKeydown(event: KeyboardEvent): void {
    // Standard keyboard navigation for suggestions
    if (this.showCourseSuggestions && this.filteredCourses.length > 0) {
        switch (event.key) {
            case 'ArrowDown':
                event.preventDefault();
                this.highlightedIndex = Math.min(this.highlightedIndex + 1, this.filteredCourses.length - 1);
                this.ensureHighlightedVisible();
                return; // Handled
            case 'ArrowUp':
                event.preventDefault();
                this.highlightedIndex = Math.max(this.highlightedIndex - 1, 0);
                this.ensureHighlightedVisible();
                return; // Handled
            case 'Enter':
                event.preventDefault();
                if (this.highlightedIndex >= 0 && this.highlightedIndex < this.filteredCourses.length) {
                    this.addCourse(this.filteredCourses[this.highlightedIndex]);
                }
                return; // Handled
            case 'Escape':
                this.closeCourseSuggestions();
                return; // Handled
        }
    }

    // Tag-specific keyboard actions
    switch (event.key) {
        case 'Backspace':
            if (this.courseSearchTerm === '' && this.selectedCourses.length > 0) {
                event.preventDefault(); // Prevent browser back navigation
                this.removeCourse(this.selectedCourses[this.selectedCourses.length - 1]);
            }
            break;
        // case 'Enter': // If not handled by suggestion selection, and input is not empty (potential new tag creation - advanced)
        //     // For now, Enter is primarily for selecting a highlighted suggestion.
        //     break;
    }
  }

  private ensureHighlightedVisible(): void {
    // Basic implementation: scroll the highlighted item into view if suggestions list is scrollable
    if (this.highlightedIndex < 0 || !this.showCourseSuggestions) return;
    const listElement = document.getElementById('course-suggestions-list');
    const itemElement = document.getElementById('course-option-' + this.highlightedIndex);
    if (listElement && itemElement) {
        const listRect = listElement.getBoundingClientRect();
        const itemRect = itemElement.getBoundingClientRect();
        if (itemRect.bottom > listRect.bottom) {
            listElement.scrollTop += itemRect.bottom - listRect.bottom;
        } else if (itemRect.top < listRect.top) {
            listElement.scrollTop -= listRect.top - itemRect.top;
        }
    }
  }

  private getAvailableCourses(): MinimalCourseInfo[] {
    return this.availableCourses.filter(course =>
      !this.selectedCourses.some(selected => selected._id === course._id)
    );
  }

  closeCourseSuggestions(): void {
    this.showCourseSuggestions = false;
    this.highlightedIndex = -1;
  }

  addCourse(course: MinimalCourseInfo, event?: Event): void {
    if (event) {
      event.stopPropagation(); // Stop event from bubbling (e.g., to onSearchBlur or container click)
      event.preventDefault();
    }

    if (!this.isCourseSelected(course)) {
      this.selectedCourses.push(course);
      this.updateFormControl();
      this.courseSearchTerm = ''; // Clear search term
      this.closeCourseSuggestions();

      // Refresh filtered courses for next interaction (after timeout to allow DOM update)
      setTimeout(() => {
        this.filteredCourses = this.getAvailableCourses();
        if (this.courseSearchTagInputRef) {
            this.courseSearchTagInputRef.nativeElement.value = ''; // Ensure visual clear
            this.courseSearchTagInputRef.nativeElement.focus();
        }
      }, 0);
    }
  }

  removeCourse(courseToRemove: MinimalCourseInfo, event?: MouseEvent): void {
    if (event) {
        event.stopPropagation(); // Prevent container click focus
        event.preventDefault();
    }
    this.selectedCourses = this.selectedCourses.filter(c => c._id !== courseToRemove._id);
    this.updateFormControl();

    // After removing, refresh the filtered list and keep focus
    this.filteredCourses = this.getAvailableCourses().filter(course =>
        this.courseSearchTerm === '' ||
        course.name.toLowerCase().includes(this.courseSearchTerm.toLowerCase()) ||
        (course.description && course.description.toLowerCase().includes(this.courseSearchTerm.toLowerCase()))
    );
    
    if (this.courseSearchTagInputRef) {
      this.courseSearchTagInputRef.nativeElement.focus();
    }
  }

  clearAllCourses(): void {
    this.selectedCourses = [];
    this.updateFormControl();
    this.filteredCourses = this.getAvailableCourses(); // Refresh suggestions
    if (this.courseSearchTagInputRef) {
        this.courseSearchTagInputRef.nativeElement.focus();
    }
  }

  trackByCourseId(index: number, course: MinimalCourseInfo): string {
    return course._id;
  }

  isCourseSelected(course: MinimalCourseInfo): boolean {
    return this.selectedCourses.some(c => c._id === course._id);
  }

  private updateFormControl(): void {
    const selectedIds = this.selectedCourses.map(course => course._id);
    this.addSubjectForm.patchValue({
      assignedCourseIds: selectedIds
    });
    this.addSubjectForm.get('assignedCourseIds')?.markAsDirty();
    this.addSubjectForm.get('assignedCourseIds')?.updateValueAndValidity();
  }

  onSubmit(): void {
    if (this.addSubjectForm.invalid) {
      this.addSubjectForm.markAllAsTouched();
      return;
    }
    this.isLoading = true;
    // ... (rest of submit logic is fine) ...
    const formValue = this.addSubjectForm.value;
    const subjectPayload: SubjectBasicInfo = {
      name: formValue.name,
      description: formValue.description,
      assignedCourseIds: formValue.assignedCourseIds || []
    };

    console.log("SubjectAddModal: Submitting subject payload:", subjectPayload);
    this.adminSubjectService.addSubject(subjectPayload).then(response => {
      if (response.success) {
        this.subjectAdded.emit(subjectPayload as SubjectBasicInfo);
        alert(response.message || 'Subject added successfully!');
        this.closeModal.emit();
      } else {
        alert(`Failed to add subject: ${response.message || 'Unknown error'}`);
      }
    }).catch(err => {
      const errorMessage = (err && err.error && err.error.message) ? err.error.message : (err && err.message) ? err.message : 'An error occurred. Please try again.';
      alert(`Error adding subject: ${errorMessage}`);
    }).finally(() => {
      this.isLoading = false;
    });
  }

  onCancel(): void {
    this.closeModal.emit();
  }
}