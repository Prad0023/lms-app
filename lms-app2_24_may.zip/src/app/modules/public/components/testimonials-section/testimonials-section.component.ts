import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ScrollAnimationDirective } from '../../../../directives/scroll-animation.directive';

interface Testimonial {
  quote: string;
  name: string;
  title: string;
  imageUrl: string;
}

@Component({
  selector: 'app-testimonials-section',
  standalone: true,
  imports: [CommonModule, ScrollAnimationDirective],
  templateUrl: './testimonials-section.component.html',
})
export class TestimonialsSectionComponent {
  testimonials: Testimonial[] = [
    {
      quote: "Abhyasify's interactive playgrounds made learning to code so much more engaging and effective. I feel much more confident in my skills!",
      name: 'Sarah L.',
      title: 'Software Developer Student',
      imageUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80'
    },
    {
      quote: "The personalized feedback and progress tracking are fantastic. I was able to pinpoint my weaknesses and focus on improving them.",
      name: 'John B.',
      title: 'Aspiring Data Scientist',
      imageUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80'
    },
    {
      quote: "As an instructor, Abhyasify has streamlined how I create and manage assignments. My students love the platform!",
      name: 'Dr. Emily K.',
      title: 'University Professor',
      imageUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80'
    }
  ];
}