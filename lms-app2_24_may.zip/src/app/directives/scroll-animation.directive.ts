// src/app/directives/scroll-animation.directive.ts
import { Directive, ElementRef, Renderer2, OnInit, OnDestroy, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common'; // Import isPlatformBrowser

@Directive({
  selector: '[appScrollAnimation]',
  standalone: true,
})
export class ScrollAnimationDirective implements OnInit, OnDestroy {
  private observer!: IntersectionObserver; // '!' asserts it will be initialized if in browser

  // Inject PLATFORM_ID
  constructor(
    private el: ElementRef,
    private renderer: Renderer2,
    @Inject(PLATFORM_ID) private platformId: Object // Use Object type
  ) {}

  ngOnInit() {
    // Only execute IntersectionObserver logic if in a browser environment
    if (isPlatformBrowser(this.platformId)) {
      this.observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            this.renderer.addClass(this.el.nativeElement, 'is-visible');
            // Optional: Unobserve after first animation
            // this.observer.unobserve(this.el.nativeElement);
          } else {
            // Optional: Remove class if you want animation to repeat on scroll out/in
            // this.renderer.removeClass(this.el.nativeElement, 'is-visible');
          }
        });
      }, { threshold: 0.1 }); // Adjust threshold as needed

      this.renderer.addClass(this.el.nativeElement, 'reveal-on-scroll'); // Initial state
      this.observer.observe(this.el.nativeElement);
    }
  }

  ngOnDestroy() {
    // Also check if observer was initialized (i.e., in browser) before disconnecting
    if (isPlatformBrowser(this.platformId) && this.observer) {
      this.observer.disconnect();
    }
  }
}