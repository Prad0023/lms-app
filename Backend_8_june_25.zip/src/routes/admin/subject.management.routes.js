// src/routes/admin/subject.management.routes.js
import { Router } from 'express';
import { subjectController } from '../../controllers/academic/subject.controller.js'; // Adjust path
import { protect } from '../../middlewares/auth.middleware.js';
import { authorizePermission } from '../../middlewares/role.middleware.js';

const router = Router();

/**
 * @route   POST /api/v1/admin/subjects/create
 * @desc    Admin creates a new subject.
 *          Encrypted Payload: { SubjectName, SubjectDescription, ... }
 * @access  Private (Admin with 'subject_create' permission)
 */
router.post(
    '/create',
    protect,
    authorizePermission('subject', 'create'), // Define this permission for admin role
    subjectController.createSubject
);

/**
 * @route   GET /api/v1/admin/subjects/view-all
 * @desc    Admin views all subjects (response is encrypted).
 * @access  Private (Admin with 'subject_read_all' permission)
 */
router.get(
    '/view-subjects',
    protect,
    authorizePermission('subject', 'read_all'), // Define this permission for admin role
    subjectController.getAllSubjects
);

router.get(
    '/:subjectId', // Route parameter for the subject ID
    protect,
    authorizePermission('subject', 'read_one'), // Ensure admin role has this permission
    subjectController.getSubjectById
);


// router.post(
//     '/modules-create/:subjectId',
//     protect,
//     authorizePermission('subject', 'update'), // Ensure admin role has this permission
//     subjectController.updateSubject
// );
router.post(
    '/:subjectId/modules-topics', // <--- CURRENTLY DEFINED ROUTE
    protect,
    authorizePermission('subject', 'update'),
    subjectController.addModulesAndTopics
);
router.post(
    '/modules-create/:subjectId',
    // '/:subjectId/modules-topics', // Changed route to be more RESTful and descriptive
    protect,
    authorizePermission('subject', 'update'), // Or more granular 'module_create', 'topic_create'
    subjectController.addModulesAndTopics
);

export default router;