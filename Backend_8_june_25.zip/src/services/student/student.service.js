import crypto from 'crypto';
import mongoose from 'mongoose';
import User from '../../models/user.model.js';
import Role from '../../models/role.model.js';
import OnboardingToken from '../../models/onboardingToken.model.js'; // Ensure this path is correct
import { ApiError } from '../../utils/apiResponse.utils.js';        // Adjust path
import { logAuditEvent } from '../common/audit.service.js';        // Adjust path, assuming audit.service.js is in common
import { ROLES } from '../common/seed.service.js';                 // Adjust path
import { generateTemporaryPassword } from '../../utils/password.utils.js'; // Adjust path
import { sendStudentOnboardingEmail } from '../common/email.service.js'; // Create this function in email.service.js

const ONBOARDING_TOKEN_EXPIRY_HOURS = 72; // Students might take longer

export const studentService = {
    getAllStudents: async () => {
        const studentRole = await Role.findOne({ name: ROLES.STUDENT });
        if (!studentRole) {
            throw new ApiError(500, 'Student role not found. Cannot fetch students.');
        }

        // Find users who have the student role
        // Exclude sensitive fields.
        const students = await User.find({ "roles.role_id": studentRole._id })
            .select('-credentials -roles._id -roles.granted_at -roles.granted_by -roles.expires_at -oauth_accounts -email_verification_token -mobile_verification_code -created_by')
            .sort({ created_at: -1 });

        // Transform to plain objects
        return students.map(student => student.toObject());
    },

    
    initiateStudentEnrollmentByAdmin: async (enrollmentRequestData, adminUserId, ipAddress, userAgent) => {
        const { studentInfo, sendInviteEmail } = enrollmentRequestData;
        const { fullName, email, mobile, course } = studentInfo; // 'course' is for context, not directly stored on User model here

        if (!fullName || !email) { // Mobile and course might be optional initially
            throw new ApiError(400, 'Missing required fields in studentInfo (fullName, email).');
        }

        const existingUser = await User.findOne({ email });
        const studentRole = await Role.findOne({ name: ROLES.STUDENT });
        if (!studentRole) {
            throw new ApiError(500, 'Student role not found. Please seed roles.');
        }

        if (existingUser) {
            const hasActiveStudentRole = existingUser.roles.some(
                r => r.role_id.toString() === studentRole._id.toString()
            ) && existingUser.is_active;

            if (hasActiveStudentRole || (existingUser.is_active && existingUser.status !== 'pending_setup')) {
                throw new ApiError(409, `User with email ${email} already exists as an active student or is an active user not pending setup.`);
            }
        }

        const tempPasswordDetails = generateTemporaryPassword();
        const adminObjectId = new mongoose.Types.ObjectId(adminUserId);

        let newStudent;
        let isReInitiation = false;

        const studentRoleEntry = {
            role_id: studentRole._id,
            granted_at: new Date(),
            granted_by: adminObjectId,
            expires_at: null
        };

        if (existingUser && existingUser.status === 'pending_setup') {
            isReInitiation = true;
            existingUser.full_name = fullName;
            existingUser.mobile_number = mobile || existingUser.mobile_number; // Update if provided
            // 'course' is not directly on User model in this design, but could be logged or used elsewhere
            existingUser.credentials = { password_hash: tempPasswordDetails.plain };
            existingUser.status = 'pending_setup';
            existingUser.is_active = false;
            existingUser.email_verified = false;
            existingUser.mobile_verified = false;
            existingUser.updated_at = new Date();
            
            existingUser.roles = existingUser.roles.filter(
                r => r.role_id.toString() !== studentRole._id.toString()
            );
            existingUser.roles.push(studentRoleEntry);

            newStudent = await existingUser.save();
            await OnboardingToken.updateMany({ user_id: newStudent._id, token_type: 'student_onboarding', used: false }, { $set: { used: true, expires_at: new Date() } });
            console.log(`[StudentService] Re-initiating setup for existing pending student: ${email}`);
        } else {
            newStudent = await User.create({
                full_name: fullName,
                email,
                mobile_number: mobile,
                // 'course' info isn't directly on User model currently. Could add a field like 'initial_course_interest'
                credentials: {
                    password_hash: tempPasswordDetails.plain,
                },
                status: 'pending_setup',
                created_by: adminObjectId,
                is_active: false,
                email_verified: false,
                mobile_verified: false,
                roles: [studentRoleEntry],
            });
            console.log(`[StudentService] Created new pending student: ${email}`);
        }

        const onboardingTokenPlain = crypto.randomBytes(32).toString('hex');
        const onboardingTokenHash = crypto.createHash('sha256').update(onboardingTokenPlain).digest('hex');
        const expiresAt = new Date(Date.now() + ONBOARDING_TOKEN_EXPIRY_HOURS * 60 * 60 * 1000);

        await OnboardingToken.create({
            user_id: newStudent._id,
            token_hash: onboardingTokenHash,
            token_type: 'student_onboarding', // Specific type for students
            expires_at: expiresAt,
        });

        let responseMessage = `Student '${fullName}' ${isReInitiation ? 'enrollment re-initiated' : 'enrollment initiated'}. Marked for setup.`;

        if (sendInviteEmail === true) {
            const frontendBaseUrl = process.env.FRONTEND_URL || 'http://localhost:4200';
            const completeProfileLink = `${frontendBaseUrl}/student-onboarding?token=${onboardingTokenPlain}`; // Example link

            try {
                await sendStudentOnboardingEmail(newStudent.email, newStudent.full_name, completeProfileLink, tempPasswordDetails.plain);
                responseMessage = `Student '${fullName}' ${isReInitiation ? 'enrollment re-initiated' : 'enrollment initiated'}. An onboarding email has been sent to ${email}.`;
            } catch (emailError) {
                console.error(`[StudentService] Failed to send student onboarding email for ${email}:`, emailError);
                responseMessage += " However, there was an issue sending the onboarding email.";
            }
        }

        await logAuditEvent({
            userId: adminObjectId,
            event_type: 'student_management',
            resource: 'users',
            resource_id: newStudent._id,
            action: 'initiate_enrollment',
            status: 'success',
            ip_address: ipAddress,
            user_agent: userAgent,
            details: {
                student_email: email,
                course_interest: course, // Log the course from input
                sendEmailInitiated: sendInviteEmail === true,
                action_type: isReInitiation ? 're_initiate_enrollment' : 'new_enrollment_initiate',
                assigned_role: ROLES.STUDENT
            }
        });

        return {
            message: responseMessage,
            studentId: newStudent._id,
        };
    },
};