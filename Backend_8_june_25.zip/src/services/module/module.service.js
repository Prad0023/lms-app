// src/services/module/module.service.js
import mongoose from 'mongoose';
import Module from '../../models/module.model.js';
import Topic from '../../models/topic.model.js';
import Subject from '../../models/subject.model.js'; // To verify subjectId if needed
import { ApiError } from '../../utils/apiResponse.utils.js';
import { logAuditEvent } from '../common/audit.service.js'; // Adjust path

export const moduleService = {
    bulkCreateTopicsForModule: async (subjectId, moduleId, topicsDataArray, adminUserId) => {
        if (!mongoose.Types.ObjectId.isValid(subjectId) || !mongoose.Types.ObjectId.isValid(moduleId)) {
            throw new ApiError(400, 'Invalid Subject ID or Module ID format.');
        }

        // Verify module exists and belongs to the subject
        const module = await Module.findOne({ _id: moduleId, SubjectID: subjectId });
        if (!module) {
            throw new ApiError(404, `Module with ID ${moduleId} not found under Subject ID ${subjectId}.`);
        }

        if (!topicsDataArray || !Array.isArray(topicsDataArray) || topicsDataArray.length === 0) {
            throw new ApiError(400, 'No topics data provided to create.');
        }

        const createdTopics = [];
        const topicsToInsert = [];

        for (const topicItem of topicsDataArray) {
            if (!topicItem.TopicName) {
                // Or use a default name, or skip, or collect errors
                console.warn(`[ModuleService] Skipping topic creation due to missing TopicName for module ${moduleId}. Topic data:`, topicItem);
                continue; // Skip this topic if name is missing
            }
            topicsToInsert.push({
                TopicName: topicItem.TopicName,
                ModuleID: module._id, // Link to the current module
                TopicContent: topicItem.TopicContent,
                TopicVideos: topicItem.TopicVideos || [],
                sequence_order: topicItem.sequence_order || 0,
                created_by: adminUserId,
                // ... other topic fields from topicItem
            });
        }

        if (topicsToInsert.length === 0) {
            throw new ApiError(400, 'No valid topics data provided after filtering for TopicName.');
        }

        // Bulk insert valid topics
        const insertedTopics = await Topic.insertMany(topicsToInsert);
        createdTopics.push(...insertedTopics.map(t => t.toObject()));


        // Optional: If your Module schema has a 'ModuleTopics' array to store Topic IDs
        // you would update the module here:
        // module.ModuleTopics.push(...insertedTopics.map(t => t._id));
        // await module.save();

        await logAuditEvent({
            userId: adminUserId,
            event_type: 'topic_management',
            resource: 'topics',
            // resource_id: null, // Or store module_id / subject_id
            action: 'bulk_create',
            status: 'success',
            details: {
                module_id: module._id,
                subject_id: subjectId,
                topics_created_count: createdTopics.length
            }
        });

        return {
            message: `Successfully created ${createdTopics.length} topics for module '${module.ModuleName}'.`,
            moduleId: module._id,
            createdTopicsCount: createdTopics.length,
            createdTopics: createdTopics // Return the actual created topic objects
        };
    },

    // Other module service methods:
    // createModuleForSubject: async (subjectId, moduleData, adminUserId) => { ... }
    // getModuleById: async (moduleId) => { ... }
    // updateModule: async (moduleId, updateData, adminUserId) => { ... }
    // deleteModule: async (moduleId, adminUserId) => { ... }
};