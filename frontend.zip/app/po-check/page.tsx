// app/po-check/page.tsx
"use client"

import React, { useState, useEffect, useCallback } from 'react';
import LoadingSpinner from '@/components/ui/loading-spinner';
import { useToast } from '@/components/ui/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const API_BASE_URL = "http://127.0.0.1:8000";

// --- TypeScript Interfaces ---
interface PORecord {
    id: number;
    pono: string;
    po_date: string;
    customername: string;
    re11no: string;
    status: boolean;
    reason: string;
    created_at: string;
}

interface Filters {
    status: 'all' | 'done' | 'pending';
    customer: string;
    pono: string;
}

// --- Bot Running Overlay ---
const BotRunningOverlay = () => (
  <div className="fixed inset-0 bg-gray-900 bg-opacity-80 flex flex-col items-center justify-center z-50 backdrop-blur-sm">
    <LoadingSpinner size="lg" />
    <h2 className="text-white text-3xl font-bold mt-6">Bot is Running...</h2>
    <p className="text-gray-300 mt-2">The application is locked until the process completes.</p>
  </div>
);

// --- Reusable Component for the main content (filters and table) ---
const PortalContent = ({ portal, onBotNameChange }: {
    portal: 'b2b' | 'crm',
    onBotNameChange: (botName: string) => void
}) => {
    const { toast } = useToast();
    const [poRecords, setPoRecords] = useState<PORecord[]>([]);
    const [allCustomers, setAllCustomers] = useState<string[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [filters, setFilters] = useState<Filters>({
        status: 'all',
        customer: '',
        pono: ''
    });

    const fetchPOData = useCallback(async (currentFilters: Filters, currentPortal: string) => {
        setIsLoading(true);
        const params = new URLSearchParams({
            portal: currentPortal,
            status: currentFilters.status,
            customer: currentFilters.customer,
            pono: currentFilters.pono
        });

        try {
            const response = await fetch(`${API_BASE_URL}/order/rpa-po-status/?${params.toString()}`);
            if (!response.ok) throw new Error("Failed to fetch PO status data.");
            const data = await response.json();
            setPoRecords(data.poRecords || []);
            setAllCustomers(data.allCustomers || []);
            onBotNameChange(data.rpaBotName || ''); // Report bot name back to parent
        } catch (error: any) {
            toast({ variant: "destructive", title: "API Error", description: error.message });
        } finally {
            setIsLoading(false);
        }
    }, [toast, onBotNameChange]);

    useEffect(() => {
        fetchPOData(filters, portal);
    }, [portal, filters, fetchPOData]);

    // ... (Filter handling functions: handleFilterChange, handleClearFilters) ...
    const handleFilterChange = (field: keyof Filters, value: string) => {
        setFilters(prev => ({ ...prev, [field]: value }));
    };

    const handleClearFilters = () => {
        setFilters({ status: 'all', customer: '', pono: '' });
    };


    if (isLoading) {
        return <div className="p-10 flex justify-center"><LoadingSpinner size="lg" /></div>;
    }

    return (
        <div className="space-y-6 mt-4">
            <div className="bg-white p-4 rounded-lg shadow-md flex flex-wrap items-end gap-6">
                {/* ... (Filter JSX is the same as before) ... */}
                 <div className="flex items-center space-x-4">
                    <span className="font-medium text-gray-700">Show:</span>
                    {(['all', 'done', 'pending'] as const).map(value => (
                        <label key={value} className="inline-flex items-center space-x-1 cursor-pointer">
                            <input type="radio" name={`status-${portal}`} value={value} checked={filters.status === value} onChange={() => handleFilterChange('status', value)} className="form-radio h-4 w-4 text-indigo-600"/>
                            <span>{value.charAt(0).toUpperCase() + value.slice(1)}</span>
                        </label>
                    ))}
                </div>
                <div className="flex-1 min-w-[200px]">
                    <label htmlFor={`customer-${portal}`} className="block text-sm font-medium text-gray-700 mb-1">Customer</label>
                    <select id={`customer-${portal}`} value={filters.customer} onChange={(e) => handleFilterChange('customer', e.target.value)} className="w-full border-gray-300 rounded-md shadow-sm p-2">
                        <option value="">All Customers</option>
                        {allCustomers.map(customer => (<option key={customer} value={customer}>{customer}</option>))}
                    </select>
                </div>
                <div className="w-48">
                    <label htmlFor={`pono-${portal}`} className="block text-sm font-medium text-gray-700 mb-1">PO Number</label>
                    <input type="text" id={`pono-${portal}`} value={filters.pono} onChange={(e) => handleFilterChange('pono', e.target.value)} placeholder="Enter PO #" className="w-full border-gray-300 rounded-md shadow-sm p-2"/>
                </div>
                <div><button onClick={handleClearFilters} className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded">Clear</button></div>
            </div>

            <div className="overflow-x-auto bg-white rounded shadow-md">
                {poRecords.length > 0 ? (
                    <table className="min-w-full table-auto">
                        <thead className="bg-gray-100">
                           {/* ... (Table Header JSX is the same as before) ... */}
                            <tr className="divide-x divide-gray-200"><th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">PO Number</th><th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">PO Date</th><th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">Customer</th><th className="px-4 py-3 text-center text-xs font-medium text-gray-600 uppercase">Status</th><th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">Reason for Failure</th></tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {poRecords.map(po => (
                                <tr key={po.id} className="hover:bg-gray-50">
                                    <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-800">{po.pono}</td><td className="px-4 py-2 whitespace-nowrap text-sm text-gray-800">{po.po_date ? new Date(po.po_date).toLocaleDateString() : '-'}</td><td className="px-4 py-2 text-sm text-gray-800">{po.customername}</td><td className="px-4 py-2 text-center text-xl"><span title={po.status ? 'Done' : 'Pending'}>{po.status ? '🟢' : '🔴'}</span></td><td className={`px-4 py-2 text-sm ${!po.status ? 'text-red-600 font-medium' : 'text-gray-800'}`}>{po.reason}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <div className="p-8 text-center text-gray-500">No PO records found matching your criteria.</div>
                )}
            </div>
        </div>
    );
};


// --- Main Page Component That Contains the Tabs and Shared State ---
const POCheckStatusPageContainer = () => {
    const { toast } = useToast();
    const [activePortal, setActivePortal] = useState<'b2b' | 'crm'>('b2b');
    const [rpaBotName, setRpaBotName] = useState('');
    const [isRunningBot, setIsRunningBot] = useState(false);

    // This function will be called by the child component to update the bot name
    const handleBotNameChange = useCallback((botName: string) => {
        setRpaBotName(botName);
    }, []);

    const runPOCheckBot = async () => {
        if (!rpaBotName) {
            toast({ variant: "destructive", title: "Error", description: "Bot name not available. Cannot trigger." });
            return;
        }

        setIsRunningBot(true); // Show overlay
        try {
            const response = await fetch(`${API_BASE_URL}/order/rpa/trigger/`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ bot_name: rpaBotName }),
            });

            const result = await response.json();
            if (!response.ok) {
                throw new Error(result.message || `Failed to trigger the '${rpaBotName}' bot.`);
            }

            toast({ title: "Success", description: `The '${rpaBotName}' bot has been triggered successfully.` });

            // Simulate bot running and then hide overlay
            setTimeout(() => {
                toast({ title: "Process Complete", description: "You may need to refresh data to see updates." });
                setIsRunningBot(false);
            }, 8000); // Lock screen for 8 seconds

        } catch (error: any) {
            toast({ variant: "destructive", title: "RPA Error", description: error.message });
            setIsRunningBot(false);
        }
    };

    return (
        <>
            {isRunningBot && <BotRunningOverlay />}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <div className="flex justify-between items-center mb-8">
                    <h1 className="text-3xl font-bold text-black">RPA PO Status Check</h1>
                    <button
                        onClick={runPOCheckBot}
                        disabled={isRunningBot || !rpaBotName}
                        className="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded flex items-center transition-opacity disabled:opacity-50"
                    >
                        {isRunningBot && <LoadingSpinner />}
                        <span className="ml-2">
                            {isRunningBot ? 'Running...' : (rpaBotName ? `Run '${rpaBotName}' Bot` : 'Run Bot')}
                        </span>
                    </button>
                </div>
                
                <Tabs defaultValue="b2b" className="w-full" onValueChange={(value) => setActivePortal(value as 'b2b' | 'crm')}>
                    <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="b2b">B2B Portal</TabsTrigger>
                        <TabsTrigger value="crm">CRM Portal</TabsTrigger>
                    </TabsList>
                    <TabsContent value="b2b">
                        <PortalContent portal="b2b" onBotNameChange={handleBotNameChange} />
                    </TabsContent>
                    <TabsContent value="crm">
                        <PortalContent portal="crm" onBotNameChange={handleBotNameChange} />
                    </TabsContent>
                </Tabs>
            </div>
        </>
    );
};

export default POCheckStatusPageContainer;