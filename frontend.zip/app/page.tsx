// app/data-upload/page.tsx
"use client"

import type React from "react"
import { useState, useCallback } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs" // Assuming shadcn/ui Tabs component
import LoadingSpinner from "@/components/ui/loading-spinner"
import { useToast } from "@/components/ui/use-toast" // Corrected import based on your folder structure

// Define the structure for a file to be uploaded
interface UploadableFile {
  id: string
  file: File // Store the actual File object
  name: string
  size: number
  status: "pending" | "uploading" | "success" | "error"
  error?: string // Optional field to store error messages
}

// IMPORTANT: Replace this with the actual base URL of your Django backend
const API_BASE_URL = "http://127.0.0.1:8000"

const DataUploadPage = () => {
  const [files, setFiles] = useState<UploadableFile[]>([])
  const [isUploading, setIsUploading] = useState(false)
  const [dragActive, setDragActive] = useState(false)
  const [activeTab, setActiveTab] = useState("b2b") // Track the active tab
  const { toast } = useToast()

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }, [])

  const addFiles = (newFiles: File[]) => {
    const uploadedFiles: UploadableFile[] = newFiles.map((file) => ({
      id: Math.random().toString(36).substr(2, 9),
      file: file, // Keep the file object
      name: file.name,
      size: file.size,
      status: "pending",
    }))
    setFiles((prev) => [...prev, ...uploadedFiles])
  }

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)
    if (e.dataTransfer.files) {
        addFiles(Array.from(e.dataTransfer.files))
    }
  }, [])

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      addFiles(Array.from(e.target.files))
    }
  }

  const removeFile = (id: string) => {
    setFiles((prev) => prev.filter((f) => f.id !== id))
  }

  const handleUpload = async () => {
    const filesToUpload = files.filter((f) => f.status === "pending")
    if (filesToUpload.length === 0) {
      toast({
        title: "No files to upload.",
        description: "Please select new files with a 'pending' status.",
      })
      return
    }

    setIsUploading(true)

    const endpoint = activeTab === "b2b" ? `${API_BASE_URL}/order/upload/` : `${API_BASE_URL}/order/upload_crm/`

    for (const file of filesToUpload) {
      // Set status to "uploading" for the current file
      setFiles((prev) =>
        prev.map((f) => (f.id === file.id ? { ...f, status: "uploading" } : f))
      )

      const formData = new FormData()
      formData.append("excel_file", file.file) // The key must match your Django form field name

      try {
        const response = await fetch(endpoint, {
          method: "POST",
          body: formData,
          // Note: Do not set 'Content-Type' header. The browser will do it correctly for FormData.
        })

        if (response.ok) {
          // Update status to "success"
          setFiles((prev) =>
            prev.map((f) => (f.id === file.id ? { ...f, status: "success" } : f))
          )
        } else {
          // Handle server-side errors
          const errorData = await response.json()
          setFiles((prev) =>
            prev.map((f) =>
              f.id === file.id
                ? { ...f, status: "error", error: errorData.detail || "Upload failed" }
                : f
            )
          )
        }
      } catch (error) {
        // Handle network errors
        setFiles((prev) =>
          prev.map((f) =>
            f.id === file.id
              ? { ...f, status: "error", error: "Network error or server unavailable." }
              : f
          )
        )
      }
    }

    setIsUploading(false)
    toast({
      title: "Upload process finished.",
      description: "Check the status of each file.",
    })
  }
  
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  // A reusable component for the file upload area and list
  const FileUploadArea = () => (
    <div className="space-y-6">
      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors duration-200 ${
          dragActive ? "border-red-500 bg-red-50" : "border-gray-300 hover:border-red-400"
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <div className="space-y-4">
          <div className="text-4xl">📁</div>
          <div>
            <p className="text-lg font-medium text-black">Drop files here or click to browse</p>
            <p className="text-gray-600 mt-1">Supports CSV, Excel, and text files</p>
          </div>
          <input
            type="file"
            multiple
            onChange={handleFileSelect}
            className="hidden"
            id="file-upload"
            accept=".csv,.xlsx,.xls,.txt"
          />
          <label htmlFor="file-upload" className="btn-secondary cursor-pointer inline-block">
            Select Files
          </label>
        </div>
      </div>

      {files.length > 0 && (
        <div className="card p-6">
          <h3 className="text-lg font-semibold mb-4 text-black">Selected Files</h3>
          <div className="space-y-3">
            {files.map((file) => (
              <div key={file.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-md border">
                <div className="flex-1">
                  <p className="font-medium text-black">{file.name}</p>
                  <p className="text-sm text-gray-600">{formatFileSize(file.size)}</p>
                  {file.status === 'error' && <p className="text-sm text-red-600">{file.error}</p>}
                </div>
                <div className="flex items-center space-x-3">
                  {file.status === "uploading" && <LoadingSpinner />}
                  {file.status === "success" && <span className="text-green-600 font-bold text-xl">✓</span>}
                  {file.status === "error" && <span className="text-red-600 font-bold text-xl">✗</span>}
                  <button
                    onClick={() => removeFile(file.id)}
                    className="text-gray-400 hover:text-black transition-colors"
                    disabled={file.status === "uploading"}
                    aria-label="Remove file"
                  >
                    ✕
                  </button>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 flex justify-end">
            <button
              onClick={handleUpload}
              disabled={isUploading || files.every((f) => f.status !== "pending")}
              className="btn-primary flex items-center space-x-2"
            >
              {isUploading && <LoadingSpinner />}
              <span>{isUploading ? "Uploading..." : `Upload to ${activeTab.toUpperCase()}`}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  )

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-black">Data Upload Portal</h1>
        <p className="text-gray-600 mt-2">Upload your B2B and CRM data files for processing</p>
      </div>

      <Tabs defaultValue="b2b" onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="b2b">B2B Upload</TabsTrigger>
          <TabsTrigger value="crm">CRM Upload</TabsTrigger>
        </TabsList>
        <TabsContent value="b2b">
          <FileUploadArea />
        </TabsContent>
        <TabsContent value="crm">
          <FileUploadArea />
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default DataUploadPage