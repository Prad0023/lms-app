// app/workbench/page.tsx
"use client"

import React, { useState, useEffect, useCallback } from "react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import LoadingSpinner from "@/components/ui/loading-spinner"
import { useToast } from "@/components/ui/use-toast"
import { Trash2, Edit3, Save } from "lucide-react"

const API_BASE_URL = "http://127.0.0.1:8000"

// --- Interface Definitions ---
interface Material {
  id: number | string
  material_cd: string
  material_desc: string
  quantity: number
  boxes: number
  length: string
  delay: string
  size_code: string
}

interface CustomerGroup {
  id: string
  customer: string
  plant: string
  dockey: string
  brand_id: string | null
  re11: string | null
  orderCount: number
  status: string
  materials: Material[]
}

const BotRunningOverlay = () => (
  <div className="fixed inset-0 bg-gray-900 bg-opacity-80 flex flex-col items-center justify-center z-50 backdrop-blur-sm">
    <LoadingSpinner size="lg" />
    <h2 className="text-white text-3xl font-bold mt-6">Bot is Running...</h2>
    <p className="text-gray-300 mt-2">
      Please wait, this may take a few moments. The application is locked.
    </p>
  </div>
);

// --- Reusable Accordion Component ---
const CustomerGroupAccordion = ({ groups, isProcessed, onSaveRE11, onConfirmDelete }: {
    groups: CustomerGroup[],
    isProcessed: boolean,
    onSaveRE11: (group: CustomerGroup, tempRE11: string) => void,
    onConfirmDelete: (type: 'delete-group' | 'delete-material', id: any) => void
}) => {
    const [editingRE11, setEditingRE11] = useState<string | null>(null);
    const [tempRE11, setTempRE11] = useState("");

    const handleEditClick = (e: React.MouseEvent, group: CustomerGroup) => {
        e.stopPropagation();
        setEditingRE11(group.id);
        setTempRE11(group.re11 || "");
    };

    const handleSaveClick = (e: React.MouseEvent, group: CustomerGroup) => {
        e.stopPropagation();
        onSaveRE11(group, tempRE11);
        setEditingRE11(null);
    };

    if (groups.length === 0) {
        return <div className="text-center text-gray-500 py-10">No orders found in this category.</div>
    }

    return (
        <Accordion type="multiple" className="w-full">
            {groups.map(group => (
                <AccordionItem value={group.id} key={group.id}>
                    <AccordionTrigger className="hover:bg-gray-50 px-4 text-left">
                        <div className="flex justify-between items-center w-full">
                            <div>
                                <div className="font-bold text-black">{group.customer}</div>
                                <div className="text-sm text-gray-500">
                                    Orders: {group.orderCount} | Dock: {group.dockey} {group.brand_id && `| Brand: ${group.brand_id}`}
                                </div>
                            </div>
                            <div className="flex items-center space-x-4 pr-4">
                                {editingRE11 === group.id ? (
                                    <div className="flex items-center space-x-2" onClick={e => e.stopPropagation()}>
                                        <input type="text" value={tempRE11} onChange={(e) => setTempRE11(e.target.value)} className="input-field text-sm py-1"/>
                                        <button onClick={(e) => handleSaveClick(e, group)} className="p-1 hover:bg-green-100 rounded-full"><Save className="h-4 w-4 text-green-600"/></button>
                                    </div>
                                ) : (
                                    <div className="text-sm">RE11: {group.re11 || "Not Set"}</div>
                                )}
                                {!isProcessed && (
                                    <>
                                        <button onClick={(e) => handleEditClick(e, group)} className="p-1 hover:bg-gray-200 rounded-full"><Edit3 className="h-4 w-4 text-blue-600"/></button>
                                        <button onClick={(e) => { e.stopPropagation(); onConfirmDelete('delete-group', group.id); }} className="p-1 hover:bg-red-100 rounded-full"><Trash2 className="h-4 w-4 text-red-500"/></button>
                                    </>
                                )}
                            </div>
                        </div>
                    </AccordionTrigger>
                    <AccordionContent className="px-4 pt-0 pb-2 bg-gray-50">
                        <table className="w-full text-sm">
                            <thead>
                                <tr className="border-b">
                                    <th className="p-2 font-semibold text-left">Material Code</th>
                                    <th className="p-2 font-semibold text-left">Description</th>
                                    <th className="p-2 font-semibold text-left">Length</th>
                                    <th className="p-2 font-semibold text-left">Delay</th>
                                    <th className="p-2 font-semibold text-left">Size Code</th>
                                    <th className="p-2 font-semibold text-left">Boxes</th>
                                    <th className="p-2 font-semibold text-left">Quantity</th>
                                    {!isProcessed && <th className="p-2 font-semibold text-left">Actions</th>}
                                </tr>
                            </thead>
                            <tbody>
                                {group.materials.map(m => (
                                    <tr key={m.id} className="border-b last:border-b-0">
                                        <td className="p-2">{m.material_cd}</td>
                                        <td className="p-2">{m.material_desc}</td>
                                        <td className="p-2">{m.length}</td>
                                        <td className="p-2">{m.delay}</td>
                                        <td className="p-2">{m.size_code}</td>
                                        <td className="p-2">{m.boxes}</td>
                                        <td className="p-2">{m.quantity}</td>
                                        {!isProcessed && (
                                            <td className="p-2">
                                                <button onClick={() => onConfirmDelete('delete-material', m.id)} className="p-1 hover:bg-red-100 rounded-full">
                                                    <Trash2 className="h-4 w-4 text-red-500"/>
                                                </button>
                                            </td>
                                        )}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </AccordionContent>
                </AccordionItem>
            ))}
        </Accordion>
    );
};


// --- Main Page Component ---
const WorkbenchPage = () => {
  const { toast } = useToast()
  const [activePortal, setActivePortal] = useState("b2b")
  const [pendingData, setPendingData] = useState<CustomerGroup[]>([])
  const [processedData, setProcessedData] = useState<CustomerGroup[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isRunningBot, setIsRunningBot] = useState(false)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [actionToConfirm, setActionToConfirm] = useState<{ type: 'delete-group' | 'delete-material', id: any } | null>(null)

  const fetchWorkbenchData = useCallback(async (portal: string) => {
    setIsLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/order/customer-wise/?portal=${portal}`);
      if (!response.ok) throw new Error("Failed to fetch workbench data.");
      const data = await response.json();
      setPendingData(data.pendingData || []);
      setProcessedData(data.processedData || []);
    } catch (error: any) {
      toast({ variant: "destructive", title: "Fetch Error", description: error.message });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  useEffect(() => { fetchWorkbenchData(activePortal); }, [activePortal, fetchWorkbenchData]);

  const handleSaveRE11 = async (group: CustomerGroup, tempRE11: string) => {
    try {
      const response = await fetch(`${API_BASE_URL}/order/customer-wise/?portal=${activePortal}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer: group.customer, plant: group.plant, dockey: group.dockey,
          brand_id: group.brand_id, re11: tempRE11,
        }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message || "Failed to save RE11.");
      
      toast({ title: "Success", description: result.message });
      setPendingData(prev => prev.map(g => g.id === group.id ? { ...g, re11: tempRE11 } : g));
    } catch (error: any) {
      toast({ variant: "destructive", title: "Save Error", description: error.message });
    }
  };

  const runPOCreationBot = async () => {
    // --- THIS IS THE CORRECTED LOGIC ---
    // 1. Determine the correct bot name based on the active portal
    const botToTrigger = activePortal === 'b2b' ? 'detonator_po_creation' : 'e2e_crm_po_create_acc';

    setIsRunningBot(true); // Show overlay
    try {
        // 2. Send the correct bot name in the API request body
        const response = await fetch(`${API_BASE_URL}/order/rpa/trigger/`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ bot_name: botToTrigger }),
        });

        const result = await response.json();
        if (!response.ok) {
            throw new Error(result.message || `Failed to trigger the '${botToTrigger}' bot.`);
        }

        toast({ title: "Bot Triggered Successfully", description: `The '${botToTrigger}' bot is now running.` });

        // 3. Simulate bot running time and then refresh data
        setTimeout(() => {
            toast({ title: "Process Complete", description: "Fetching latest data from the server." });
            fetchWorkbenchData(activePortal);
            setIsRunningBot(false); // Hide overlay
        }, 10000);

    } catch (error: any) {
        toast({ variant: "destructive", title: "RPA Error", description: error.message });
        setIsRunningBot(false); // Hide overlay on failure
    }
  };

  const confirmDelete = (type: 'delete-group' | 'delete-material', id: any) => {
    setActionToConfirm({ type, id });
    setDialogOpen(true);
  };

  const executeDelete = async () => {
    if (!actionToConfirm) return;
    const { type, id } = actionToConfirm;
    
    try {
      const response = await fetch(`${API_BASE_URL}/order/customer-wise/?portal=${activePortal}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(type === 'delete-group' ? { group_id: id } : { material_id: id }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message || 'Failed to delete.');

      toast({ title: "Success", description: result.message });
      if (type === 'delete-group') {
        setPendingData(prev => prev.filter(g => g.id !== id));
      } else {
        setPendingData(prev => prev.map(group => ({
          ...group,
          materials: group.materials.filter(m => m.id !== id),
        })).filter(group => group.materials.length > 0));
      }
    } catch (error: any) {
      toast({ variant: "destructive", title: "Delete Error", description: error.message });
    } finally {
      setDialogOpen(false);
      setActionToConfirm(null);
    }
  };

  if (isLoading) return <div className="flex justify-center items-center p-20"><LoadingSpinner size="lg" /></div>;

  const PortalContent = () => (
    <Tabs defaultValue="pending" className="w-full mt-4">
        <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="pending">Pending Orders ({pendingData.length})</TabsTrigger>
            <TabsTrigger value="processed">Processed Orders ({processedData.length})</TabsTrigger>
        </TabsList>
        <TabsContent value="pending" className="mt-4">
            <CustomerGroupAccordion groups={pendingData} isProcessed={false} onSaveRE11={handleSaveRE11} onConfirmDelete={confirmDelete} />
        </TabsContent>
        <TabsContent value="processed" className="mt-4">
            <CustomerGroupAccordion groups={processedData} isProcessed={true} onSaveRE11={()=>{}} onConfirmDelete={()=>{}} />
        </TabsContent>
    </Tabs>
  )

  return (
    <>
      {isRunningBot && <BotRunningOverlay />}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold text-black">PO Creation Workbench</h1>
              <p className="text-gray-600 mt-2">Manage orders for the <span className="font-semibold">{activePortal.toUpperCase()}</span> portal.</p>
            </div>
            <button onClick={runPOCreationBot} disabled={isRunningBot || pendingData.length === 0} className="btn-primary flex items-center space-x-2">
              {isRunningBot && <LoadingSpinner />}
              <span>{isRunningBot ? "Processing..." : "Run PO Creation Bot"}</span>
            </button>
        </div>

        <Tabs defaultValue="b2b" className="w-full" onValueChange={setActivePortal}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="b2b">B2B Portal</TabsTrigger>
            <TabsTrigger value="crm">CRM Portal</TabsTrigger>
          </TabsList>
          
          <TabsContent value="b2b"><PortalContent /></TabsContent>
          <TabsContent value="crm"><PortalContent /></TabsContent>
        </Tabs>
      </div>

      <AlertDialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle><AlertDialogDescription>This action cannot be undone. This will permanently delete the data from the server.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={executeDelete} className="bg-red-600 hover:bg-red-700">Continue</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}

export default WorkbenchPage;