import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { MainAppLayoutComponent } from './core/layout/main-app-layout/main-app-layout.component'; // Import layout

export const routes: Routes = [
  // Public Landing Page (no sidebar layout)
  {
    path: '',
    loadChildren: () => import('./modules/public/public.module').then(m => m.PublicModule),
  },
  // Auth pages (no sidebar layout typically)
  {
    path: 'auth',
    loadChildren: () => import('./modules/auth/auth.module').then(m => m.AuthModule)
  },

  // Routes that USE the MainAppLayoutComponent with sidebar
  {
    path: '', // A parent route for all sections that use the main layout
    component: MainAppLayoutComponent, // Apply the layout here
    canActivate: [authGuard], // Protect all child routes of this layout
    children: [
      {
        path: 'admin',
        loadChildren: () => import('./modules/admin/admin.module').then(m => m.AdminModule),
        data: { expectedRoles: ['admin'] } // Role check can also be on this parent or individual child routes
      },
      // {
      //   path: 'teacher',
      //   loadChildren: () => import('./modules/teacher/teacher.module').then(m => m.TeacherModule),
      //   data: { expectedRoles: ['teacher'] }
      // },
      {
        path: 'student',
        loadChildren: () => import('./modules/student/student.module').then(m => m.StudentModule),
        data: { expectedRoles: ['student'] }
      },
      {
        path: 'profile', // Example of a common authenticated route
        // loadComponent: () => import('./pages/profile-page/profile-page.component').then(m => m.ProfilePageComponent),
        // For now, let's assume profile is part of a UserModule or similar
        redirectTo: 'admin/dashboard', // Placeholder, you'd create a profile page
        pathMatch: 'full'
      }
      // Add other common authenticated routes here that share the layout
    ]
  },
  { path: '**', redirectTo: '', pathMatch: 'full' }
];