import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router'; // ActivatedRoute is not strictly needed for history.state but good for other route info
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { AuthService } from '../../../../core/services/auth.service'; // Adjust path
import { OtpVerificationResponse } from '../../../../core/models/user.model';
import { firstValueFrom } from 'rxjs';
@Component({
  selector: 'app-email-otp-verification-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './email-otp-verification-page.component.html',
})
export class EmailOtpVerificationPageComponent implements OnInit {
  otpForm: FormGroup;
  isLoading = false;
  isResendingOtp = false;
  errorMessage: string | null = null;
  successMessage: string | null = null;
  emailToVerify: string | null = null;
  mobileNumberProvidedDuringReg: string | null = null; // To pass to next OTP step

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    // private activatedRoute: ActivatedRoute // Not strictly needed for history.state access
  ) {
    this.otpForm = this.fb.group({
      otp: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(6), Validators.pattern(/^\d+$/)]]
    });
  }

  ngOnInit(): void {
    // Use history.state to retrieve data passed during navigation
    const navigationState = history.state;
    console.log("EmailOtpVerificationPage: Received history.state:", navigationState); // <<< DEBUG

    if (navigationState && navigationState.email) {
      this.emailToVerify = navigationState.email;
      this.mobileNumberProvidedDuringReg = navigationState.mobileNumber || null; // Get mobile number if passed
      console.log("EmailOtpVerificationPage: Email to verify:", this.emailToVerify, "Mobile provided:", this.mobileNumberProvidedDuringReg);
    } else {
      console.error("EmailOtpVerificationPage: Email not found in history.state. Redirecting to student registration.");
      this.errorMessage = "Could not retrieve your email for verification. Please try registering again.";
      // Redirect after a short delay to allow user to see error, or provide a button
      // setTimeout(() => this.router.navigate(['/auth/register-student']), 3000);
      // For now, a direct redirect is fine, but user might miss the error.
      this.router.navigate(['/auth/register-student']);
    }
  }

  get f() { return this.otpForm.controls; }

  onSubmit(): void {
    if (this.otpForm.invalid || !this.emailToVerify) {
        this.otpForm.markAllAsTouched();
        if (!this.emailToVerify) this.errorMessage = "Email context lost. Please try again.";
        return;
    }
    this.isLoading = true;
    this.errorMessage = null;
    this.successMessage = null;

    this.authService.verifyEmailOtp(this.emailToVerify, this.f['otp'].value).subscribe({
      next: (response: OtpVerificationResponse) => {
        this.isLoading = false;
        if (response.success) {
          this.successMessage = response.message || "Email verified successfully!";
          // Check if mobile verification is needed based on mobileNumberProvidedDuringReg
          if (this.mobileNumberProvidedDuringReg && response.data?.status !== 'active' && !response.data?.mobileVerified) {
            console.log("EmailOtpVerificationPage: Email verified, mobile was provided. Navigating to mobile OTP.");
            this.router.navigate(['/auth/verify-mobile-otp'], {
              state: { email: this.emailToVerify, mobileNumber: this.mobileNumberProvidedDuringReg }
            });
          } else if (response.data?.status === 'active') {
            console.log("EmailOtpVerificationPage: Account fully activated. Navigating to login.");
            alert("Account activated! Please login with your new credentials.");
            this.router.navigate(['/auth/login']);
          } else {
             console.log("EmailOtpVerificationPage: Email verified, no further steps indicated or mobile not provided. Navigating to login.");
             alert("Email verified! Please login to continue.");
             this.router.navigate(['/auth/login']);
          }
        } else {
          this.errorMessage = response.message || "Email OTP verification failed.";
        }
      },
      error: (err) => {
        this.isLoading = false;
        this.errorMessage = err.message || "An error occurred during email OTP verification.";
        console.error("Email OTP Verification error:", err);
      }
    });
  }

  async onResendOtp(): Promise<void> {
    // ... (Resend OTP logic from before, remains the same)
    if (!this.emailToVerify || this.isResendingOtp) return;
    this.isResendingOtp = true; this.errorMessage = null; this.successMessage = null;
    try {
      const response = await firstValueFrom(this.authService.resendEmailOtp(this.emailToVerify));
      if (response.success) this.successMessage = response.message || "New OTP sent.";
      else this.errorMessage = response.message || "Failed to resend OTP.";
    } catch (e:any) { this.errorMessage = e.message || "Error resending OTP."; }
    finally { this.isResendingOtp = false; }
  }
}