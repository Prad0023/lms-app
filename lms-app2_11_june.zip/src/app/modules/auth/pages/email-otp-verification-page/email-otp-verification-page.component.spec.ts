import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmailOtpVerificationPageComponent } from './email-otp-verification-page.component';

describe('EmailOtpVerificationPageComponent', () => {
  let component: EmailOtpVerificationPageComponent;
  let fixture: ComponentFixture<EmailOtpVerificationPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EmailOtpVerificationPageComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmailOtpVerificationPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
