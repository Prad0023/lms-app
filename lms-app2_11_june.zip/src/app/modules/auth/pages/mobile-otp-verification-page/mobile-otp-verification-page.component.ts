import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router'; // ActivatedRoute not strictly needed for history.state
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { AuthService } from '../../../../core/services/auth.service'; // Adjust path
import { OtpVerificationResponse, ResendOtpResponse } from '../../../../core/models/user.model'; // Adjust path
import { firstValueFrom } from 'rxjs';

@Component({
  selector: 'app-mobile-otp-verification-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './mobile-otp-verification-page.component.html',
})
export class MobileOtpVerificationPageComponent implements OnInit {
  otpForm: FormGroup;
  isLoading = false;
  isResendingOtp = false;
  errorMessage: string | null = null;
  successMessage: string | null = null;

  // These will be populated from history.state
  userEmailForLookup: string | null = null; // Email of the user (for resend OTP if mobile fails, or primary lookup if mobile token associated with email)
  mobileNumberToVerify: string | null = null; // The actual mobile number that received the OTP
  mobileNumberToDisplay: string | null = null;
  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.otpForm = this.fb.group({
      otp: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(6), Validators.pattern(/^\d+$/)]]
    });
  }

  ngOnInit(): void {
    const navigationState = history.state;
    console.log("MobileOtpVerificationPage: Received history.state:", navigationState); // <<< KEY DEBUG LOG

    this.userEmailForLookup = navigationState?.email || null;
    this.mobileNumberToVerify = navigationState?.mobileNumber || null;

    if (!this.mobileNumberToVerify) { // Primarily, we need the mobile number that was OTP'd
      console.error("MobileOtpVerificationPage: Mobile number for OTP verification not found in route state. Redirecting to student registration.");
      this.errorMessage = "Could not retrieve your mobile number for verification. Please try the process again.";
      this.router.navigate(['/auth/register-student']);
    } else if (!this.userEmailForLookup && this.mobileNumberToVerify) {
      // If email is missing but mobile is present, this is unusual for our flow
      // as email verification comes first. Backend might need email for user lookup if mobile not primary.
      // For now, log a warning. Resend OTP might need userEmailForLookup.
      console.warn("MobileOtpVerificationPage: Email context is missing, but mobile number is present. Verification might be limited if backend relies on email for user lookup during resend.");
    }

    console.log("MobileOtpVerificationPage: Mobile to verify:", this.mobileNumberToVerify, "User email context:", this.userEmailForLookup);
  }

  get f() { return this.otpForm.controls; }

  onSubmit(): void {
    if (this.otpForm.invalid || !this.mobileNumberToVerify) {
      this.otpForm.markAllAsTouched();
      if(!this.mobileNumberToVerify) this.errorMessage = "Mobile number context lost. Please restart registration.";
      return;
    }
    this.isLoading = true;
    this.errorMessage = null;
    this.successMessage = null;

    // The backend for verify-mobile-otp needs either the mobile number or another unique identifier (like email or userId)
    // to find the user and their pending mobile OTP.
    // Let's assume the backend can find the user by the mobileNumber itself.
    // If not, and it needs email, we have this.userEmailForLookup.
    // Your AuthService.verifyMobileOtp sends `identifier` and `identifierType`.
    // So we use this.mobileNumberToVerify as the identifier and 'mobileNumber' as type.

    this.authService.verifyMobileOtp(this.mobileNumberToVerify, this.f['otp'].value, 'mobileNumber').subscribe({
      next: (response: OtpVerificationResponse) => {
        this.isLoading = false;
        if (response.success) {
          this.successMessage = response.message || "Mobile number verified successfully!";
          if (response.data?.status === 'active') {
            alert("Account fully activated! Please login.");
            this.router.navigate(['/auth/login']);
          } else if (response.data?.status === 'pending_email_verification') {
            alert("Mobile verified. Your email still needs verification. This is unusual, please contact support or try email verification again.");
            this.router.navigate(['/auth/verify-email-otp'], { state: { email: this.userEmailForLookup } });
          } else {
            alert("Mobile number verified! Your account should be active. Please proceed to login.");
            this.router.navigate(['/auth/login']);
          }
        } else {
          this.errorMessage = response.message || "Mobile OTP verification failed.";
        }
      },
      error: (err) => {
        this.isLoading = false;
        this.errorMessage = err.message || "An error occurred during mobile OTP verification.";
        console.error("Mobile OTP Verification error:", err);
      }
    });
  }

  async onResendOtp(): Promise<void> {
    // Resending OTP for this.mobileNumberToVerify.
    // The backend needs an identifier to find the user.
    // If mobile number is unique, it can use that. Otherwise, it might need email.
    if (!this.mobileNumberToVerify || this.isResendingOtp) return;

    this.isResendingOtp = true;
    this.errorMessage = null;
    this.successMessage = null;

    try {
      // Using mobileNumber as the identifier for resend.
      const response: ResendOtpResponse = await firstValueFrom(
        this.authService.resendMobileOtp(this.mobileNumberToVerify, 'mobileNumber')
      );
      if (response.success) {
        this.successMessage = response.message || "New OTP sent to your mobile number.";
      } else {
        this.errorMessage = response.message || "Failed to resend OTP.";
      }
    } catch (error: any) {
      this.errorMessage = error.message || "Error resending OTP.";
    } finally {
      this.isResendingOtp = false;
    }
  }
}