import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MobileOtpVerificationPageComponent } from './mobile-otp-verification-page.component';

describe('MobileOtpVerificationPageComponent', () => {
  let component: MobileOtpVerificationPageComponent;
  let fixture: ComponentFixture<MobileOtpVerificationPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MobileOtpVerificationPageComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MobileOtpVerificationPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
