import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

// Import the page components to be routed to
import { LoginPageComponent } from './pages/login-page/login-page.component';
import { AdminRegisterPageComponent } from './pages/admin-register-page/admin-register-page.component';
import { StudentRegisterPageComponent } from './pages/student-register-page/student-register-page.component'; // <<< IMPORT
import { EmailOtpVerificationPageComponent } from './pages/email-otp-verification-page/email-otp-verification-page.component'; // <<< IMPORT
import { MobileOtpVerificationPageComponent } from './pages/mobile-otp-verification-page/mobile-otp-verification-page.component'; // <<< IMPORT


const routes: Routes = [
  {
    path: 'login', // Full path will be /auth/login
    component: LoginPageComponent
  },
  {
    path: 'register-admin', // Full path will be /auth/register-admin
    component: AdminRegisterPageComponent
  },
  {
    path: '', // Default route for /auth
    redirectTo: 'login',
    pathMatch: 'full'
  },
  
  { path: 'verify-email-otp', component: EmailOtpVerificationPageComponent }, // <<< NEW
  { path: 'verify-mobile-otp', component: MobileOtpVerificationPageComponent },// <<< NEW
  { path: 'register-student', component: StudentRegisterPageComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }