// Example: src/app/modules/auth/auth.routes.ts
import { Routes } from '@angular/router';

export const AUTH_ROUTES: Routes = [
  {
    path: 'login',
    loadComponent: () => import('./pages/login-page/login-page.component').then(c => c.LoginPageComponent)
  },
  {
    path: 'register-admin', // Or 'register' if it's the only registration
    loadComponent: () => import('./pages/admin-register-page/admin-register-page.component').then(c => c.AdminRegisterPageComponent)
  },
  { path: '', redirectTo: 'login', pathMatch: 'full' }
];