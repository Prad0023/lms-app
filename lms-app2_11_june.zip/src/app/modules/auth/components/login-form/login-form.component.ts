import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router'; // RouterLink if used in template
import { AuthService } from '../../../../core/services/auth.service'; // Correct path
import {  LoginPayload } from '../../../../core/models/user.model'; // Correct path

@Component({
  selector: 'app-login-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './login-form.component.html',
  // styleUrls: ['./login-form.component.css']
})
export class LoginFormComponent {
  loginForm: FormGroup;
  isLoading = false;
  errorMessage: string | null = null;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
  ) {
    this.loginForm = this.fb.group({
      email: ['testadmin@school.edu', [Validators.required, Validators.email]],
      password: ['SecurePassword123!', [Validators.required, Validators.minLength(6)]], // Example minLength
    });
  }

  // GETTERS FOR TEMPLATE ACCESS
  get email() { return this.loginForm.get('email'); }
  get password() { return this.loginForm.get('password'); }

  async onSubmit(): Promise<void> {
    if (this.loginForm.invalid) {
      this.markAllAsTouched();
      return;
    }

    this.isLoading = true; // Set loading to true
    this.errorMessage = null;
    const payload: LoginPayload = this.loginForm.value;

    try {
      console.log('LoginFormComponent: Submitting payload:', payload);
      const response = await this.authService.login(payload);
      // isLoading will be set to false AFTER the promise resolves or rejects

      if (!response.success) {
        this.errorMessage = response.message;
        console.error('LoginFormComponent: Login failed - Server response:', response.message);
      } else {
        console.log('LoginFormComponent: Login successful, navigation should have been handled by AuthService.');
        // If successful, navigation is handled by AuthService,
        // so the component might be destroyed before isLoading is set back to false here.
        // That's usually fine. If not, AuthService could return a boolean from navigateToDashboard
        // or the component could subscribe to router events.
      }
    } catch (error: any) { // Catches errors from authService.login if it re-throws or if promise rejects
      this.errorMessage = error.message || 'An unexpected error occurred during login.';
      console.error('LoginFormComponent: Login error caught in component:', error);
    } finally {
      // This block executes whether the try succeeds or an error is caught
      this.isLoading = false; // <<< ENSURE isLoading IS ALWAYS RESET
      console.log('LoginFormComponent: isLoading set to false.');
    }
  }

  private markAllAsTouched(): void {
    Object.values(this.loginForm.controls).forEach(control => {
      control.markAsTouched();
    });
  }
}