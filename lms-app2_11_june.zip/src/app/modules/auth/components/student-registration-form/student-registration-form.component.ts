import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService  } from '../../../../core/services/auth.service'; // Adjust path to core service
import { StudentRegistrationPayload, AuthResponse } from '../../../../core/models/user.model'

@Component({
  selector: 'app-student-registration-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './student-registration-form.component.html',
  // styleUrls: ['./student-registration-form.component.css']
})
export class StudentRegistrationFormComponent {
  registerForm: FormGroup;
  isLoading = false;
  errorMessage: string | null = null;
  successMessage: string | null = null;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.registerForm = this.fb.group({
      fullName: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      mobileNumber: ['', [Validators.pattern(/^\+?[1-9]\d{1,14}$/)]], // Optional but validate
      password: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', Validators.required],
      // courseOfInterest: [''] // Example optional field
    }, { validators: this.passwordMatchValidator });
  }

  passwordMatchValidator(form: FormGroup) {
    const password = form.get('password')?.value;
    const confirmPassword = form.get('confirmPassword')?.value;
    return password === confirmPassword ? null : { mismatch: true };
  }

  get f() { return this.registerForm.controls; }

  onSubmit(): void {
    this.errorMessage = null;
    this.successMessage = null;
    this.registerForm.markAllAsTouched();

    if (this.registerForm.invalid) {
      console.log("Student registration form invalid", this.registerForm.errors);
      return;
    }

    this.isLoading = true;
    const formValue = this.registerForm.value;
    const payload: StudentRegistrationPayload = {
      fullName: formValue.fullName,
      email: formValue.email,
      password: formValue.password,
      mobileNumber: formValue.mobileNumber || undefined, // Send undefined if empty
      // courseOfInterest: formValue.courseOfInterest || undefined,
    };

    this.authService.registerStudent(payload).subscribe({
      next: (response: AuthResponse) => {
        this.isLoading = false;
        if (response.success) {
          this.successMessage = response.message || "Registration initiated. Please check your email for OTP.";
          console.log("StudentRegistrationForm: Registration API success. Preparing to navigate to OTP page."); // <<< ADD LOG
          console.log("StudentRegistrationForm: Payload for OTP navigation state:", { email: payload.email, mobileNumber: payload.mobileNumber }); // <<< ADD LOG

          // VVVVVVVVVV THIS IS THE NAVIGATION LINE VVVVVVVVVVVV
          this.router.navigate(['/auth/verify-email-otp'], {
            state: {
              email: payload.email,
              mobileNumber: payload.mobileNumber // Ensure payload.mobileNumber holds the correct value from form
            }
          });
          // ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
          console.log("StudentRegistrationForm: Navigation attempt to OTP page finished."); // <<< ADD LOG
          this.registerForm.reset();
        } else {
          this.errorMessage = response.message || "Registration failed.";
        }
      },
      error: (err) => {
        this.isLoading = false;
        this.errorMessage = err.message || 'An unexpected error occurred during registration.';
        console.error("Student registration error:", err);
      }
    });
  }
}