import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeacherHireModalComponent } from './teacher-hire-modal.component';

describe('TeacherHireModalComponent', () => {
  let component: TeacherHireModalComponent;
  let fixture: ComponentFixture<TeacherHireModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TeacherHireModalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TeacherHireModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
