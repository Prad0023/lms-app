import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubjectModuleAddModalComponent } from './subject-module-add-modal.component';

describe('SubjectModuleAddModalComponent', () => {
  let component: SubjectModuleAddModalComponent;
  let fixture: ComponentFixture<SubjectModuleAddModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SubjectModuleAddModalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SubjectModuleAddModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
