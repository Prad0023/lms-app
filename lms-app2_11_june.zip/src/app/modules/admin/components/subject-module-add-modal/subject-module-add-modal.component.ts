import { Component, EventEmitter, Input, OnInit, Output, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormArray, AbstractControl, ValidationErrors } from '@angular/forms';
import { ModuleBasicInfo } from '../../models/subject.model';
import { MinimalCourseInfo } from '../../models/course.model';

@Component({
  selector: 'app-subject-module-add-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './subject-module-add-modal.component.html',
})
export class SubjectModuleAddComponent implements OnInit, OnChanges {
  @Input() subjectId!: string;
  @Input() subjectName!: string;
  @Input() coursesAssociatedWithParentSubject: MinimalCourseInfo[] = [];

  @Output() closeModal = new EventEmitter<void>();
  // Now moduleAdded can emit a single ModuleBasicInfo or an array from JSON upload
  @Output() moduleAdded = new EventEmitter<ModuleBasicInfo | ModuleBasicInfo[]>();

  addModuleForm: FormGroup;
  isLoading = false;
  uploadedModules: ModuleBasicInfo[] | null = null; // To store parsed modules from JSON
  jsonFileName: string | null = null;
  jsonError: string | null = null;

  constructor(private fb: FormBuilder) {
    this.addModuleForm = this.fb.group({
      moduleName: ['', Validators.required],
      moduleDescription: [''],
      appliesToCourseIds: this.fb.array([]),
      initialTopics: this.fb.array([], { validators: this.requireAtLeastOneValidTopicInArray })
    });
  }

  ngOnInit(): void {
    if (this.initialTopicsArray.length === 0) {
      this.addTopicInputInternal();
    }
    console.log("Modal received courses for parent subject:", this.coursesAssociatedWithParentSubject);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['coursesAssociatedWithParentSubject']) {
      console.log("Modal courses for parent subject updated:", this.coursesAssociatedWithParentSubject);
    }
  }

  get f() { return this.addModuleForm.controls; }
  get initialTopicsArray() { return this.addModuleForm.get('initialTopics') as FormArray; }
  get appliesToCourseIds() { return this.addModuleForm.get('appliesToCourseIds') as FormArray; }

  // Validator and topic methods (createTopicGroup, addTopicInputInternal, addTopicInput, removeTopicInput, canAddMoreTopics)
  // remain the same as in the previous correct version.
  private requireAtLeastOneValidTopicInArray(formArray: AbstractControl): ValidationErrors | null { /* ... as before ... */
    if (formArray instanceof FormArray && formArray.controls.length > 0) {
      const hasAtLeastOneValidTopic = formArray.controls.some(
        control => control.get('topicName')?.value?.trim() !== ''
      );
      return hasAtLeastOneValidTopic ? null : { requireAtLeastOneValidTopic: true };
    }
    return null;
  }
  createTopicGroup(): FormGroup { /* ... as before ... */
    return this.fb.group({ topicName: ['', Validators.required] });
  }
  private addTopicInputInternal(): void { /* ... as before ... */
    this.initialTopicsArray.push(this.createTopicGroup());
  }
  addTopicInput(): void { /* ... as before ... */
     if (this.canAddMoreTopics()) { this.addTopicInputInternal(); }
  }
  removeTopicInput(index: number): void { /* ... as before ... */
    if (this.initialTopicsArray.length > 1) { this.initialTopicsArray.removeAt(index); }
  }
  canAddMoreTopics(): boolean { /* ... as before ... */
    if (this.initialTopicsArray.length === 0) return true;
    const lastTopicGroup = this.initialTopicsArray.at(this.initialTopicsArray.length - 1);
    if (!lastTopicGroup) return false;
    const topicNameControl = lastTopicGroup.get('topicName');
    return !!(topicNameControl && topicNameControl.valid && topicNameControl.value?.trim() !== '');
  }

  // Course Selection logic for appliesToCourseIds
  onCourseSelectionChange(event: Event, courseId: string): void { /* ... as before ... */
    const isChecked = (event.target as HTMLInputElement).checked;
    const courseIdsFormArray = this.appliesToCourseIds;
    if (isChecked) {
      if (!courseIdsFormArray.controls.find(ctrl => ctrl.value === courseId)) {
        courseIdsFormArray.push(this.fb.control(courseId));
      }
    } else {
      const index = courseIdsFormArray.controls.findIndex(ctrl => ctrl.value === courseId);
      if (index > -1) { courseIdsFormArray.removeAt(index); }
    }
  }
  isCourseSelectedForModule(courseId: string): boolean { /* ... as before ... */
    return !!this.appliesToCourseIds.controls.find(ctrl => ctrl.value === courseId);
  }


  toTitleCase(str: string): string { /* ... as before ... */
    if (!str) return '';
    return str.toLowerCase().split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  }

  // --- JSON File Upload Logic ---
  onFileSelected(event: Event): void {
    const fileInput = event.target as HTMLInputElement;
    if (fileInput.files && fileInput.files.length > 0) {
      const file = fileInput.files[0];
      this.jsonFileName = file.name;
      this.jsonError = null;
      this.uploadedModules = null; // Clear previous upload

      if (file.type === "application/json") {
        const reader = new FileReader();
        reader.onload = (e) => {
          try {
            const jsonContent = e.target?.result as string;
            const parsedData = JSON.parse(jsonContent);
            // Validate structure of parsedData (e.g., is it an array of ModuleBasicInfo?)
            if (this.isValidModuleBasicInfoArray(parsedData)) {
              this.uploadedModules = parsedData.map(module => ({
                ...module,
                moduleName: this.toTitleCase(module.moduleName.trim()),
                initialTopics: module.initialTopics?.map(topic => ({
                    topicName: this.toTitleCase(topic.topicName.trim())
                })).filter(topic => topic.topicName !== '') || []
              }));
              console.log("Parsed JSON modules:", this.uploadedModules);
              // Disable manual form if JSON is successfully parsed
              this.addModuleForm.disable();
            } else {
              this.jsonError = "Invalid JSON structure. Please use the demo file format.";
              this.clearJsonUpload(fileInput);
            }
          } catch (error) {
            console.error("Error parsing JSON file:", error);
            this.jsonError = "Error parsing JSON file. Make sure it's valid JSON.";
            this.clearJsonUpload(fileInput);
          }
        };
        reader.onerror = (error) => {
            console.error("Error reading file:", error);
            this.jsonError = "Error reading the selected file.";
            this.clearJsonUpload(fileInput);
        };
        reader.readAsText(file);
      } else {
        this.jsonError = "Invalid file type. Please upload a .json file.";
        this.clearJsonUpload(fileInput);
      }
    }
  }

  isValidModuleBasicInfoArray(data: any): data is ModuleBasicInfo[] {
    if (!Array.isArray(data)) return false;
    return data.every(item =>
      typeof item === 'object' &&
      item !== null &&
      'moduleName' in item && typeof item.moduleName === 'string' &&
      // 'appliesToCourseIds' should be string[]
      (item.appliesToCourseIds === undefined || (Array.isArray(item.appliesToCourseIds) && item.appliesToCourseIds.every((id: any) => typeof id === 'string'))) &&
      // 'initialTopics' should be array of {topicName: string}
      (item.initialTopics === undefined || (Array.isArray(item.initialTopics) && item.initialTopics.every((topic: any) => typeof topic === 'object' && topic !== null && 'topicName' in topic && typeof topic.topicName === 'string')))
    );
  }

  clearJsonUpload(fileInput?: HTMLInputElement): void {
    this.uploadedModules = null;
    this.jsonFileName = null;
    if (fileInput) {
        fileInput.value = ''; // Reset file input
    }
    // Re-enable manual form if JSON upload is cleared or failed
    this.addModuleForm.enable();
    if (this.initialTopicsArray.length === 0 && this.addModuleForm.enabled) {
      this.addTopicInputInternal(); // Re-add if form enabled and no topics
    }
  }

  downloadDemoJson(): void {
    const demoData: ModuleBasicInfo[] = [
      {
        moduleName: "Sample Module 1: Introduction",
        moduleDescription: "This is the first module covering basic concepts.",
        appliesToCourseIds: [this.coursesAssociatedWithParentSubject?.[0]?._id || "COURSE_ID_1"], // Example using first associated course
        initialTopics: [
          { topicName: "Topic 1.1: Overview" },
          { topicName: "Topic 1.2: Key Definitions" }
        ]
      },
      {
        moduleName: "Sample Module 2: Advanced Techniques",
        moduleDescription: "Diving deeper into the subject matter.",
        appliesToCourseIds: [], // Example: not specifically tied to a course via ReqForCourses
        initialTopics: [
          { topicName: "Topic 2.1: Core Technique A" },
          { topicName: "Topic 2.2: Core Technique B Application" }
        ]
      }
    ];
    const jsonString = JSON.stringify(demoData, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'demo-modules-template.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
  // --- End JSON File Upload Logic ---

  onSubmit(): void {
    this.isLoading = true; // Set loading for submit button

    if (this.uploadedModules && this.uploadedModules.length > 0) {
      // If JSON data is present and valid, emit that
      console.log("SubjectModuleAddModal: Submitting uploaded JSON modules:", this.uploadedModules);
      this.moduleAdded.emit(this.uploadedModules);
      // isLoading will be handled by parent based on service call for multiple modules
    } else {
      // Otherwise, submit manual form data
      this.addModuleForm.markAllAsTouched();
      if (this.addModuleForm.invalid) {
        console.log("Add Module Form (manual) is invalid. Errors:", this.addModuleForm.errors);
        if (this.initialTopicsArray.invalid && this.initialTopicsArray.length > 0) {
          if (this.initialTopicsArray.hasError('requireAtLeastOneValidTopic')) {
              // alert("Module must have at least one topic with a valid name."); // Consider less intrusive feedback
          }
        }
        this.isLoading = false; // Reset loading as submission is stopped
        return;
      }

      const formValue = this.addModuleForm.value;
      const processedTopics = formValue.initialTopics
          .map((topic: { topicName: string }) => ({
              topicName: this.toTitleCase(topic.topicName.trim())
          }))
          .filter((topic: { topicName: string }) => topic.topicName !== '');

      if (processedTopics.length === 0 && formValue.initialTopics.length > 0) {
          alert("At least one topic must have a valid name.");
          this.isLoading = false;
          return;
      }

      const modulePayload: ModuleBasicInfo = {
        moduleName: this.toTitleCase(formValue.moduleName.trim()),
        moduleDescription: formValue.moduleDescription?.trim() || undefined,
        appliesToCourseIds: formValue.appliesToCourseIds || [],
        initialTopics: processedTopics
      };
      console.log("SubjectModuleAddModal: Submitting manually entered module payload:", modulePayload);
      this.moduleAdded.emit(modulePayload);
    }
    // Parent (SubjectDetailPageComponent) handles the actual service call and setting isLoading to false,
    // and closing the modal upon completion.
  }

  onCancel(): void {
    this.closeModal.emit();
  }
}