import { Component } from '@angular/core';

@Component({
  selector: 'app-batch-management-page',
  imports: [],
  templateUrl: './batch-management-page.component.html',
  styleUrl: './batch-management-page.component.css'
})
export class BatchManagementPageComponent {

}
