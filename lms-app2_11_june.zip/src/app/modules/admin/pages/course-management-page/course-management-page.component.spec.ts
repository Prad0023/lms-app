import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CourseManagementPageComponent } from './course-management-page.component';

describe('CourseManagementPageComponent', () => {
  let component: CourseManagementPageComponent;
  let fixture: ComponentFixture<CourseManagementPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CourseManagementPageComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CourseManagementPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
