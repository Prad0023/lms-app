// src/app/modules/admin/pages/module-content-management-page/module-content-management-page.component.ts
import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common'; // DatePipe is usually available via CommonModule
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators, FormArray, AbstractControl, ValidationErrors } from '@angular/forms';

import { AdminSubjectService } from '../../services/admin-subject.service';
import { AdminTopicService, GenericMutationResponse } from '../../services/admin-topic.service';

import {
  ModuleDetailsBackendNested,   // From parent subject's Modules array
  TopicDetailsBackendNested,    // From moduleDetails.Topics array
  TopicSimpleCreatePayload,
  BulkTopicAddPayload,
  BulkTopicAddResponse
} from '../../models/subject.model'; // Assuming all module/topic related models are also re-exported or defined here for simplicity

// Ensure these are correctly exported from topic.model.ts and imported
import {
  AssessmentItem,
  TopicNote,
  TopicAssignment,
  TopicRevisionMaterial,
  TopicDetailsWithResourcesBackend // For the full topic details loaded into the modal
} from '../../models/topic.model';

// Correct import for the modal component
import { TopicResourceModalComponent } from '../../components/topic-resource-modal/topic-resource-modal.component';

@Component({
  selector: 'app-module-content-management-page',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    TopicResourceModalComponent // <<< IMPORTED MODAL
  ],
  templateUrl: './module-content-management-page.component.html',
})
export class ModuleContentManagementPageComponent implements OnInit {
  subjectId: string | null = null;
  moduleId: string | null = null;
  moduleDetails: ModuleDetailsBackendNested | null = null; // Contains existing TopicDetailsBackendNested[]

  isLoadingPage = true;           // Overall page loading state
  errorMessage: string | null = null;

  // For "Add New Topics" section (manual form or JSON)
  showAddTopicsSection = false;   // Controls visibility of the add topics UI block
  addTopicsForm: FormGroup;       // FormGroup for manually adding one or more topics
  isAddingTopics = false;         // Loading state for the "Add Topics" submit button
  @ViewChild('topicJsonFileInput') topicJsonFileInputRef!: ElementRef<HTMLInputElement>; // For resetting file input
  uploadedTopics: TopicSimpleCreatePayload[] | null = null; // Stores topics from JSON file upload
  jsonFileName: string | null = null;
  jsonError: string | null = null;

  // For resource management modal
  isResourceModalOpen = false;
  // selectedTopicForResources holds the full topic details (TopicDetailsWithResourcesBackend) when modal is open
  selectedTopicForResources: TopicDetailsWithResourcesBackend | TopicDetailsBackendNested | null = null; // Use TopicDetailsWithResourcesBackend if available
  selectedResourceType: 'Assessments' | 'Notes' | 'Assignments' | 'Revision' | null = null;
  currentTopicResources: AssessmentItem[] | TopicNote[] | TopicAssignment[] | TopicRevisionMaterial[] = []; // Data for the modal
  isLoadingTopicResourcesForModal = false; // Specific loader for when modal fetches/shows resources


  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private adminSubjectService: AdminSubjectService,
    private adminTopicService: AdminTopicService,
    private fb: FormBuilder
  ) {
    this.addTopicsForm = this.fb.group({
      topics: this.fb.array([], { validators: this.requireAtLeastOneValidTopicInFormArray })
    });
  }

  ngOnInit(): void {
    this.subjectId = this.route.snapshot.paramMap.get('subjectId');
    this.moduleId = this.route.snapshot.paramMap.get('moduleId');
    if (this.subjectId && this.moduleId) {
      this.loadModuleAndItsExistingTopics();
      if (this.newTopicsFormArray.length === 0) this.addNewTopicFieldToForm();
    } else { this.errorMessage = "Subject/Module ID missing."; this.isLoadingPage = false; }
  }

  async loadModuleAndItsExistingTopics(): Promise<void> {
    if (!this.subjectId || !this.moduleId) return;
    this.isLoadingPage = true; this.errorMessage = null;
    try {
      const subjectData = await this.adminSubjectService.getSubjectDetailsWithNestedData(this.subjectId);
      if (subjectData?.Modules) {
        const mod = subjectData.Modules.find(m => m._id === this.moduleId);
        if (mod) { this.moduleDetails = mod; } else { this.errorMessage = "Module not found."; }
      } else { this.errorMessage = "Subject or modules not found."; }
    } catch (e:any) { this.errorMessage = e.message; }
    finally { this.isLoadingPage = false; }
  }

  get newTopicsFormArray() { return this.addTopicsForm.get('topics') as FormArray; }
  createTopicFormGroup(): FormGroup { return this.fb.group({ topicName: ['', Validators.required] }); }
  addNewTopicFieldToForm(): void { if(this.canAddNewTopicField()) this.newTopicsFormArray.push(this.createTopicFormGroup()); }
  removeNewTopicField(index: number): void { if(this.newTopicsFormArray.length > 1) this.newTopicsFormArray.removeAt(index); }
  canAddNewTopicField(): boolean {
    if (this.newTopicsFormArray.length === 0) return true;
    const last = this.newTopicsFormArray.at(this.newTopicsFormArray.length - 1);
    return !!(last && last.get('topicName')?.valid && last.get('topicName')?.value?.trim());
  }
  private requireAtLeastOneValidTopicInFormArray(arr: AbstractControl): ValidationErrors | null {
    return (arr instanceof FormArray && arr.length > 0 && arr.controls.some(c => c.get('topicName')?.value?.trim())) ? null : { requireAtLeastOneValidTopicInFormArray: true };
  }
  toggleAddTopicsSection(): void {
    this.showAddTopicsSection = !this.showAddTopicsSection;
    if (!this.showAddTopicsSection) this.clearAddTopicsFormAndFile();
    else if (this.newTopicsFormArray.length === 0) this.addNewTopicFieldToForm();
  }
  clearAddTopicsFormAndFile(): void {
    this.newTopicsFormArray.clear(); this.addTopicsForm.reset(); this.newTopicsFormArray.clear();
    this.jsonFileName = null; this.jsonError = null; this.uploadedTopics = null;
    if (this.topicJsonFileInputRef) this.topicJsonFileInputRef.nativeElement.value = '';
    this.addTopicsForm.get('topics')?.enable();
    if (this.newTopicsFormArray.length === 0) this.addNewTopicFieldToForm();
  }
  toTitleCase(str: string): string { return str ? str.toLowerCase().split(' ').map(w=>w.charAt(0).toUpperCase()+w.slice(1)).join(' ') : ''; }

  async onAddTopicsSubmit(): Promise<void> {
    if (!this.moduleId || !this.subjectId) { return; }
    let topicsToSubmit: TopicSimpleCreatePayload[] = [];
    if (this.uploadedTopics && this.uploadedTopics.length > 0) {
      topicsToSubmit = this.uploadedTopics.map(t => ({ topicName: this.toTitleCase(t.topicName.trim()) }));
    } else {
      this.addTopicsForm.get('topics')?.markAllAsTouched();
      if (this.addTopicsForm.get('topics')?.invalid) { return; }
      topicsToSubmit = (this.addTopicsForm.get('topics') as FormArray).controls
        .map(ctrl => ({ topicName: this.toTitleCase(ctrl.get('topicName')?.value?.trim()) }))
        .filter(t => t.topicName);
    }
    if (topicsToSubmit.length === 0) { alert("No topics to add."); return; }

    this.isAddingTopics = true;
    const bulkPayload: BulkTopicAddPayload = { moduleId: this.moduleId, subjectId: this.subjectId, topics: topicsToSubmit };
    try {
      const response: BulkTopicAddResponse = await this.adminTopicService.addTopicsToModule(this.subjectId, this.moduleId, topicsToSubmit);
      if (response.success) { alert(response.message || `${topicsToSubmit.length} topic(s) added successfully!`); this.toggleAddTopicsSection(); this.clearAddTopicsFormAndFile(); this.loadModuleAndItsExistingTopics();
      } else {
        let errorDetail = response.data?.errors?.map(e => `- "${e.topicNameAttempted}": ${e.error}`).join("\n") || '';
        alert(`Failed: ${response.message || 'Unknown error'}${errorDetail ? `\nDetails:\n${errorDetail}` : ''}`);
      }
    } catch (error: any) { alert(`Error: ${error.message}`); }
    finally { this.isAddingTopics = false; }
  }

  onTopicFileSelected(event: Event): void { /* ... as before ... */ }

  isValidTopicSimpleCreatePayloadArray(data: any): data is TopicSimpleCreatePayload[] {
    // Validate that data is an array of objects with a non-empty string 'topicName'
    return Array.isArray(data) && data.every(
      (item) => typeof item === 'object' && item !== null && typeof item.topicName === 'string' && item.topicName.trim().length > 0
    );
  }
  
  
  clearTopicJsonUploadFields(): void { /* ... as before ... */ }
  downloadTopicDemoJson(): void { /* ... as before ... */ }


  async openResourceModal(topic: TopicDetailsBackendNested, resourceType: 'Assessments' | 'Notes' | 'Assignments' | 'Revision'): Promise<void> {
    console.log(`ModuleContentPage: Opening resource modal for ${resourceType} of topic: ${topic.TopicName} (ID: ${topic._id})`);
    this.selectedResourceType = resourceType;
    this.isLoadingTopicResourcesForModal = true;
    this.isResourceModalOpen = true;
    this.currentTopicResources = []; // Reset

    try {
      const fullTopicDetails = await this.adminTopicService.getTopicWithResources(topic._id);
      if (fullTopicDetails) {
        this.selectedTopicForResources = fullTopicDetails;
        switch (resourceType) {
          case 'Assessments': this.currentTopicResources = fullTopicDetails.Assessments ? [...fullTopicDetails.Assessments] : []; break;
          case 'Notes': this.currentTopicResources = fullTopicDetails.Notes ? [...fullTopicDetails.Notes] : []; break;
          case 'Assignments': this.currentTopicResources = fullTopicDetails.Assignments ? [...fullTopicDetails.Assignments] : []; break;
          case 'Revision': this.currentTopicResources = fullTopicDetails.RevisionMaterials ? [...fullTopicDetails.RevisionMaterials] : []; break;
        }
      } else { this.errorMessage = `Could not load details for topic "${topic.TopicName}".`; this.closeResourceModal(); }
    } catch (e:any) { this.errorMessage = `Error loading resources: ${e.message}`; this.closeResourceModal(); }
    finally { this.isLoadingTopicResourcesForModal = false; }
  }

  closeResourceModal(): void { this.isResourceModalOpen = false; this.selectedTopicForResources = null; this.selectedResourceType = null; this.currentTopicResources = []; }

  async handleResourcesSaved(updatedResources: any[]): Promise<void> {
    if (!this.selectedTopicForResources || !this.selectedResourceType) { return; }
    const topicIdToUpdate = this.selectedTopicForResources._id;
    this.isAddingTopics = true; // Or specific isLoadingResourcesSave = true
    try {
      let response: GenericMutationResponse | undefined;
      switch (this.selectedResourceType) {
        case 'Assessments':
          response = await this.adminTopicService.updateTopicAssessments(topicIdToUpdate, updatedResources as AssessmentItem[]);
          break;
        default: alert(`Save for "${this.selectedResourceType}" TBD.`); this.isAddingTopics = false; this.closeResourceModal(); return;
      }
      if (response && response.success) { alert(`${this.selectedResourceType} updated!`); this.loadModuleAndItsExistingTopics(); }
      else { alert(`Failed to save: ${response?.message}`); }
    } catch (e: any) { alert(`Error saving: ${e.message}`); }
    finally { this.isAddingTopics = false; this.closeResourceModal(); }
  }

  editTopicDetails(topic: TopicDetailsBackendNested): void {
    console.log("Edit topic details action for:", topic);
    alert("Edit Topic Details - TBD");
  }
  goBackToSubject(): void { if (this.subjectId) this.router.navigate(['/admin/subjects', this.subjectId]); else this.router.navigate(['/admin/subjects']); }
}