// src/app/modules/admin/models/subject.model.ts

// Import from course.model.ts IF MinimalCourseInfo is defined there and exported.
// If MinimalCourseInfo is only for subjects, define it here.
// For now, assuming it comes from course.model.ts:
import { MinimalCourseInfo } from './course.model';

// --- Basic Info for Forms ---
export interface CreatedByInfo {
  _id: string;
  email: string;
  full_name: string;
}

// For the "Add Subject" form
export interface SubjectBasicInfo {
  name: string;
  description: string;
  assignedCourseIds?: string[]; // Array of Course IDs this subject should be linked to
}

export interface TopicSimpleCreatePayload {
  topicName: string;
  // Add other simple fields the form might collect for a new topic like topicContent, topicVideos if any
  // topicContent?: string;
  // topicVideos?: string[];
}
// For the "Add Module" Form (used by SubjectModuleAddComponent & SubjectDetailPageComponent)
export interface ModuleBasicInfo {
  moduleName: string;
  moduleDescription?: string;
  appliesToCourseIds: string[]; // IDs of courses THIS MODULE specifically applies to (ReqForCourses)
  initialTopics: TopicSimpleCreatePayload[]; // Simplified topic input for creation
}

export interface BulkTopicAddPayload {
  moduleId: string;
  subjectId: string;
  topics: TopicSimpleCreatePayload[];
}

// --- Backend Data Structures (as received AFTER decryption) ---

export interface CreatedByInfo { // Helper for consistent created_by structure
  _id: string;
  email: string;
  full_name: string;
}

// Raw Topic structure from backend (as nested in Module, from your log)
export interface TopicDetailsBackendNested {
  Assessments: any;
  _id: string;
  TopicName: string;
  ModuleID?: string; // Backend log sometimes omits if nested, but good for consistency
  TopicVideos?: string[];
  TopicContent?: string; // From your DB schema example
  sequence_order?: number;
  is_active?: boolean;
  created_by?: CreatedByInfo;
  CreatedAt?: string;
  UpdatedAt?: string;
  __v?: number;
  Assessment?: string;
}

// Raw Module structure from backend (as nested in Subject, from your log)
export interface ModuleDetailsBackendNested {
  _id: string;
  ModuleName: string;
  SubjectID: string;
  ModuleDescription?: string;
  ModuleCredits?: number;
  ReqForCourses?: string[]; // From your DB schema, matches `appliesToCourseIds` in ModuleBasicInfo
  sequence_order?: number;
  is_active?: boolean;
  created_by?: CreatedByInfo;
  CreatedAt?: string;
  UpdatedAt?: string;
  __v?: number;
  Topics: TopicDetailsBackendNested[]; // Array of Topic objects from your log
}

// Raw Subject data structure from backend (e.g., GET /admin/subjects/view/:subjectId)
// This is what AdminSubjectService's getSubjectDetailsWithNestedData should return
export interface SubjectDetailsBackend {
  _id: string;
  SubjectName: string;
  SubjectDescription?: string;
  SubjectCredits?: number;
  SubjectInstructor?: string[];       // Array of User ObjectIds
  AssociatedCourses?: MinimalCourseInfo[]; // Array of { _id, CourseName } - matches your log!
  is_active?: boolean;                // From your log
  created_by?: CreatedByInfo;       // From your log
  CreatedAt: string;                 // From your log
  UpdatedAt: string;                 // From your log
  __v?: number;
  Modules: ModuleDetailsBackendNested[]; // Directly nested modules & topics, from your log
  // Fields from your DB schema that might not have been in the specific log:
  SubjectLevel?: string;
  SubjectType?: string;
  // SubjectModules: ["ObjectId (array, ref: 'Module')"], // From schema: If backend sends only IDs here
                                                        // then `Modules` array above is redundant.
                                                        // Your log showed nested `Modules`. Prioritize the log.
}


// --- Frontend View Models (FE) - What components will use for display ---

// For displaying a Topic in an expanded Module view
export interface TopicListItemFE {
  _id: string;
  topicName: string;
  // sequence_order?: number; // If needed for display/sorting
}

// For displaying a Module in the Subject Detail Page (including its topics)
export interface ModuleListItemFE {
  _id: string;
  moduleName: string;
  moduleDescription?: string;
  topicCount: number;           // Derived from Topics.length
  importance?: string;         // UI-driven or future backend field
  isTopicsVisible?: boolean;   // UI state for controlling dropdown/expansion
  topics: TopicListItemFE[];    // Transformed Topic objects for display
  isLoadingTopics?: boolean;   // UI state (though less needed if topics are embedded)
  // sequence_order?: number;   // If needed for display/sorting
}

// For the complete Subject Detail view (what SubjectDetailPageComponent.subjectViewData will hold)
export interface SubjectDetailViewFE {
  _id: string;
  name: string;                // from SubjectName
  description: string;         // from SubjectDescription
  credits?: number;            // from SubjectCredits
  subjectLevel?: string;
  subjectType?: string;
  createdAt: Date;
  updatedAt?: Date;
  createdByFullName?: string;
  isActive?: boolean;
  associatedCourses: MinimalCourseInfo[]; // Already {_id, CourseName} format from backend
  modules: ModuleListItemFE[];            // List of processed modules for display
}

// For listing subjects in SubjectManagementPageComponent
export interface SubjectListItem { // Renamed from your original SubjectListItemFE
  _id: string;
  name: string;         // from SubjectName
  description: string;  // from SubjectDescription (truncated)
  courseCount?: number; // from AssociatedCourses.length
  isActive?: boolean;    // from is_active
}

// ----- API Request/Response Wrappers -----
export interface EncryptedListPayload {
  responseAesKeyB64: string;
  encryptedData: string; // For lists, this is Base64 of JSON string of Array. For single, Base64 of JSON string of Object.
}

// Used for GET /admin/subjects/view-subjects (list)
// AND for GET /admin/subjects/view/:subjectId (single - backend sends single object in encryptedData)
export interface FetchSubjectsApiResponse {
  success: boolean;
  statusCode: number;
  data?: EncryptedListPayload;
  message: string;
}

export interface EncryptedSubjectRequest { // For POST/PUT subject data
  encryptedAesKeyB64: string;
  encryptedPayloadB64: string;
}

export interface ModuleMutationResponse { // Changed from SubjectMutationResponse if it returns Module
  success: boolean;
  message: string;
  data?: ModuleDetailsBackendNested; // Returns the created/updated module
  statusCode?: number;
}

// If add SINGLE topic returns just the topic
export interface TopicMutationResponse {
    success: boolean;
    message: string;
    data?: TopicDetailsBackendNested;
    statusCode?: number;
}

// Use this for creating/updating a SUBJECT entity
export interface SubjectMutationResponse {
  success: boolean;
  message: string;
  data?: SubjectDetailsBackend;
  statusCode?: number;
}






// Response from backend for creating/updating a subject or a module


// Response from backend for bulk module creation
export interface BulkModuleAddResponse {
  success: boolean;
  message: string;
  statusCode?: number;
  data?: {
    createdModulesCount?: number;
    createdModuleIds?: string[];
    errors?: { moduleNameAttempted: string; error: string }[];
  };
}

// Payload for updating a subject
export interface SubjectUpdatePayload {
  name: string;
  description: string;
  assignedCourseIds: string[]; // The full new list of associated course IDs
  // Add other editable fields of a Subject
  SubjectCredits?: number;
  SubjectLevel?: string;
  SubjectType?: string;
  is_active?: boolean;
}

// ... other interfaces ...
export interface TopicSimpleCreatePayload {
  topicName: string;
  // Potentially other fields from your add topic form for a single topic:
  // topicContent?: string;
  // topicVideos?: string[]; // Array of video URLs/IDs
  // sequenceOrder?: number;
}

export interface BulkTopicAddResponse { // <<< MUST BE EXPORTED
  success: boolean;
  message: string;
  statusCode?: number;
  data?: {
    createdTopicsCount?: number;
    createdTopicIds?: string[];
    errors?: { topicNameAttempted: string, error: string }[];
  };
}

export interface EncryptedGenericRequest { // <<< ENSURE THIS IS EXPORTED
  encryptedAesKeyB64: string;
  encryptedPayloadB64: string;
}