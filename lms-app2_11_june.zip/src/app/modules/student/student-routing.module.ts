import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StudentDashboardPageComponent } from './pages/student-dashboard-page/student-dashboard-page.component';

const routes: Routes = [
  { path: 'dashboard', component: StudentDashboardPageComponent },
  // Add other student routes like /courses, /assignments later
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StudentRoutingModule { }