import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StudentRoutingModule } from './student-routing.module';
import { StudentDashboardPageComponent } from './pages/student-dashboard-page/student-dashboard-page.component';
// Import other student components here as you create them

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    StudentRoutingModule,
    StudentDashboardPageComponent // Import if used in this module's routes
  ]
})
export class StudentModule { }