import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../../core/services/auth.service'; // Adjust path
import { User } from '../../../../core/models/user.model';
@Component({
  selector: 'app-student-dashboard-page',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="p-6">
      <h1 class="text-2xl font-semibold text-gray-800">Student Dashboard</h1>
      <p *ngIf="currentUser" class="mt-2">Welcome, {{ currentUser.fullName }}!</p>
      <p class="mt-4 text-gray-600">Your courses, assignments, and grades will appear here.</p>
    </div>
  `
})
export class StudentDashboardPageComponent implements OnInit {
  currentUser: User | null = null
  
  constructor(private authService: AuthService) {}

  ngOnInit(): void {
    this.authService.currentUser.subscribe(user => this.currentUser = user);
  }
}