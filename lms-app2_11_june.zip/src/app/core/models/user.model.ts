export interface OtpVerificationResponse {
  success: boolean;
  message: string;
  statusCode?: number;
  data?: {
    emailVerified?: boolean;
    mobileVerified?: boolean;
    status?: string; // e.g., 'pending_mobile_verification', 'active'
    // Optionally return JWT token here if login is immediate after final verification
    // token?: string;
    // user?: User;
  };
}

export interface ResendOtpResponse {
  success: boolean;
  message: string;
  statusCode?: number;
}


export interface StudentRegistrationPayload {
  fullName: string; // Mapped from full_name or consistent with frontend forms
  email: string;
  password?: string; // For self-registration
  mobileNumber?: string; // Optional, mapped from mobile_number
  // Potentially other fields students provide on self-registration
  // courseOfInterest?: string; // Example
}


export interface AdminRegistrationPayload {
  email: string;
  mobile_number: string;
  full_name: string;
  password?: string;
}

export interface LoginPayload {
  email: string;
  password?: string;
}

export interface EncryptedLoginRequest {
  encryptedAesKeyB64: string;
  encryptedPayloadB64: string;
}

export interface User {
fullName: any;
  _id: string;
  email: string;
  full_name: string;
  roles: string[];
}

export interface AuthResponse {
  statusCode: number;
  data?: {
    token: string;
    user: User;
    expiresIn: string;
  };
  message: string;
  success: boolean;
}
