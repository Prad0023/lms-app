import { Injectable, PLATFORM_ID, Inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, throwError, firstValueFrom } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environments'; // Ensure this path is correct
import { EncryptionService } from './encryption.service'; // Assuming same folder
import {
  ResendOtpResponse, OtpVerificationResponse, StudentRegistrationPayload,
  AdminRegistrationPayload, LoginPayload, EncryptedLoginRequest, AuthResponse, User
} from '../models/user.model'; // Adjust path as needed
// --- Interfaces ---

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = `${environment.apiUrl}/auth`;
  private currentUserSubject: BehaviorSubject<User | null>;
  public currentUser: Observable<User | null>;

  private readonly TOKEN_KEY = 'authToken';
  private readonly USER_KEY = 'currentUser';
  private readonly isBrowser: boolean;

  constructor(
    private http: HttpClient,
    private router: Router,
    private encryptionService: EncryptionService,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    this.isBrowser = isPlatformBrowser(this.platformId);

    let initialUser: User | null = null;
    if (this.isBrowser) {
      const storedUserString = localStorage.getItem(this.USER_KEY);
      if (storedUserString) {
        try {
          initialUser = JSON.parse(storedUserString);
        } catch (e) {
          console.error('Error parsing stored user from localStorage', e);
          if (this.isBrowser) localStorage.removeItem(this.USER_KEY);
        }
      }
    }
    this.currentUserSubject = new BehaviorSubject<User | null>(initialUser);
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue(): User | null {
    return this.currentUserSubject.value;
  }

  public get token(): string | null {
    if (this.isBrowser) {
      return localStorage.getItem(this.TOKEN_KEY);
    }
    return null;
  }

  public isLoggedIn(): boolean {
    if (this.isBrowser) {
      return !!localStorage.getItem(this.TOKEN_KEY); // Corrected direct access
    }
    return false;
  }

  // --- Admin Registration ---
  registerFirstAdmin(payload: AdminRegistrationPayload): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiUrl}/register-first-admin`, payload).pipe(
      tap(response => {
        if (response.success) {
          console.log('Admin registration successful:', response.message);
        } else {
          console.warn('Admin registration failed on server:', response.message);
        }
      }),
      catchError(this.handleError)
    );
  }

  // --- Login (with Encryption) ---
  async login(loginDetails: LoginPayload): Promise<AuthResponse> {
    try {
      console.log("AuthService: Login process started for:", loginDetails.email);

      // vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
      // THESE LINES WERE MISSING FROM THE CODE YOU PASTED IN THE PREVIOUS TURN
      // THEY ARE NECESSARY TO SETUP THE VARIABLES USED LATER
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      console.log("RSA Public CryptoKey obtained.");

      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      console.log("AES CryptoKey generated.");

      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      console.log("AES Key (Base64 for RSA encryption):", aesKeyBase64ForRsa.substring(0, 10) + "...");
      // ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

      const rsaEncryptedAesKeyBase64 = await this.encryptionService.encryptAesKeyBase64WithRsa(
        aesKeyBase64ForRsa, // This variable is now defined
        rsaPublicKeyCryptoKey // This variable is now defined
      );
      console.log("RSA Encrypted AES Key (Base64 for payload):", rsaEncryptedAesKeyBase64.substring(0, 10) + "...");

      const aesEncryptedPayloadBase64 = await this.encryptionService.encryptLoginPayloadAesGcm(
        loginDetails,
        aesCryptoKey // This variable is now defined
      );
      console.log("AES-GCM Encrypted Login Payload (Base64 for payload):", aesEncryptedPayloadBase64.substring(0, 10) + "...");

      const encryptedRequest: EncryptedLoginRequest = {
        encryptedAesKeyB64: rsaEncryptedAesKeyBase64,
        encryptedPayloadB64: aesEncryptedPayloadBase64
      };

      console.log("AuthService: Final encrypted request payload:", JSON.stringify(encryptedRequest).substring(0, 100) + "...");
      console.log("AuthService: Attempting HTTP POST to /login");
      const response = await firstValueFrom(
        this.http.post<AuthResponse>(`${this.apiUrl}/login`, encryptedRequest).pipe(
          tap(res => {
            console.log("AuthService: RAW RESPONSE from /login API:", JSON.stringify(res)); // Log raw response

            if (res && typeof res.success === 'boolean') {
              if (res.success && res.data && res.data.token && res.data.user) { // <<< Be very specific here
                console.log("AuthService: Login API reported success. User data:", res.data.user, "Token:", res.data.token.substring(0, 15) + "...");
                try {
                  this.storeAuthData(res.data.token, res.data.user); // << CALLING storeAuthData
                  // Navigation is called AFTER storing data
                  this.navigateToDashboard(res.data.user.roles);
                  console.log("AuthService: Navigation to dashboard should have been initiated.");
                } catch (e: any) {
                  console.error("AuthService: CRITICAL ERROR during post-login processing (store/navigate):", e.message, e);
                }
              } else {
                // Log detailed reasons for failure if success is true but data is bad
                if (res.success && !res.data) console.error("AuthService: Login successful but res.data is missing or falsy.");
                else if (res.success && res.data && !res.data.token) console.error("AuthService: Login successful but res.data.token is missing.");
                else if (res.success && res.data && !res.data.user) console.error("AuthService: Login successful but res.data.user is missing.");
                else console.warn("AuthService: Login API reported failure or unexpected data structure:", res.message);
              }
            } else {
              console.error("AuthService: Invalid response structure from /login API (res or res.success is missing/invalid):", res);
            }
          }),
          catchError(error => {
            console.error("AuthService: HTTP error caught in login observable pipe:", error);
            return throwError(() => error);
          })
        )
      );
      console.log("AuthService: login promise is resolving with response object:", response);
      return response;
    } catch (error: any) {
      // ... (outer catch remains the same) ...
      console.error('AuthService: Outer catch for login process failed:', error.message, error);
      const httpError = error instanceof HttpErrorResponse ? error : null;
      return {
        statusCode: httpError?.status || 500,
        message: (httpError?.error as any)?.message || error.message || 'Login failed due to an unexpected client-side error.',
        success: false,
      };
    }
  }



  // --- OTP Verification Methods ---
  verifyEmailOtp(email: string, otp: string): Observable<OtpVerificationResponse> {
    const endpoint = `${this.apiUrl}/verify-email-otp`;
    console.log(`AuthService: Verifying email OTP for ${email}`);
    return this.http.post<OtpVerificationResponse>(endpoint, { email, otp }).pipe(
      tap(res => console.log("Email OTP Verification Response:", res)),
      catchError(this.handleError) // Re-use generic error handler
    );
  }

  resendEmailOtp(email: string): Observable<ResendOtpResponse> {
    const endpoint = `${this.apiUrl}/resend-email-otp`;
    console.log(`AuthService: Resending email OTP for ${email}`);
    return this.http.post<ResendOtpResponse>(endpoint, { email }).pipe(
      tap(res => console.log("Resend Email OTP Response:", res)),
      catchError(this.handleError)
    );
  }

  verifyMobileOtp(identifier: string, otp: string, identifierType: 'email' | 'mobileNumber' = 'email'): Observable<OtpVerificationResponse> {
    // Backend needs to know if 'identifier' is an email or mobile to find the user
    // If backend only accepts one, adjust payload. For flexibility, let's send what it is.
    // Or, better, use a userId if available from previous step.
    const endpoint = `${this.apiUrl}/verify-mobile-otp`;
    console.log(`AuthService: Verifying mobile OTP for ${identifierType}: ${identifier}`);
    const payload: any = { otp };
    if (identifierType === 'email') payload.email = identifier;
    if (identifierType === 'mobileNumber') payload.mobileNumber = identifier;
    // if using userId: payload.userId = identifier;

    return this.http.post<OtpVerificationResponse>(endpoint, payload).pipe(
      tap(res => console.log("Mobile OTP Verification Response:", res)),
      catchError(this.handleError)
    );
  }

  resendMobileOtp(identifier: string, identifierType: 'email' | 'mobileNumber' = 'email'): Observable<ResendOtpResponse> {
    const endpoint = `${this.apiUrl}/resend-mobile-otp`;
    console.log(`AuthService: Resending mobile OTP for ${identifierType}: ${identifier}`);
    const payload: any = {};
    if (identifierType === 'email') payload.email = identifier;
    if (identifierType === 'mobileNumber') payload.mobileNumber = identifier;

    return this.http.post<ResendOtpResponse>(endpoint, payload).pipe(
      tap(res => console.log("Resend Mobile OTP Response:", res)),
      catchError(this.handleError)
    );
  }
  // <<< SINGLE IMPLEMENTATION of navigateToDashboard >>>
  navigateToDashboard(roles: string[]): void {
    console.log('AuthService: Attempting to navigate based on roles:', roles);
    if (!roles || roles.length === 0) {
      console.warn("AuthService: No roles found for user, navigating to fallback.");
      this.router.navigate(['/']);
      return;
    }

    if (roles.map(r => r.toLowerCase()).includes('admin')) {
      console.log("AuthService: Navigating to /admin/dashboard");
      this.router.navigate(['/admin/dashboard']);
    } else if (roles.map(r => r.toLowerCase()).includes('teacher')) {
      console.log("AuthService: Navigating to /teacher/dashboard");
      this.router.navigate(['/teacher/dashboard']);
    } else if (roles.map(r => r.toLowerCase()).includes('student')) {
      console.log("AuthService: Navigating to /student/dashboard");
      this.router.navigate(['/student/dashboard']);
    } else {
      console.warn('AuthService: No matching dashboard for roles, navigating to fallback.');
      this.router.navigate(['/']);
    }
  }

  registerStudent(payload: StudentRegistrationPayload): Observable<AuthResponse> { // AuthResponse is what backend sends initially
    const registerStudentEndpoint = `${this.apiUrl}/register-student`;
    console.log(`AuthService: Student self-registration attempt for: ${payload.email}`);
    return this.http.post<AuthResponse>(registerStudentEndpoint, payload).pipe(
      tap(response => {
        if (response.success) {
          console.log('Student registration successful, backend should have sent OTPs:', response.message);
          // DO NOT LOG IN YET. Frontend will navigate to OTP verification.
          // Store email or userId if needed for OTP verification steps, perhaps in a temporary service state
          // For now, component will pass email to OTP page.
        } else {
          console.warn('Student registration failed on server:', response.message);
        }
      }),
      catchError(this.handleError)
    );
  }


  // <<< SINGLE IMPLEMENTATION of storeAuthData >>>
  private storeAuthData(token: string, user: User): void {
    console.log("AuthService: Attempting to store auth data. Token:", token.substring(0, 15) + "...", "User:", user);
    if (this.isBrowser) {
      try {
        localStorage.setItem(this.TOKEN_KEY, token);
        localStorage.setItem(this.USER_KEY, JSON.stringify(user));
        console.log("AuthService: Data stored in localStorage. TOKEN_KEY:", localStorage.getItem(this.TOKEN_KEY)?.substring(0, 15) + "...", "USER_KEY:", localStorage.getItem(this.USER_KEY));
      } catch (e) {
        console.error("AuthService: Error writing to localStorage in storeAuthData:", e);
        // Potentially re-throw or handle this critical failure
      }
    }
    this.currentUserSubject.next(user); // <<<< CRUCIAL for immediate state update
    console.log('AuthService: currentUserSubject updated. New value:', this.currentUserSubject.value);
    console.log('AuthService: Verifying isLoggedIn() after storeAuthData:', this.isLoggedIn());
    console.log('AuthService: Verifying token getter after storeAuthData:', this.token?.substring(0, 15) + "...");
  }

  // <<< SINGLE IMPLEMENTATION of logout >>>
  logout(): void {
    if (this.isBrowser) {
      localStorage.removeItem(this.TOKEN_KEY);
      localStorage.removeItem(this.USER_KEY);
    }
    this.currentUserSubject.next(null);
    this.router.navigate(['/auth/login']);
    console.log('User logged out.');
  }

  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = 'An unknown error occurred!';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Client-side error: ${error.error.message}`;
    } else {
      errorMessage = `Server error Code: ${error.status}\nMessage: ${(error.error as any)?.message || error.message}`;
    }
    console.error('AuthService handleError:', errorMessage, error);
    return throwError(() => new Error(errorMessage));
  }
}