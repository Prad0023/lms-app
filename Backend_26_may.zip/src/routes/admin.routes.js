import { Router } from 'express';
// We'll import controllers and middlewares later
import { protect } from '../middlewares/auth.middleware.js';  
import { adminController } from '../controllers/admin.controller.js'; // Ensure this path is correct
import { authorizePermission } from '../middlewares/role.middleware.js';
const router = Router();

/**
 * @route   POST /api/v1/admin/teachers/initiate-hire
 * @desc    Admin initiates the hiring process for a new teacher.
 *          Payload (after decryption): { teacherInfo: { fullName, email, mobile, designation }, sendEmail: boolean }
 * @access  Private (Admin with 'user_create' permission)
 */
// Placeholder route (we'll replace this with actual admin routes)


router.post(
    '/teachers/initiate-hire', // The specific path for this action
    protect,                   // Middleware: Verifies JWT, attaches req.user
    authorizePermission('user', 'create'), // Middleware: Checks if user has 'create' permission on 'user' resource
    adminController.initiateTeacherHire // The controller function to handle the request
);

router.get(
    '/teachers/view-teachers',
    protect,
    authorizePermission('user', 'read_all'), // Assuming 'read_all' on 'user' implies viewing teachers
    adminController.viewAllTeachers
);

router.get('/', (req, res) => {
    res.send('Admin routes are working!');
});

export default router;