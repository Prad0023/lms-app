// src/services/subject/subject.service.js
import Subject from '../../models/subject.model.js';
import Course from '../../models/course.model.js'; // Needed if assigning to courses immediately
import { ApiError } from '../../utils/apiResponse.utils.js';
import { logAuditEvent } from '../common/audit.service.js'; // Assuming path
import mongoose from 'mongoose';


export const subjectService = {
    createSubject: async (subjectInputData, adminUserId) => {
        const {
            SubjectName,
            SubjectDescription,
            SubjectCredits,
            SubjectLevel,
            SubjectType,
            assignedCourseIds,
        } = subjectInputData;

        if (!SubjectName) {
            throw new ApiError(400, 'SubjectName is required.');
        }

        const existingSubject = await Subject.findOne({ SubjectName });
        if (existingSubject) {
            throw new ApiError(409, `Subject with name '${SubjectName}' already exists.`);
        }

        let validCourseObjectIds = [];
        if (assignedCourseIds && assignedCourseIds.length > 0) {
            console.log('[SubjectService] Received assignedCourseIds:', assignedCourseIds);
            for (const idStr of assignedCourseIds) {
                if (!idStr || typeof idStr !== 'string' || !mongoose.Types.ObjectId.isValid(idStr.trim())) {
                    console.error(`[SubjectService] Invalid ObjectId string received: "${idStr}"`);
                    throw new ApiError(400, `The provided course ID "${idStr}" is not a valid ObjectId format.`);
                }
                validCourseObjectIds.push(new mongoose.Types.ObjectId(idStr.trim()));
            }

            console.log('[SubjectService] Converted validCourseObjectIds:', validCourseObjectIds);
            const coursesExist = await Course.find({ '_id': { $in: validCourseObjectIds } }).select('_id');
            if (coursesExist.length !== validCourseObjectIds.length) {
                const existingCourseIdsSet = new Set(coursesExist.map(c => c._id.toString()));
                const invalidIds = assignedCourseIds.filter(id => !existingCourseIdsSet.has(id.trim()));
                throw new ApiError(400, `One or more assigned courses do not exist in the database. Invalid or non-existent IDs: ${invalidIds.join(', ')}`);
            }
        }

        const newSubject = new Subject({
            SubjectName,
            SubjectDescription,
            SubjectCredits,
            SubjectLevel,
            SubjectType,
            AssociatedCourses: validCourseObjectIds,
            created_by: adminUserId,
        });

        await newSubject.save();

        if (validCourseObjectIds.length > 0) {
            try {
                const courseUpdateResult = await Course.updateMany(
                    { _id: { $in: validCourseObjectIds } },
                    { $addToSet: { CourseSubjects: newSubject._id } }
                );
                console.log(`[SubjectService] Updated ${courseUpdateResult.modifiedCount} courses to include subject ${newSubject._id}`);
            } catch (courseUpdateError) {
                console.error(`[SubjectService] Error updating courses with new subject ${newSubject._id}:`, courseUpdateError);
            }
        }

        await logAuditEvent({ /* ... audit log data ... */ });
        await newSubject.populate([
            { path: 'AssociatedCourses', select: 'CourseName _id' },
            { path: 'created_by', select: 'full_name email' }
        ]);

        return newSubject;
    },


    getAllSubjects: async () => {
        const subjects = await Subject.find({})
            .populate({ path: 'created_by', select: 'full_name email _id' })
            // Add other populates if needed (e.g., SubjectInstructor)
            .sort({ CreatedAt: -1 });
        return subjects;
    },

    getSubjectById: async (subjectId) => {
        if (!mongoose.Types.ObjectId.isValid(subjectId)) {
            throw new ApiError(400, 'Invalid subject ID format.');
        }

        const subject = await Subject.findById(subjectId)
            .populate({
                path: 'AssociatedCourses', // Populate the courses this subject is part of
                select: 'CourseName _id'   // Select specific fields from Course
            })
            .populate({
                path: 'SubjectInstructor', // Populate instructor details
                select: 'full_name email _id'
            })
            // .populate({ // If you uncomment SubjectModules in subject.model.js and want to populate them
            //     path: 'SubjectModules',
            //     select: 'ModuleName _id sequence_order', // Select specific fields from Module
            //     populate: { // Optional: further populate topics within each module
            //         path: 'ModuleTopics', // Assuming Module schema has ModuleTopics field
            //         select: 'TopicName _id sequence_order'
            //     }
            // })
            .populate({
                path: 'created_by',
                select: 'full_name email _id'
            });

        if (!subject) {
            throw new ApiError(404, 'Subject not found.');
        }
        return subject;
    },

    updateSubject: async (subjectId, updateData, adminUserId) => {
        if (!mongoose.Types.ObjectId.isValid(subjectId)) {
            throw new ApiError(400, 'Invalid subject ID format.');
        }

        const {
            SubjectName, // Mapped from 'name' in controller
            SubjectDescription, // Mapped from 'description' in controller
            SubjectCredits,
            SubjectLevel,
            SubjectType,
            is_active,
            assignedCourseIds, // The COMPLETE new list of associated Course ObjectIds (strings)
            // ... other updatable subject fields
        } = updateData;

        const subjectToUpdate = await Subject.findById(subjectId);
        if (!subjectToUpdate) {
            throw new ApiError(404, 'Subject not found for update.');
        }

        // Check for name conflict if SubjectName is being changed
        if (SubjectName && SubjectName !== subjectToUpdate.SubjectName) {
            const existingSubjectWithName = await Subject.findOne({ SubjectName });
            if (existingSubjectWithName) {
                throw new ApiError(409, `Another subject with name '${SubjectName}' already exists.`);
            }
            subjectToUpdate.SubjectName = SubjectName;
        }

        // Update basic fields
        if (typeof SubjectDescription !== 'undefined') subjectToUpdate.SubjectDescription = SubjectDescription;
        if (typeof SubjectCredits !== 'undefined') subjectToUpdate.SubjectCredits = SubjectCredits;
        if (typeof SubjectLevel !== 'undefined') subjectToUpdate.SubjectLevel = SubjectLevel;
        if (typeof SubjectType !== 'undefined') subjectToUpdate.SubjectType = SubjectType;
        if (typeof is_active !== 'undefined') subjectToUpdate.is_active = is_active;

        let oldAssociatedCourseIdsStrings = subjectToUpdate.AssociatedCourses.map(id => id.toString());
        let newValidCourseObjectIds = [];
        let newAssignedCourseIdsStrings = [];

        if (typeof assignedCourseIds !== 'undefined') { // Only process if provided
            if (assignedCourseIds.length > 0) {
                for (const idStr of assignedCourseIds) {
                    if (!idStr || typeof idStr !== 'string' || !mongoose.Types.ObjectId.isValid(idStr.trim())) {
                        throw new ApiError(400, `The provided course ID "${idStr}" in assignedCourseIds is not a valid ObjectId format.`);
                    }
                    newValidCourseObjectIds.push(new mongoose.Types.ObjectId(idStr.trim()));
                    newAssignedCourseIdsStrings.push(idStr.trim());
                }

                const coursesExist = await Course.find({ '_id': { $in: newValidCourseObjectIds } }).select('_id');
                if (coursesExist.length !== newValidCourseObjectIds.length) {
                    const existingCourseIdsSet = new Set(coursesExist.map(c => c._id.toString()));
                    const invalidIds = newAssignedCourseIdsStrings.filter(id => !existingCourseIdsSet.has(id));
                    throw new ApiError(400, `One or more assigned courses do not exist. Invalid or non-existent IDs: ${invalidIds.join(', ')}`);
                }
            }
            // Update the subject's AssociatedCourses
            subjectToUpdate.AssociatedCourses = newValidCourseObjectIds;
        }
        // If assignedCourseIds was not in payload, subjectToUpdate.AssociatedCourses remains unchanged.
        // If assignedCourseIds was an empty array, subjectToUpdate.AssociatedCourses becomes empty.

        const updatedSubject = await subjectToUpdate.save();

        // Now, update the Course documents based on changes to AssociatedCourses
        if (typeof assignedCourseIds !== 'undefined') {
            const coursesToRemoveSubjectFrom = oldAssociatedCourseIdsStrings.filter(id => !newAssignedCourseIdsStrings.includes(id));
            const coursesToAddSubjectTo = newAssignedCourseIdsStrings.filter(id => !oldAssociatedCourseIdsStrings.includes(id));

            if (coursesToRemoveSubjectFrom.length > 0) {
                await Course.updateMany(
                    { _id: { $in: coursesToRemoveSubjectFrom.map(id => new mongoose.Types.ObjectId(id)) } },
                    { $pull: { CourseSubjects: updatedSubject._id } }
                );
                console.log(`[SubjectService] Removed subject ${updatedSubject._id} from courses: ${coursesToRemoveSubjectFrom.join(', ')}`);
            }
            if (coursesToAddSubjectTo.length > 0) {
                await Course.updateMany(
                    { _id: { $in: coursesToAddSubjectTo.map(id => new mongoose.Types.ObjectId(id)) } },
                    { $addToSet: { CourseSubjects: updatedSubject._id } }
                );
                console.log(`[SubjectService] Added subject ${updatedSubject._id} to courses: ${coursesToAddSubjectTo.join(', ')}`);
            }
        }

        await logAuditEvent({
            userId: adminUserId,
            event_type: 'subject_management',
            resource: 'subjects',
            resource_id: updatedSubject._id,
            action: 'update',
            status: 'success',
            details: { updated_fields: Object.keys(updateData) } // Log which fields were in update payload
        });

        // Populate for response
        await updatedSubject.populate([
            { path: 'AssociatedCourses', select: 'CourseName _id' },
            { path: 'created_by', select: 'full_name email' }
        ]);

        return updatedSubject;
    },
    // ... other subject service methods (getById, update, delete)
};