import mongoose from 'mongoose';

const permissionSchema = new mongoose.Schema({
    resource: { type: String, required: true }, // e.g., 'course', 'user', 'submission'
    action: { type: String, required: true }, // e.g., 'create', 'read', 'update', 'delete'
    // attributes: { type: String, default: '*' } // Optional: for fine-grained control like 'own' or '*'
}, { _id: false });

const roleSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Role name is required.'],
        unique: true,
        trim: true,
        lowercase: true, // Standardize role names
    },
    description: {
        type: String,
        trim: true,
    },
    permissions: [permissionSchema], // Embedded permissions
    is_system_role: { // To prevent deletion of core roles like 'admin', 'teacher', 'student'
        type: Boolean,
        default: false,
    }
}, { timestamps: true });

// Example roles: 'admin', 'teacher', 'student'
// Permissions could be like:
// Admin: [{ resource: 'user', action: 'create' }, { resource: 'user', action: 'readAll' }, ...]
// Teacher: [{ resource: 'course', action: 'updateOwn' }, { resource: 'submission', action: 'readOwnCourse' }]
// Student: [{ resource: 'course', action: 'readEnrolled' }, { resource: 'submission', action: 'createOwn' }]


const Role = mongoose.model('Role', roleSchema);
export default Role;