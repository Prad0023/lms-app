import mongoose from 'mongoose';

const moduleSchema = new mongoose.Schema({
    ModuleName: { type: String, required: true, trim: true },
    SubjectID: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject', required: true, index: true },
    ModuleDescription: { type: String, trim: true },
    // ModuleTopics: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Topic' }], // We'll link Topics to Modules
    ModuleCredits: { type: Number, default: 0 },
    // ModulePrerequisites: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Module' }], // Self-referencing
    sequence_order: { type: Number, default: 0 }, // For ordering modules within a subject
    is_active: { type: Boolean, default: true },
    created_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
}, { timestamps: { createdAt: 'CreatedAt', updatedAt: 'UpdatedAt' } });

moduleSchema.index({ SubjectID: 1, ModuleName: 1 });

const Module = mongoose.model('Module', moduleSchema);
export default Module;