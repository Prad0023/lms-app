import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import config from './config/env.config.js';
import errorHandler from './middlewares/errorHandler.middleware.js';
import studentManagementRoutes from './routes/admin/student.management.routes.js';
// Import routes (we'll create these later)
import authRoutes from './routes/auth.routes.js';
import userRoutes from './routes/user.routes.js';
import roleRoutes from './routes/role.routes.js';
// import courseRoutes from './routes/course.routes.js';
import adminRoutes from './routes/admin.routes.js';
import courseManagementRoutes from './routes/admin/course.management.routes.js';
import subjectManagementRoutes from './routes/admin/subject.management.routes.js'; // New import


const app = express();

// Middlewares
app.use(cors()); // Enable CORS for all routes
app.use(helmet()); // Set various HTTP headers for security
app.use(express.json({ limit: '16kb' })); // Parse JSON bodies
app.use(express.urlencoded({ extended: true, limit: '16kb' })); // Parse URL-encoded bodies

if (config.nodeEnv === 'development') {
    app.use(morgan('dev')); // HTTP request logger
}

// --- Routes ---
app.get('/', (req, res) => res.send('RBAC API is running!')); // Health check

app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/users', userRoutes); // For general user profile actions (e.g., current user updating their profile)
app.use('/api/v1/roles', roleRoutes); // For admin managing roles
app.use('/api/v1/admin', adminRoutes); // For admin managing users, etc.
app.use('/api/v1/admin/students', studentManagementRoutes); 
app.use('/api/v1/admin/courses', courseManagementRoutes);
app.use('/api/v1/admin/subjects', subjectManagementRoutes); 
// --- Error Handling ---
// Catch 404 and forward to error handler
app.use((req, res, next) => {
    const error = new Error(`Not Found - ${req.originalUrl}`);
    error.statusCode = 404;
    next(error);
});

// Global error handler (must be last middleware)
app.use(errorHandler);

export default app;