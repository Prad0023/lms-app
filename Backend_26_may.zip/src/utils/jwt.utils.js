import jwt from 'jsonwebtoken';
import config from '../config/env.config.js';

export const generateToken = (userId, userRoles = []) => {
    const payload = {
        user: {
            id: userId,
        },
        // We might not need roles in JWT if we always fetch user from DB on protected routes
        // But can be useful for quick client-side UI toggles (not for backend auth decisions)
        // roles: userRoles.map(r => r.name) // Assuming role object has a 'name' field
    };
    return jwt.sign(payload, config.jwtSecret, { expiresIn: config.jwtExpiresIn });
};

export const verifyToken = (token) => {
    try {
        return jwt.verify(token, config.jwtSecret);
    } catch (error) {
        return null; // Or throw an error to be caught
    }
};