import mongoose from 'mongoose';
import config from './env.config.js';

const connectDB = async () => {
    try {
        await mongoose.connect(config.mongoURI, {
            // useNewUrlParser: true, // No longer needed
            // useUnifiedTopology: true, // No longer needed
            // useCreateIndex: true, // No longer supported - Mongoose handles this by default
            // useFindAndModify: false, // No longer supported
        });
        console.log('MongoDB Connected...');

        // Optional: Setup TTL indexes explicitly if not handled by schema options
        // This is just to show how you might do it if needed. Mongoose schema options are preferred.
        // await mongoose.connection.db.collection('sessions').createIndex({ expires_at: 1 }, { expireAfterSeconds: 0 });
        // await mongoose.connection.db.collection('password_reset_tokens').createIndex({ expires_at: 1 }, { expireAfterSeconds: 0 });

    } catch (err) {
        console.error('MongoDB Connection Error:', err.message);
        process.exit(1); // Exit process with failure
    }
};

export default connectDB;