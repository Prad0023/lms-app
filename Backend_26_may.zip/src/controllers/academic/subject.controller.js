// src/controllers/academic/subject.controller.js
import asyncHandler from '../../utils/asyncHandler.utils.js'; // Adjust path
import { ApiResponse, ApiError } from '../../utils/apiResponse.utils.js'; // Adjust path
import { subjectService } from '../../services/subject/subject.service.js'; // Adjust path
import {
    decryptAesKeyWithRsa,
    decryptPayloadWithAesGcm,
    encryptPayloadWithAesGcm // For encrypted responses
} from '../../utils/crypto.utils.js'; // Adjust path
import cryptoNode from 'crypto';

export const subjectController = {
    createSubject: asyncHandler(async (req, res) => {
        const { encryptedAesKeyB64, encryptedPayloadB64 } = req.body;

        if (!encryptedAesKeyB64 || !encryptedPayloadB64) {
            throw new ApiError(400, 'Encrypted AES key and payload are required for creating a subject.');
        }

        const aesKeyBuffer = decryptAesKeyWithRsa(encryptedAesKeyB64);
        const decryptedFrontendData = decryptPayloadWithAesGcm(encryptedPayloadB64, aesKeyBuffer);

        console.log('[SubjectController] Decrypted data from frontend:', JSON.stringify(decryptedFrontendData, null, 2));

        // Map frontend field names and include assignedCourseIds
        const subjectInputDataForService = {
            SubjectName: decryptedFrontendData.name,
            SubjectDescription: decryptedFrontendData.description,
            SubjectCredits: decryptedFrontendData.credits,
            SubjectLevel: decryptedFrontendData.level,
            SubjectType: decryptedFrontendData.type,
            assignedCourseIds: decryptedFrontendData.assignedCourseIds || [] // Pass this to the service
        };

        if (!subjectInputDataForService.SubjectName) {
            throw new ApiError(400, 'Decrypted payload for subject creation is missing required field: name (which maps to SubjectName).');
        }

        const adminUserId = req.user.id;
        const newSubject = await subjectService.createSubject(subjectInputDataForService, adminUserId);

        // The newSubject returned from the service will now have AssociatedCourses populated
        res.status(201).json(new ApiResponse(201, newSubject, 'Subject created successfully and associated with specified courses.'));
    }),


    getAllSubjects: asyncHandler(async (req, res) => {
        const subjects = await subjectService.getAllSubjects();
        console.log(subjects)
        if (!subjects || subjects.length === 0) {
            const emptyAesKey = cryptoNode.randomBytes(32);
            const encryptedEmpty = encryptPayloadWithAesGcm([], emptyAesKey);
            return res.status(200).json(new ApiResponse(200, {
                responseAesKeyB64: emptyAesKey.toString('base64'),
                encryptedData: encryptedEmpty
            }, 'No subjects found.'));
        }

        const responseAesKeyBuffer = cryptoNode.randomBytes(32);
        const encryptedSubjectsDataB64 = encryptPayloadWithAesGcm(subjects, responseAesKeyBuffer);

        const responsePayload = {
            responseAesKeyB64: responseAesKeyBuffer.toString('base64'),
            encryptedData: encryptedSubjectsDataB64
        };

        res.status(200).json(new ApiResponse(200, responsePayload, 'Subjects retrieved and encrypted.'));
    }),

    getSubjectById: asyncHandler(async (req, res) => {
        const { subjectId } = req.params; // Get subjectId from route parameters

        const subject = await subjectService.getSubjectById(subjectId);
        // subjectService.getSubjectById will throw ApiError(404) if not found

        // Encrypt the response
        const responseAesKeyBuffer = cryptoNode.randomBytes(32);
        const encryptedSubjectDataB64 = encryptPayloadWithAesGcm(subject.toObject(), responseAesKeyBuffer);

        const responsePayload = {
            responseAesKeyB64: responseAesKeyBuffer.toString('base64'),
            encryptedData: encryptedSubjectDataB64
        };

        res.status(200).json(new ApiResponse(200, responsePayload, 'Subject details retrieved successfully.'));
    }),

    updateSubject: asyncHandler(async (req, res) => {
        const { subjectId } = req.params;
        const { encryptedAesKeyB64, encryptedPayloadB64 } = req.body;

        if (!encryptedAesKeyB64 || !encryptedPayloadB64) {
            throw new ApiError(400, 'Encrypted AES key and payload are required for updating a subject.');
        }

        const aesKeyBuffer = decryptAesKeyWithRsa(encryptedAesKeyB64);
        const decryptedUpdateData = decryptPayloadWithAesGcm(encryptedPayloadB64, aesKeyBuffer);

        console.log('[SubjectController] Decrypted update data from frontend:', JSON.stringify(decryptedUpdateData, null, 2));

        // Map frontend field names if necessary
        const updateDataForService = {
            SubjectName: decryptedUpdateData.name,
            SubjectDescription: decryptedUpdateData.description,
            SubjectCredits: decryptedUpdateData.credits,
            SubjectLevel: decryptedUpdateData.level,
            SubjectType: decryptedUpdateData.type,
            is_active: decryptedUpdateData.is_active, // Ensure frontend can send this
            assignedCourseIds: decryptedUpdateData.assignedCourseIds // Expects array of course ID strings
            // Map other editable fields
        };

        // Remove undefined fields so they don't overwrite existing values with null if not provided
        Object.keys(updateDataForService).forEach(key => {
            if (updateDataForService[key] === undefined) {
                delete updateDataForService[key];
            }
        });
        // 'assignedCourseIds' should be an empty array if all associations are to be removed,
        // or not present in payload if associations are not to be changed.
        // The service logic handles `typeof assignedCourseIds !== 'undefined'`

        if (Object.keys(updateDataForService).length === 0) {
            throw new ApiError(400, "No update data provided.");
        }

        const adminUserId = req.user.id;
        const updatedSubject = await subjectService.updateSubject(subjectId, updateDataForService, adminUserId);

        // Response is typically the updated resource (plaintext for CUD operations is common)
        res.status(200).json(new ApiResponse(200, updatedSubject, 'Subject updated successfully.'));
    }),
};