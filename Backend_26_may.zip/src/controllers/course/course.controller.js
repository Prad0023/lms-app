// src/controllers/course/course.controller.js
import asyncHandler from '../../utils/asyncHandler.utils.js';
import { ApiResponse, ApiError } from '../../utils/apiResponse.utils.js';
import { courseService } from '../../services/course/course.service.js';
import {
    decryptAesKeyWithRsa,
    decryptPayloadWithAesGcm,
    encryptPayloadWithAesGcm
} from '../../utils/crypto.utils.js';
import cryptoNode from 'crypto';

export const courseController = {
    createCourse: asyncHandler(async (req, res) => {
        const { encryptedAesKeyB64, encryptedPayloadB64 } = req.body;

        if (!encryptedAesKeyB64 || !encryptedPayloadB64) {
            throw new ApiError(400, 'Encrypted AES key and payload are required for creating a course.');
        }

        const aesKeyBuffer = decryptAesKeyWithRsa(encryptedAesKeyB64);
        const decryptedCourseData = decryptPayloadWithAesGcm(encryptedPayloadB64, aesKeyBuffer);
        console.log("[CreateCourseController] Decrypted Data from Frontend:", decryptedCourseData);
        // Expected decryptedCourseData: { name, description, subjectIds, credits, level, type, etc. }
        // Map frontend names to backend CourseName, CourseDescription if they differ
        const courseInputData = {
            CourseName: decryptedCourseData.name,
            CourseDescription: decryptedCourseData.description,
            course_code: decryptedCourseData.courseCode, // Assuming frontend sends courseCode
            Credits: decryptedCourseData.credits,
            CourseLevel: decryptedCourseData.level,
            CourseType: decryptedCourseData.type,
            subjectIds: decryptedCourseData.subjectIds, // Array of Subject ObjectIds
            // ... map other fields
        };


        if (!courseInputData.CourseName) {
            throw new ApiError(400, 'Decrypted payload for course creation is missing required field: name (CourseName).');
        }

        const adminUserId = req.user.id;
        const newCourse = await courseService.createCourse(courseInputData, adminUserId);

        res.status(201).json(new ApiResponse(201, newCourse, 'Course created successfully.'));
    }),

    getAllCourses: asyncHandler(async (req, res) => {
        const courses = await courseService.getAllCourses();

        if (!courses || courses.length === 0) {
            // Still encrypt an empty array for consistency if that's the desired pattern
            const emptyAesKey = cryptoNode.randomBytes(32);
            const encryptedEmpty = encryptPayloadWithAesGcm([], emptyAesKey);
            return res.status(200).json(new ApiResponse(200, {
                responseAesKeyB64: emptyAesKey.toString('base64'),
                encryptedData: encryptedEmpty
            }, 'No courses found.'));
        }

        const responseAesKeyBuffer = cryptoNode.randomBytes(32);
        const encryptedCoursesDataB64 = encryptPayloadWithAesGcm(courses, responseAesKeyBuffer);

        const responsePayload = {
            responseAesKeyB64: responseAesKeyBuffer.toString('base64'),
            encryptedData: encryptedCoursesDataB64
        };

        res.status(200).json(new ApiResponse(200, responsePayload, 'Courses retrieved and encrypted.'));
    }),

    getCourseById: asyncHandler(async (req, res) => {
        const { courseId } = req.params; // Get courseId from route parameters

        const course = await courseService.getCourseById(courseId);
        // courseService.getCourseById will throw ApiError(404) if not found

        // Encrypt the response
        const responseAesKeyBuffer = cryptoNode.randomBytes(32);
        const encryptedCourseDataB64 = encryptPayloadWithAesGcm(course.toObject(), responseAesKeyBuffer); // Encrypt the single course object

        const responsePayload = {
            responseAesKeyB64: responseAesKeyBuffer.toString('base64'),
            encryptedData: encryptedCourseDataB64
        };

        res.status(200).json(new ApiResponse(200, responsePayload, 'Course details retrieved successfully.'));
    }),
};