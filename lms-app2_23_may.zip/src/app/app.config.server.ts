// src/app/app.config.server.ts
import { mergeApplicationConfig, ApplicationConfig } from '@angular/core';
import { provideServerRendering } from '@angular/platform-server';
import { appConfig } from './app.config'; // Your main app config

// If app.routes.server.ts is empty or doesn't export serverRoutes,
// you might not need to merge anything specific here yet.
// For now, ensure app.routes.server.ts exists even if empty.
// Or, if app.routes.server.ts is meant to be empty for now:
const serverConfig: ApplicationConfig = {
  providers: [
    provideServerRendering()
  ]
};

export const config = mergeApplicationConfig(appConfig, serverConfig);