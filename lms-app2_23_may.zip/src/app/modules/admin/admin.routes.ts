import { Routes } from '@angular/router';

export const ADMIN_ROUTES: Routes = [ // Ensure you EXPORT the routes array
  {
    path: 'dashboard',
    // Example, adjust to your actual admin dashboard component
    loadComponent: () => import('./pages/admin-dashboard-page/admin-dashboard-page.component').then(c => c.AdminDashboardPageComponent)
  },
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' }
];