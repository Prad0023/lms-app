import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';

import { AdminSubjectService } from '../../services/admin-subject.service';
import { SubjectListItem, SubjectDetailsBackend, SubjectBasicInfo } from '../../models/subject.model'; // Using SubjectListItem for the table
import { SubjectAddModalComponent } from '../../components/subject-add-modal/subject-add-modal.component';

@Component({
  selector: 'app-subject-management-page',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    SubjectAddModalComponent
  ],
  templateUrl: './subject-management-page.component.html',
  // styleUrls: ['./subject-management-page.component.css']
})
export class SubjectManagementPageComponent implements OnInit {
  isAddSubjectModalOpen = false;
  subjects: SubjectListItem[] = []; // Use SubjectListItem for display
  isLoadingSubjects = false;
  errorMessage: string | null = null;
  filterForm: FormGroup;

  constructor(
    private router: Router,
    private adminSubjectService: AdminSubjectService,
    private fb: FormBuilder
  ) {
    this.filterForm = this.fb.group({
      searchTerm: [''],
    });
  }

  ngOnInit(): void {
    this.loadSubjects();
    this.filterForm.valueChanges.subscribe(() => {
      this.loadSubjects();
    });
  }

  async loadSubjects(): Promise<void> {
    this.isLoadingSubjects = true;
    this.errorMessage = null;
    try {
      const filters = this.filterForm.value;
      const subjectsFromBackend: SubjectDetailsBackend[] = await this.adminSubjectService.getSubjects(filters);

      this.subjects = subjectsFromBackend.map(sBackend => ({
        _id: sBackend._id,
        name: sBackend.SubjectName, // Map from backend field name
        description: sBackend.SubjectDescription.length > 100 ? sBackend.SubjectDescription.substring(0, 97) + '...' : sBackend.SubjectDescription,
        courseCount: sBackend.Courses?.length || 0 // Count associated courses
      }));
    } catch (error: any) {
      this.errorMessage = error.message || 'Failed to load subjects.';
    } finally {
      this.isLoadingSubjects = false;
    }
  }

  openAddSubjectModal(): void {
    this.isAddSubjectModalOpen = true;
  }

  closeAddSubjectModal(): void {
    this.isAddSubjectModalOpen = false;
  }
  

  handleSubjectAdded(subjectData: SubjectBasicInfo): void {
    console.log('SubjectManagementPage: Subject add initiated from modal:', subjectData);
    this.loadSubjects(); // Refresh list
    this.closeAddSubjectModal();
  }

  viewSubjectDetails(subjectId: string): void { console.log("View subject:", subjectId); }
  editSubject(subjectId: string): void {
  console.log("Edit subject:", subjectId);
  this.router.navigate(['/admin/subjects', subjectId, 'edit']); // Navigate to edit page
}
}