import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { firstValueFrom, catchError, tap, throwError } from 'rxjs';

// Import necessary models and services
import { StudentBasicEnrollInfo } from '../../models/student.model'; // From student.model.ts
import { AdminStudentService, StudentEnrollmentInitiationPayload, EncryptedStudentRequest, StudentEnrollmentResponse } from '../../services/admin-student.service'; // Adjust path
import { EncryptionService } from '../../../../core/services/encryption.service'; // For encryption logic

@Component({
  selector: 'app-student-mail-preview-page',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './student-mail-preview-page.component.html',
  // styleUrls: ['./student-mail-preview-page.component.css']
})
export class StudentMailPreviewPageComponent implements OnInit {
  studentData: StudentBasicEnrollInfo | null = null;
  mailSubject = '';
  mailBody = '';
  simulatedStudentOnboardingLink = '';
  isLoading = false;

  constructor(
    private router: Router,
    private adminStudentService: AdminStudentService, // Service to handle final enrollment
    private encryptionService: EncryptionService // Needed if this component initiates encryption
                                                  // Alternatively, AdminStudentService handles all encryption
  ) {}

  ngOnInit(): void {
    const navigationState = history.state;
    console.log("StudentMailPreviewPageComponent: Received history.state:", navigationState);

    if (navigationState && navigationState.studentData) {
      this.studentData = navigationState.studentData as StudentBasicEnrollInfo;
      console.log("StudentMailPreviewPageComponent: Student data successfully retrieved:", this.studentData);
      this.generateMailContent();
    } else {
      console.error('StudentMailPreviewPageComponent: Student data not found in history.state. Navigating back.');
      this.router.navigate(['/admin/students']);
    }
  }

  private generateMailContent(): void {
    if (!this.studentData) return;

    this.simulatedStudentOnboardingLink = `https://our-lms.com/student-onboarding?token=${Date.now()}-${this.studentData.email.split('@')[0]}`;

    this.mailSubject = `Welcome to Abhyasify LMS, ${this.studentData.fullName}!`;
    this.mailBody = `
Dear ${this.studentData.fullName},

Welcome to Abhyasify LMS! We're excited to have you join our learning community.

Your account has been initiated by an administrator. If this is your first time, please click the link below to complete your profile setup and get started:
${this.simulatedStudentOnboardingLink}

If you have been previously enrolled or have an existing account, you can try logging in directly.

We look forward to seeing you in the courses!

Best regards,
The Abhyasify Team
    `;
  }

  onCancel(): void {
    if (this.isLoading) return;
    console.log('Student mail preview cancelled. No action taken.');
    this.router.navigate(['/admin/students']);
  }

  async onSendMailAndEnroll(): Promise<void> {
    if (!this.studentData || this.isLoading) return;
    this.isLoading = true;
    console.log(`Processing "Send Mail & Enroll" for ${this.studentData.email}`);

    const payload: StudentEnrollmentInitiationPayload = {
      studentInfo: this.studentData, // Contains fullName, email, mobile?, course?
      onboardingLink: this.simulatedStudentOnboardingLink, // The link to be sent
      sendInviteEmail: true
    };

    try {
      const response = await this.adminStudentService.initiateStudentEnrollment(payload);
      if (response.success) {
        alert(response.message || `Student ${this.studentData.fullName} enrolled and invitation email (simulated) sent!`);
        this.router.navigate(['/admin/students']);
      } else {
        alert(`Enrollment failed: ${response.message || 'Unknown server error.'}`);
      }
    } catch (error: any) {
      alert(`Error: ${error.message || 'An unknown error occurred during enrollment.'}`);
    } finally {
      this.isLoading = false;
    }
  }

  async onEnrollNoMail(): Promise<void> { // Renamed from "Mark for Review" to be more student-centric
    if (!this.studentData || this.isLoading) return;
    this.isLoading = true;
    console.log(`Processing "Enroll (No Mail)" for ${this.studentData.fullName}`);

    const payload: StudentEnrollmentInitiationPayload = {
      studentInfo: this.studentData,
      onboardingLink: this.simulatedStudentOnboardingLink, // Still generate for backend record if needed
      sendInviteEmail: false
    };

    try {
      const response = await this.adminStudentService.initiateStudentEnrollment(payload);
      if (response.success) {
        alert(response.message || `Student ${this.studentData.fullName} enrolled successfully (no email sent).`);
        this.router.navigate(['/admin/students']);
      } else {
        alert(`Enrollment failed: ${response.message || 'Unknown server error.'}`);
      }
    } catch (error: any) {
      alert(`Error: ${error.message || 'An unknown error occurred during enrollment.'}`);
    } finally {
      this.isLoading = false;
    }
  }
}