import { Component, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router'; // RouterModule for routerLink
import { switchMap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

import { AdminCourseService } from '../../services/admin-course.service';
// We'll use CourseDetailsFE for display, service will fetch CourseDetailsBackend then we map
import { CourseDetailsFE, CourseDetailsBackend, Subject as CourseSubject } from '../../models/course.model';

@Component({
  selector: 'app-course-detail-page',
  standalone: true,
  imports: [CommonModule, RouterModule, DatePipe], // DatePipe for formatting
  templateUrl: './course-detail-page.component.html',
  // styleUrls: ['./course-detail-page.component.css']
})
export class CourseDetailPageComponent implements OnInit {
  course: CourseDetailsFE | null = null;
  isLoading = true;
  errorMessage: string | null = null;
  courseId: string | null = null;

  // Placeholder for enrolled students count/list - fetched separately later
  enrolledStudentsCount: number = 0; // Example
  // Placeholder for other course related stats - fetched separately later

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private adminCourseService: AdminCourseService
  ) {}

  ngOnInit(): void {
    this.route.paramMap.pipe(
      switchMap(params => {
        this.courseId = params.get('courseId');
        if (this.courseId) {
          this.isLoading = true;
          this.errorMessage = null;
          // In a real app, getCourseById would fetch and decrypt ONE course
          return from(this.adminCourseService.getCourseById(this.courseId)); // We need to add getCourseById
        }
        return of(null); // Or throw an error / navigate away if no ID
      })
    ).subscribe({
      next: (courseFromBackend) => {
        if (courseFromBackend) {
          this.course = this.mapBackendToFE(courseFromBackend);
          // Fetch enrolled students count separately
          this.loadCourseStats(this.courseId!);
        } else if(this.courseId) { // If courseId was present but service returned null
          this.errorMessage = 'Course not found.';
        }
        this.isLoading = false;
      },
      error: (err) => {
        this.errorMessage = err.message || 'Failed to load course details.';
        console.error("Error loading course details:", err);
        this.isLoading = false;
      }
    });
  }

   navigateToEdit(): void {
    if (this.courseId) {
      console.log('Navigate to edit course with ID:', this.courseId);
      this.router.navigate(['/admin/courses', this.courseId, 'edit']);
    } else {
      console.error('Cannot navigate to edit, courseId is missing.');
    }
  }
  
  // Mapping function (similar to the list page, but for a single object)
  private mapBackendToFE(cBackend: CourseDetailsBackend): CourseDetailsFE {
    let subjectDisplayNames = 'N/A';
    if (cBackend.CourseSubjects && Array.isArray(cBackend.CourseSubjects) && cBackend.CourseSubjects.length > 0) {
      subjectDisplayNames = cBackend.CourseSubjects.map(subject => {
        if (typeof subject === 'string') return subject; // Assuming IDs/names
        if (typeof subject === 'object' && subject !== null) return (subject as any).name || (subject as any).SubjectName || 'Unknown';
        return 'Invalid';
      }).join(', ');
    } else if (cBackend.CourseSubjects && cBackend.CourseSubjects.length === 0) {
        subjectDisplayNames = 'None';
    }

    return {
      _id: cBackend._id,
      name: cBackend.CourseName || 'Unnamed Course',
      description: cBackend.CourseDescription || 'No description available.',
      subjectsDisplay: subjectDisplayNames,
      isPublished: typeof cBackend.is_published === 'boolean' ? cBackend.is_published : false,
      createdAt: cBackend.created_at ? new Date(cBackend.created_at) : new Date(0),
      // Map other fields from CourseDetailsBackend to CourseDetailsFE as needed for display
      // For example, if you add CourseLevel, CourseDuration, CourseInstructor to CourseDetailsFE:
      // courseLevel: cBackend.CourseLevel || 'N/A',
      // courseDuration: cBackend.CourseDuration || 0, // Assuming number
      // instructorNames: cBackend.CourseInstructor?.join(', ') || 'N/A', // If CourseInstructor is string[]
      // isActive: cBackend.is_active // From your backend model (add to FE if needed)
    };
  }

  // Placeholder for fetching additional stats
  loadCourseStats(courseId: string): void {
    console.log("Fetching stats for course ID:", courseId);
    // Simulate fetching stats
    setTimeout(() => {
      this.enrolledStudentsCount = Math.floor(Math.random() * 100); // Random count for now
    }, 500);
  }

   navigateToEditSubjects(): void {
    if (this.courseId) {
      console.log('Navigate to edit subjects for course ID:', this.courseId);
      // Later, you would navigate to a specific route for editing subjects, e.g.:
      // this.router.navigate(['/admin/courses', this.courseId, 'edit-subjects']);
      alert('Edit Subjects functionality not yet implemented.');
    } else {
      console.error('Cannot navigate to edit subjects, courseId is missing.');
    }
  }

  goBack(): void {
    this.router.navigate(['/admin/courses']);
  }
}

// Need to import 'from' from 'rxjs' for from(this.adminCourseService.getCourseById(this.courseId))
import { from } from 'rxjs';