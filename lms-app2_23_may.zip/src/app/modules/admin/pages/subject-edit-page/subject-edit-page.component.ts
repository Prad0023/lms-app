import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormArray } from '@angular/forms';
import {
  Subject as RxJsSubject, // Alias to avoid conflict
  Subscription,
  debounceTime,
  distinctUntilChanged,
  switchMap,
  map, // <<< IMPORT map operator
  filter, // filter operator not directly used here but often useful
  tap,
  catchError,
  startWith,
  of,
  from // <<< IMPORT from operator
} from 'rxjs';
import { AdminSubjectService } from '../../services/admin-subject.service';
import { SubjectDetailsBackend, SubjectUpdatePayload } from '../../models/subject.model';
import { MinimalCourseInfo } from '../../models/course.model';

@Component({
  selector: 'app-subject-edit-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './subject-edit-page.component.html',
  // styleUrls: ['./subject-edit-page.component.css']
})
export class SubjectEditPageComponent implements OnInit, OnDestroy {
  subjectId: string | null = null;
  subjectForm: FormGroup;
  currentSubject: SubjectDetailsBackend | null = null;
  isLoading = false;
  isFetchingDetails = true;
  errorMessage: string | null = null;

  // For searchable course combobox
  courseSearchTerm$ = new RxJsSubject<string | null>(); // Allow null to fetch all initially
  availableCoursesForSearch: MinimalCourseInfo[] = [];
  selectedCourses: MinimalCourseInfo[] = []; // To display chips of selected courses
  showCourseDropdown = false;
  isLoadingCourses = false;

  private subscriptions = new Subscription();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    private adminSubjectService: AdminSubjectService
  ) {
    this.subjectForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required],
      assignedCourseIds: this.fb.array([]) // Will hold IDs of selected courses
    });
  }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('subjectId');
    if (id) {
      this.subjectId = id;
      this.loadSubjectDetails();
    } else {
      this.errorMessage = "Subject ID not found.";
      this.isFetchingDetails = false;
    }

    this.subscriptions.add(
      this.courseSearchTerm$.pipe(
        startWith(null),
        debounceTime(300),
        distinctUntilChanged(),
        tap(() => this.isLoadingCourses = true),
        switchMap((term: string | null) => // Term can be null from startWith
          from(this.adminSubjectService.getCoursesForSelection()).pipe( // <<< CONVERT PROMISE TO OBSERVABLE
            map((courses: MinimalCourseInfo[]) => { // Now courses is correctly typed
              if (term) {
                return courses.filter(c => c.name.toLowerCase().includes(term.toLowerCase()));
              }
              return courses; // Return all courses if term is null or empty
            }),
            catchError((err) => {
              console.error('Error fetching courses for dropdown:', err);
              return of([]); // Return an Observable of an empty array
            })
          )
        ),
        tap(() => this.isLoadingCourses = false)
      ).subscribe((courses: MinimalCourseInfo[]) => { // subjects (now courses) should be MinimalCourseInfo[]
        this.availableCoursesForSearch = courses.filter(
          (ac: MinimalCourseInfo) => !this.selectedCourses.find(sc => sc._id === ac._id)
        );
        // You might want to show dropdown if there are results or input has focus
        const courseSearchInputEl = document.getElementById('courseSearchEditInput') as HTMLInputElement;
        if (this.availableCoursesForSearch.length > 0 || (courseSearchInputEl && courseSearchInputEl.value)) {
          this.showCourseDropdown = true;
        } else {
          this.showCourseDropdown = false;
        }
      })
    );
  }

 // In src/app/modules/admin/pages/subject-edit-page/subject-edit-page.component.ts
  async loadSubjectDetails(): Promise<void> {
    if (!this.subjectId) return;
    this.isFetchingDetails = true;
    try {
      // Fetch all available courses first to map IDs to names later
      const allCoursesForLookup = await this.adminSubjectService.getCoursesForSelection();

      const subject = await this.adminSubjectService.getSubjectById(this.subjectId);
      if (subject) {
        this.currentSubject = subject;
        this.subjectForm.patchValue({
          name: subject.SubjectName,
          description: subject.SubjectDescription,
        });

        this.selectedCourses = []; // Clear first
        this.assignedCourseIdsFormArray.clear();

        if (subject.Courses && Array.isArray(subject.Courses)) {
          (subject.Courses as string[]).forEach(courseId => { // Assume subject.Courses is string[]
            const foundCourse = allCoursesForLookup.find(c => c._id === courseId);
            if (foundCourse) {
              this.selectedCourses.push(foundCourse); // Add MinimalCourseInfo
              this.assignedCourseIdsFormArray.push(this.fb.control(courseId)); // Add ID to form
            } else {
              // Handle case where a course ID is associated but not found in allCoursesForLookup
              // Maybe add a placeholder or log a warning
              this.assignedCourseIdsFormArray.push(this.fb.control(courseId));
              this.selectedCourses.push({_id: courseId, name: `Course ID: ${courseId} (Name not found)`});
            }
          });
        }
        // Trigger an initial population of availableCoursesForSearch after selectedCourses is set
        this.courseSearchTerm$.next((document.getElementById('courseSearchEditInput') as HTMLInputElement)?.value || null);

      } else {
        this.errorMessage = "Subject not found.";
      }
    } catch (error: any) {
      this.errorMessage = error.message || "Failed to load subject details.";
    } finally {
      this.isFetchingDetails = false;
    }
  }


  get f() { return this.subjectForm.controls; }
  get assignedCourseIdsFormArray() { return this.subjectForm.get('assignedCourseIds') as FormArray; }


  onCourseSearch(event: Event): void {
    const searchTerm = (event.target as HTMLInputElement).value;
    this.courseSearchTerm$.next(searchTerm);
    if (!searchTerm) {
      this.showCourseDropdown = false;
      // this.availableCoursesForSearch = []; // Don't clear if you want to show all on empty search
    } else {
      this.showCourseDropdown = true;
    }
  }

  selectCourse(course: MinimalCourseInfo, searchInput: HTMLInputElement): void {
    if (!this.selectedCourses.find(c => c._id === course._id)) {
      this.selectedCourses.push(course);
      this.assignedCourseIdsFormArray.push(this.fb.control(course._id));
      // Remove from available list for search to prevent re-selection
      this.availableCoursesForSearch = this.availableCoursesForSearch.filter(ac => ac._id !== course._id);
    }
    searchInput.value = ''; // Clear search
    this.showCourseDropdown = false; // Hide dropdown
    this.courseSearchTerm$.next(null); // Refresh available list without the selected one
  }

  removeSelectedCourse(courseToRemove: MinimalCourseInfo): void {
    this.selectedCourses = this.selectedCourses.filter(c => c._id !== courseToRemove._id);
    const index = this.assignedCourseIdsFormArray.controls.findIndex(control => control.value === courseToRemove._id);
    if (index > -1) {
      this.assignedCourseIdsFormArray.removeAt(index);
    }
    // Add back to available if it's not there and matches current search (optional complex logic)
    // For simplicity, just trigger a refresh of available courses
    this.courseSearchTerm$.next((document.getElementById('courseSearchEditInput') as HTMLInputElement)?.value || null);
  }

  async onSubmit(): Promise<void> {
    if (this.subjectForm.invalid || !this.subjectId) {
      this.subjectForm.markAllAsTouched();
      return;
    }
    this.isLoading = true;
    this.errorMessage = null;

    const formValue = this.subjectForm.value;
    const updatePayload: SubjectUpdatePayload = {
      name: formValue.name,
      description: formValue.description,
      assignedCourseIds: formValue.assignedCourseIds // This is an array of selected course IDs
    };

    try {
      const response = await this.adminSubjectService.updateSubject(this.subjectId, updatePayload);
      if (response.success) {
        alert(response.message || 'Subject updated successfully!');
        this.router.navigate(['/admin/subjects']); // Or back to subject detail
      } else {
        this.errorMessage = response.message || 'Failed to update subject.';
      }
    } catch (error: any) {
      this.errorMessage = error.message || 'An error occurred while updating the subject.';
    } finally {
      this.isLoading = false;
    }
  }

  onSearchFocus(): void { this.showCourseDropdown = true; }
  onSearchBlur(): void { setTimeout(() => { this.showCourseDropdown = false; }, 200); }


  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }
}