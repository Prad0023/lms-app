// Basic subject structure (could be more complex if subjects have IDs from backend)
export interface Subject {
  id: string; // Or number, depending on backend
  name: string;
}

// For the "Add Course" form
export interface CourseBasicInfo {
  name: string;
  description: string;
  subjectIds?: string[]; // Array of selected subject IDs (or just names if IDs not used yet)
}

// For the data coming from the backend AFTER decryption
export interface CourseDetailsBackend {
  _id: string;
  CourseName: string;          // <<< ADD THIS (Matches your decrypted log)
  CourseDescription: string;   // <<< ADD THIS (Matches your decrypted log)
  Credits?: number;             // From your decrypted log
  CoursePrerequisites?: string[];// From your decrypted log (List<ObjectId> -> string[])
  CourseInstructor?: string[];  // From your decrypted log (List<ObjectId> -> string[])
  CourseSubjects?: string[] | { id: string, name: string }[]; // <<< ADD THIS (Matches your decrypted log as '[]')
                               // Choose one format based on actual backend output or mock data.
                               // If backend sends ObjectIds, string[] is more likely.
                               // If it sends rich subject objects, {id,name}[]
                               // Your log showed CourseSubjects: [], so string[] is a safe bet for IDs, or [] if its just a list of names.
                               // Let's assume for now it's just an array of strings (subject IDs or names)
                               // If it's Subject objects, the map in component needs to handle that.
  is_published?: boolean;       // From your decrypted log (is_published:false)
  created_at: string;          // Assuming this exists from log context
  updated_at: string;          // Assuming this exists
  // Add any other fields from your actual decrypted JSON log
  CourseLevel?: string;
  CourseType?: string;
  CourseDuration?: number;
  CourseStartDate?: string;
  CourseEndDate?: string;
  CourseMaterials?: any; // object
  CourseSchedule?: any[]; // List<Object>
  
  // Ensure all fields that the .map() function in your component TRIES to access from
  // 'cBackend' are actually defined here, even if optional.
  // Based on current mapping: CourseName, CourseDescription, CourseSubjects, is_published, created_at are used.
}

// For the frontend view model (what the component's 'courses' array will hold)
export interface CourseDetailsFE {
  _id: string;
  name: string;
  description: string;
  subjectsDisplay: string; // Comma-separated string of subject names for display
  // isPublished: boolean;
  createdAt: Date;
  isPublished: boolean;
  // other relevant fields for the list view
}

// Re-use generic EncryptedListPayload and FetchApiResponse
// For example, from teacher.model.ts or create generic versions
// For clarity, let's define a specific one for courses for now
export interface EncryptedListPayload { // Copied for clarity, can be shared
  responseAesKeyB64: string;
  encryptedData: string;
}

export interface FetchCoursesApiResponse {
  success: boolean;
  statusCode: number;
  data?: EncryptedListPayload;
  message: string;
}

// For sending encrypted course data
export interface EncryptedCourseRequest {
  encryptedAesKeyB64: string;
  encryptedPayloadB64: string;
}

// For the backend response when adding/updating a course
export interface CourseMutationResponse {
  success: boolean;
  message: string;
  data?: CourseDetailsBackend; // Return the created/updated course
  statusCode?: number;
}

export interface MinimalCourseInfo {
  _id: string;
  name: string; // Or CourseName, depending on what your /view-courses returns before mapping
}