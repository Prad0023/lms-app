import { CourseBasicInfo, MinimalCourseInfo } from "./course.model"; // Assuming Course model exists

// For listing subjects (simplified for now)
export interface SubjectListItem {
  _id: string;
  name: string;
  description: string;
  courseCount?: number; // How many courses this subject is part of
}

// For the "Add Subject" form
export interface SubjectBasicInfo {
  name: string;
  description: string;
  assignedCourseIds?: string[]; // Array of Course IDs this subject should be linked to
}

// For data coming from backend for a single subject (if needed for a detail view later)
export interface SubjectDetailsBackend {
  _id: string;
  SubjectName: string;         // Matches your DB structure
  SubjectDescription: string;  // Matches your DB structure
  SubjectCredits?: number;      // From your DB structure
  // ... other fields from your "Subjects" DB structure
  Courses?: MinimalCourseInfo[] | string[]; // Array of associated course objects (with minimal info like ID and name) or just IDs
  created_at: string;
  updated_at: string;
}


export interface SubjectUpdatePayload {
  name: string;              // Mapped from SubjectName
  description: string;       // Mapped from SubjectDescription
  assignedCourseIds: string[]; // Updated list of associated course IDs
  // Include other editable fields of a subject as needed
}
// For frontend view model of a single subject (if different from backend)
export interface SubjectDetailsFE {
  _id: string;
  name: string;
  description: string;
  credits?: number;
  associatedCoursesDisplay?: string; // Comma-separated list of course names
  createdAt: Date;
  // ... other relevant fields for detail view
}


// ---- Re-using/defining encryption and API response structures ----
// These can be generic if the pattern is the same across entities

export interface EncryptedListPayload {
  responseAesKeyB64: string;
  encryptedData: string;
}

export interface FetchSubjectsApiResponse { // Specific to fetching subjects
  success: boolean;
  statusCode: number;
  data?: EncryptedListPayload; // Where encryptedData contains SubjectDetailsBackend[]
  message: string;
}

export interface EncryptedSubjectRequest { // For sending encrypted subject data (e.g., for add/update)
  encryptedAesKeyB64: string;
  encryptedPayloadB64: string;
}

export interface SubjectMutationResponse { // For backend response when adding/updating a subject
  success: boolean;
  message: string;
  data?: SubjectDetailsBackend; // Return the created/updated subject
  statusCode?: number;
}