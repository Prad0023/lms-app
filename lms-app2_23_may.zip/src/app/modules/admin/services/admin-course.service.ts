import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { firstValueFrom, Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { environment } from '../../../../environments/environments';
import { EncryptionService } from '../../../core/services/encryption.service';
import { AuthService } from '../../../core/services/auth.service';
import {
  CourseBasicInfo, // This is the payload before encryption for addCourse
  CourseDetailsBackend,
  FetchCoursesApiResponse,
  Subject as CourseSubject, // Renamed to avoid conflict if needed elsewhere
  EncryptedCourseRequest, // The structure for the encrypted POST body
  CourseMutationResponse  // The expected response after adding/updating
} from '../models/course.model';

@Injectable({
  providedIn: 'root'
})
export class AdminCourseService {
  private baseApiUrl = `${environment.apiUrl}/admin/courses`; // Correct base URL

  constructor(
    private http: HttpClient,
    private encryptionService: EncryptionService,
    private authService: AuthService
  ) {}

  // --- Add New Course ---
  async addCourse(coursePayloadToEncrypt: CourseBasicInfo): Promise<CourseMutationResponse> {
    const addCourseEndpoint = `${this.baseApiUrl}/create`; // Endpoint: POST /api/v1/admin/courses/create
    console.log(`AdminCourseService: Adding new course via ${addCourseEndpoint}`, coursePayloadToEncrypt);

    try {
      // 1. Get RSA Public Key
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();

      // 2. Generate a new AES Key
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);

      // 3. RSA Encrypt the Base64 string of the AES Key
      const rsaEncryptedAesKeyBase64 = await this.encryptionService.encryptAesKeyBase64WithRsa(
        aesKeyBase64ForRsa,
        rsaPublicKeyCryptoKey
      );

      // 4. AES-GCM Encrypt the actual coursePayloadToEncrypt (which is CourseBasicInfo)
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(
        coursePayloadToEncrypt, // The CourseBasicInfo object
        aesCryptoKey
      );

      // 5. Prepare the final encrypted request payload
      const encryptedRequest: EncryptedCourseRequest = {
        encryptedAesKeyB64: rsaEncryptedAesKeyBase64,
        encryptedPayloadB64: aesEncryptedPayloadB64
      };

      const adminToken = this.authService.token;
      if (!adminToken) {
        throw new Error("Admin authentication token not found. Please log in again.");
      }
      const headers = {
        'Authorization': `Bearer ${adminToken}`,
        'Content-Type': 'application/json'
      };

      console.log("AdminCourseService: Sending encrypted 'add course' request:", JSON.stringify(encryptedRequest).substring(0,150) + "...");

      // 6. Make the ACTUAL HTTP POST request
      return await firstValueFrom(
        this.http.post<CourseMutationResponse>(addCourseEndpoint, encryptedRequest, { headers })
          .pipe(
            tap(res => console.log("AdminCourseService: Response from add course API:", res)),
            catchError(this.handleHttpError) // Use your common error handler
          )
      );
    } catch (error) { // Catches errors from encryption or if token not found or other client-side issues
      console.error("Error in AdminCourseService.addCourse (client-side or during encryption):", error);
      const err = error as Error; // Type assertion
      // Ensure a consistent error object structure is rejected for the component to handle
      return Promise.reject({
        success: false,
        message: err.message || 'Failed to add course due to a client-side processing error.',
        statusCode: 0 // Or another appropriate status for client-side failure
      } as CourseMutationResponse);
    }
  }

  // ... (getSubjects, getCourses, simulateFetchCoursesApi, getMockCoursesData, handleHttpError methods from previous response)
  // Ensure getAuthHeaders is available if not inlining token logic
  

   // --- Fetch All Courses - MODIFIED TO USE REAL API ---
  async getCourses(filters?: { searchTerm?: string }): Promise<CourseDetailsBackend[]> {
    const viewCoursesEndpoint = `${this.baseApiUrl}/view-courses`; // Correct endpoint
    console.log(`AdminCourseService: Fetching courses from ${viewCoursesEndpoint} with filters:`, filters);

    let httpParams = new HttpParams();
    if (filters?.searchTerm) {
      httpParams = httpParams.set('search', filters.searchTerm);
    }
    // Add other filters like subjectId, isPublished as needed, e.g.:
    // if (filters?.subjectId) httpParams = httpParams.set('subject', filters.subjectId);
    // if (typeof filters?.isPublished === 'boolean') httpParams = httpParams.set('published', filters.isPublished.toString());

    try {
      const headers = this.getAuthHeaders(); // Get headers with token

      // --- REPLACE SIMULATION WITH ACTUAL API CALL ---
      console.log("AdminCourseService: Making ACTUAL API call to /view-courses");
      const apiResponse = await firstValueFrom(
        this.http.get<FetchCoursesApiResponse>(viewCoursesEndpoint, { params: httpParams, headers: headers })
          .pipe(
            tap(res => console.log("AdminCourseService: Raw response from /view-courses API:", res)),
            catchError(this.handleHttpError) // Use the centralized error handler
          )
      );
      // --- END OF ACTUAL API CALL BLOCK ---

      // const apiResponse: FetchCoursesApiResponse = await this.simulateFetchCoursesApi(filters); // KEEP THIS COMMENTED OUT or REMOVE

      console.log("AdminCourseService: Received API response (after firstValueFrom):", apiResponse);

      if (apiResponse && apiResponse.success && apiResponse.data) {
        const { responseAesKeyB64, encryptedData } = apiResponse.data;
        if (!responseAesKeyB64 || !encryptedData) {
            console.error("AdminCourseService: Missing responseAesKeyB64 or encryptedData from backend.");
            throw new Error("Invalid encrypted data structure received from server.");
        }
        console.log("AdminCourseService: Attempting to decrypt course list with AES key:", responseAesKeyB64.substring(0,10)+"...");
        const decryptedJsonString = await this.encryptionService.decryptAesGcmPayload(
          encryptedData,
          responseAesKeyB64
        );
        console.log("AdminCourseService: Decrypted JSON string for courses:", decryptedJsonString.substring(0, 200) + "...");
        const coursesFromBackend: CourseDetailsBackend[] = JSON.parse(decryptedJsonString);
        // console.log(`AdminCourseService: Successfully decrypted ${coursesFromBackend.length} courses.`);
        return coursesFromBackend;
      } else {
        // Handle cases where apiResponse might be falsy, or success is false, or data is missing
        const errorMessage = apiResponse?.message || "Failed to fetch courses: Server indicated failure or no data.";
        console.error("AdminCourseService: Fetch courses failed -", errorMessage, "API Response:", apiResponse);
        throw new Error(errorMessage);
      }
    } catch (error: any) { // Catches errors from HTTP call, decryption, or missing token
      console.error("AdminCourseService: Error in getCourses method:", error);
      let detailedMessage = "Could not fetch or process course data.";
      if (error instanceof HttpErrorResponse) {
          detailedMessage = (error.error as any)?.message || error.message || `Server error ${error.status}`;
      } else if (error.message) {
          detailedMessage = error.message;
      }
      // This error will propagate to the component
      throw new Error(detailedMessage);
    }
  }

  private getAuthHeaders() {
    const token = this.authService.token;
    if (!token) {
      console.error("AdminCourseService: Admin token not found. Cannot make authenticated API call.");
      // Throw an error to prevent the API call from being made without a token
      throw new Error("Authentication token is missing. Please log in again.");
    }
    return {
      'Authorization': `Bearer ${token}`,
      // 'Content-Type': 'application/json' // Not usually needed for GET requests but doesn't hurt
    };
  }

  async getSubjects(searchTerm?: string): Promise<CourseSubject[]> {
    // This is still mocked. Replace with a real API call when backend endpoint for subjects is ready.
    console.log("AdminCourseService: Fetching subjects (mocked), search term:", searchTerm);
    await new Promise(resolve => setTimeout(resolve, 300));
    let allSubjects: CourseSubject[] = [
      { id: 'subj_math', name: 'Mathematics' }, { id: 'subj_physics', name: 'Physics' },
      { id: 'subj_chem', name: 'Chemistry' }, { id: 'subj_bio', name: 'Biology' },
      { id: 'subj_hist', name: 'History' }, { id: 'subj_eng', name: 'English Literature' },
      { id: 'subj_cs', name: 'Computer Science' }, { id: 'subj_art', name: 'Art & Design' },
    ];
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      allSubjects = allSubjects.filter(s => s.name.toLowerCase().includes(term));
    }
    return allSubjects.slice(0, 5);
  }

  private handleHttpError(error: HttpErrorResponse): Observable<never> {
    console.error('AdminCourseService HTTP Error:', error.status, error.message, error.error);
    let userMessage = 'An unexpected error occurred with the course service.';

    // Try to get a more specific message from the backend error response
    if (error.error && typeof error.error === 'object' && error.error.message) {
      userMessage = error.error.message;
    } else if (typeof error.error === 'string' && error.error.length > 0 && error.error.length < 300) { // Check if error.error is a simple string
        userMessage = error.error;
    } else if (error.message) {
      userMessage = `Error ${error.status}: ${error.statusText}`;
    }

    // Return an observable error that includes a success: false and the message,
    // similar to the FetchCoursesApiResponse structure for consistency in error handling.
    return throwError(() => ({
        success: false,
        message: userMessage,
        statusCode: error.status,
        errorDetail: error.error // Keep the original error object for deeper inspection if needed
    }));
  }

    async getCourseById(courseId: string): Promise<CourseDetailsBackend | null> {
    const courseDetailEndpoint = `${this.baseApiUrl}/view/${courseId}`; // Example endpoint: /api/v1/admin/courses/view/:courseId
    console.log(`AdminCourseService: Fetching course details for ID: ${courseId} from ${courseDetailEndpoint}`);

    try {
      const headers = this.getAuthHeaders();

      // SIMULATE API CALL for now
      // Replace with actual API call when backend is ready
      // const apiResponse = await firstValueFrom(
      //   this.http.get<FetchCourseDetailApiResponse>(courseDetailEndpoint, { headers }) // Need a FetchCourseDetailApiResponse
      //     .pipe(catchError(this.handleHttpError))
      // );
      const apiResponse: any = await this.simulateFetchCourseByIdApi(courseId); // Simulate


      console.log("AdminCourseService: Received API response for single course:", apiResponse);

      if (apiResponse.success && apiResponse.data) {
        // Assuming the 'data' object for a single course is structured as:
        // { responseAesKeyB64: "...", encryptedData: "..." }
        // And encryptedData decrypts directly to a CourseDetailsBackend object (not an array)
        const { responseAesKeyB64, encryptedData } = apiResponse.data;
         if (!responseAesKeyB64 || !encryptedData) {
            console.error("AdminCourseService: Missing responseAesKeyB64 or encryptedData for single course.");
            throw new Error("Invalid encrypted data structure received for single course.");
        }
        console.log("AdminCourseService: Attempting to decrypt single course with AES key:", responseAesKeyB64.substring(0,10)+"...");
        const decryptedJsonString = await this.encryptionService.decryptAesGcmPayload(
          encryptedData,
          responseAesKeyB64
        );
        console.log("AdminCourseService: Decrypted JSON string for single course:", decryptedJsonString.substring(0,200)+"...");
        const courseFromBackend: CourseDetailsBackend = JSON.parse(decryptedJsonString);
        console.log("AdminCourseService: Successfully decrypted single course:", courseFromBackend);
        return courseFromBackend;
      } else if (apiResponse.statusCode === 404) {
          return null; // Course not found
      } else {
        throw new Error(apiResponse.message || "Failed to fetch course details.");
      }
    } catch (error: any) {
      console.error(`AdminCourseService: Error in getCourseById for ID ${courseId}:`, error);
      // Let the component handle displaying a general error message
      if (error.statusCode === 404 || error.message?.toLowerCase().includes('not found')) return null;
      throw new Error( (error instanceof HttpErrorResponse && error.error?.message) || error.message || "Could not fetch or decrypt course details." );
    }
  }

   private async simulateFetchCourseByIdApi(courseId: string): Promise<FetchCoursesApiResponse | {success: boolean, statusCode: number, message: string}> {
      console.log(`AdminCourseService: SIMULATING API call to /view/${courseId}`);
      await new Promise(resolve => setTimeout(resolve, 400));
      const mockCourses = this.getMockCoursesData({}); // Get all mock courses
      const foundCourse = mockCourses.find(c => c._id === courseId);

      if (!foundCourse) {
          return { success: false, statusCode: 404, message: `Simulated: Course with ID ${courseId} not found.` };
      }

      // Simulate server-side encryption of this single course
      const tempAesKey = await this.encryptionService.generateAesGcmKey();
      const responseAesKeyB64 = await this.encryptionService.exportRawAesKeyAsBase64(tempAesKey);
      const encryptedData = await this.encryptionService.encryptLoginPayloadAesGcm(foundCourse, tempAesKey);

      return {
          success: true,
          statusCode: 200,
          data: {
              responseAesKeyB64: responseAesKeyB64,
              encryptedData: encryptedData // Encrypted single CourseDetailsBackend object
          },
          message: "Course details retrieved and encrypted (simulated)."
      };
  }
    



  private async simulateFetchCoursesApi(filters?: { searchTerm?: string }): Promise<FetchCoursesApiResponse> {
    console.log("AdminCourseService: SIMULATING API call to /view-courses with filters:", filters);
    await new Promise(resolve => setTimeout(resolve, 500));
    const mockRawCoursesList: CourseDetailsBackend[] = this.getMockCoursesData(filters);
    const tempAesKey = await this.encryptionService.generateAesGcmKey();
    const responseAesKeyB64 = await this.encryptionService.exportRawAesKeyAsBase64(tempAesKey);
    const encryptedData = await this.encryptionService.encryptLoginPayloadAesGcm(mockRawCoursesList, tempAesKey);
    return { success: true, statusCode: 200, data: { responseAesKeyB64, encryptedData }, message: "Simulated fetch success."};
  }
  private getMockCoursesData(filters?: { searchTerm?: string }): CourseDetailsBackend[] {
    let courses: CourseDetailsBackend[] = [
    
    {
        _id: 'c001',
        CourseName: 'Introduction to Algebra', // Matches interface
        CourseDescription: 'Learn the fundamentals of algebra.', // Matches interface
        CourseSubjects: [{id: 'subj_math', name: 'Mathematics'}], // Example: array of subject objects
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        is_published: true,
        // Add other required fields from CourseDetailsBackend like email_verified (if they are NOT optional)
        // For now, if CourseDetailsBackend has these as optional, it's fine.
        Credits: 3, CoursePrerequisites: [], CourseInstructor: [],
      },
      {
        _id: 'c002',
        CourseName: 'Classical Mechanics',
        CourseDescription: 'Explore Newton\'s laws and beyond.',
        CourseSubjects: [{id: 'subj_physics', name: 'Physics'}], // If your mapping handles this
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        is_published: false,
        Credits: 4, CoursePrerequisites: [], CourseInstructor: [],
      },
      // Your example decrypted object:
      {
        _id:"682eeb77718d50f7493b2b89",
        CourseName:"Introduction to DSa",
        CourseDescription:"dcjbsdkcjbk",
        Credits:0, // From log
        CoursePrerequisites:[], // From log
        CourseInstructor:[], // From log
        CourseSubjects:[], // From log
        is_published:false, // From log (make sure type matches CourseDetailsBackend)
        created_at: "2025-05-19T10:49:24.280Z", // Example
        updated_at: "2025-05-19T10:49:24.280Z", // Example
      }
    ];
    if (filters?.searchTerm) { /* filter logic */ }
    return courses;
  }


  

  
}