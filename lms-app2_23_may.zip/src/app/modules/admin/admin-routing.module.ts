import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AdminDashboardPageComponent } from './pages/admin-dashboard-page/admin-dashboard-page.component';
// Import new page components once created
import { TeacherManagementPageComponent } from './pages/teacher-management-page/teacher-management-page.component';
// import { StudentManagementPageComponent } from './pages/student-management-page/student-management-page.component';
import { BatchManagementPageComponent } from './pages/batch-management-page/batch-management-page.component';
import { CourseManagementPageComponent } from './pages/course-management-page/course-management-page.component';
import { AdminSettingsPageComponent } from './pages/admin-settings-page/admin-settings-page.component';
import { TeacherMailPreviewPageComponent } from './pages/teacher-mail-preview-page/teacher-mail-preview-page.component';
import { StudentManagementPageComponent } from './pages/student-management-page/student-management-page.component'; // If using component directly
import { StudentMailPreviewPageComponent } from './pages/student-mail-preview-page/student-mail-preview-page.component'; // Import new page
import { CourseDetailPageComponent } from './pages/course-detail-page/course-detail-page.component'; // <<< Import




const routes: Routes = [
  {
    path: 'dashboard',
    component: AdminDashboardPageComponent
  },
  {
    path: 'teachers',
    // component: TeacherManagementPageComponent // We'll create this next
    loadComponent: () => import('./pages/teacher-management-page/teacher-management-page.component').then(m => m.TeacherManagementPageComponent)
  },
  { // New route for mail preview, as a child of 'teachers' or a sibling
    path: 'teachers/mail-preview', // Or just 'mail-preview' if you want /admin/mail-preview
    component: TeacherMailPreviewPageComponent
  },
  {
    path: 'students',
    // component: StudentManagementPageComponent // Or loadComponent as before
    loadComponent: () => import('./pages/student-management-page/student-management-page.component').then(m => m.StudentManagementPageComponent)
  },
  { // New route for student mail preview
    path: 'students/mail-preview',
    component: StudentMailPreviewPageComponent // Route to the new component
  },
  {
    path: 'batches',
    // component: BatchManagementPageComponent
    loadComponent: () => import('./pages/batch-management-page/batch-management-page.component').then(m => m.BatchManagementPageComponent)

  },
  {
    path: 'courses', // Path should already exist
    // component: CourseManagementPageComponent // or loadComponent as below
    loadComponent: () => import('./pages/course-management-page/course-management-page.component').then(m => m.CourseManagementPageComponent)
  },
   {
    path: 'courses/:courseId', // Route for viewing a single course's details
    // component: CourseDetailPageComponent // Or loadComponent
    loadComponent: () => import('./pages/course-detail-page/course-detail-page.component').then(m => m.CourseDetailPageComponent)

  },
  {
    path: 'courses/:courseId/edit', // Placeholder route for editing
    // loadComponent: () => import('./pages/course-edit-page/course-edit-page.component').then(m => m.CourseEditPageComponent)
    redirectTo: 'courses/:courseId', // For now, redirect back to detail or implement edit page
    pathMatch: 'full'
  },
  {
    path: 'settings',
    // component: AdminSettingsPageComponent
    loadComponent: () => import('./pages/admin-settings-page/admin-settings-page.component').then(m => m.AdminSettingsPageComponent)
  },
  {
    path: 'subjects',
    loadComponent: () => import('./pages/subject-management-page/subject-management-page.component').then(m => m.SubjectManagementPageComponent)
  },
  { // New route for editing a subject
    path: 'subjects/:subjectId/edit',
    // component: SubjectEditPageComponent // Or loadComponent
    loadComponent: () => import('./pages/subject-edit-page/subject-edit-page.component').then(m => m.SubjectEditPageComponent)
  },
  {
    path: '', // Default for /admin
    redirectTo: 'dashboard',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }