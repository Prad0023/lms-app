import { Component, EventEmitter, Output, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormArray } from '@angular/forms';
import { SubjectBasicInfo } from '../../models/subject.model';
import { MinimalCourseInfo } from '../../models/course.model'; // To display courses
import { AdminSubjectService } from '../../services/admin-subject.service'; // To fetch courses

@Component({
  selector: 'app-subject-add-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './subject-add-modal.component.html',
  // styleUrls: ['./subject-add-modal.component.css']
})
export class SubjectAddModalComponent implements OnInit {
  @Output() closeModal = new EventEmitter<void>();
  @Output() subjectAdded = new EventEmitter<SubjectBasicInfo>();

  addSubjectForm: FormGroup;
  isLoading = false;
  isLoadingCourses = false;
  availableCourses: MinimalCourseInfo[] = [];
  // No searchable dropdown for courses here, just a multi-select for simplicity
  // A searchable one could be added similar to CourseAddModal's subject search

  constructor(
    private fb: FormBuilder,
    private adminSubjectService: AdminSubjectService
  ) {
    this.addSubjectForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required],
      assignedCourseIds: this.fb.array([]) // For storing selected course IDs
    });
  }

  ngOnInit(): void {
    this.loadCoursesForSelection();
  }

  async loadCoursesForSelection(): Promise<void> {
    this.isLoadingCourses = true;
    try {
      this.availableCourses = await this.adminSubjectService.getCoursesForSelection();
    } catch (error) {
      console.error("Error loading courses for selection:", error);
      // Handle error, maybe show a message to user
    } finally {
      this.isLoadingCourses = false;
    }
  }

  get f() { return this.addSubjectForm.controls; }
  get assignedCourseIdsArray() { return this.addSubjectForm.get('assignedCourseIds') as FormArray; }

  onCourseSelectionChange(event: Event): void {
    const selectedOptions = (event.target as HTMLSelectElement).selectedOptions;
    this.assignedCourseIdsArray.clear(); // Clear existing
    for (let i = 0; i < selectedOptions.length; i++) {
      this.assignedCourseIdsArray.push(this.fb.control(selectedOptions[i].value));
    }
  }
  
  getCourseNameById(courseId: string): string {
    const course = this.availableCourses.find(c => c._id === courseId);
    return course ? course.name : 'Unknown Course';
  }

  onSubmit(): void {
    if (this.addSubjectForm.invalid) {
      this.addSubjectForm.markAllAsTouched();
      return;
    }
    this.isLoading = true;
    const formValue = this.addSubjectForm.value;
    const subjectPayload: SubjectBasicInfo = {
      name: formValue.name,
      description: formValue.description,
      assignedCourseIds: formValue.assignedCourseIds // Array of course IDs
    };

    console.log("SubjectAddModal: Submitting subject payload:", subjectPayload);
    this.adminSubjectService.addSubject(subjectPayload).then(response => {
      if (response.success) {
        this.subjectAdded.emit(subjectPayload);
        alert(response.message || 'Subject added successfully!');
        this.closeModal.emit();
      } else {
        alert(`Failed to add subject: ${response.message || 'Unknown error'}`);
      }
    }).catch(err => {
      alert(`Error adding subject: ${err.message || 'Please try again.'}`);
    }).finally(() => {
      this.isLoading = false;
    });
  }

  onCancel(): void {
    this.closeModal.emit();
  }
}