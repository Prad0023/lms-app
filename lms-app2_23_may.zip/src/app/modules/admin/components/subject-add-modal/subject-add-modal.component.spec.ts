import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubjectAddModalComponent } from './subject-add-modal.component';

describe('SubjectAddModalComponent', () => {
  let component: SubjectAddModalComponent;
  let fixture: ComponentFixture<SubjectAddModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SubjectAddModalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SubjectAddModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
