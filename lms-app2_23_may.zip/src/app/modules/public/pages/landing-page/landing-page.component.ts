// src/app/pages/landing-page/landing-page.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

// Import ALL the section components used in the template
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { HeroSectionComponent } from '../../components/hero-section/hero-section.component';
import { ProblemStatementSectionComponent } from '../../components/problem-statement-section/problem-statement-section.component';
import { FeaturesSectionComponent } from '../../components/features-section/features-section.component';
import { ProcessSectionComponent } from '../../components/process-section/process-section.component';
import { TechnologiesSectionComponent } from '../../components/technologies-section/technologies-section.component';
import { TestimonialsSectionComponent } from '../../components/testimonials-section/testimonials-section.component';
import { BlogsPreviewSectionComponent } from '../../components/blogs-preview-section/blogs-preview-section.component';
import { PageFooterComponent } from '../../components/page-footer/page-footer.component';

@Component({
  selector: 'app-landing-page',
  standalone: true,
  imports: [
    CommonModule,
    // Add ALL imported section components here
    NavbarComponent,
    HeroSectionComponent,
    ProblemStatementSectionComponent,
    FeaturesSectionComponent,
    ProcessSectionComponent,
    TechnologiesSectionComponent,
    TestimonialsSectionComponent,
    BlogsPreviewSectionComponent,
    PageFooterComponent
  ],
  templateUrl: './landing-page.component.html',
})
export class LandingPageComponent {
  // If you had other logic here, keep it
}