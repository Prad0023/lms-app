import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    RouterLinkActive
  ],
  templateUrl: './navbar.component.html',
  // styleUrls: ['./navbar.component.scss'] // If you have specific styles
})
export class NavbarComponent {
  // These were missing or incorrect:
  isMobileMenuOpen: boolean = false; // Initialize the property

  toggleMobileMenu(): void { // Define the method
    this.isMobileMenuOpen = !this.isMobileMenuOpen;
  }
}