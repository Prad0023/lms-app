import { Component } from '@angular/core';
import { CommonModule } from '@angular/common'; // For standalone
import { RouterLink } from '@angular/router'; // If you have router links in its template
import { LoginFormComponent } from '../../components/login-form/login-form.component'; // Import the form

@Component({
  selector: 'app-login-page',
  standalone: true, // Ensure it's standalone
  imports: [
    CommonModule,
    RouterLink, // If needed
    LoginFormComponent // Import the standalone form component it uses
  ],
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css'] // Optional
})
export class LoginPageComponent {
  // This page component now mainly hosts the login form.
  // Actual login logic is in LoginFormComponent and AuthService.
  constructor() {}
}