import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminRegistrationFormComponent } from '../../components/admin-registration-form/admin-registration-form.component';

@Component({
  selector: 'app-admin-register-page',
  standalone: true,
  imports: [
    CommonModule,
    AdminRegistrationFormComponent
  ],
  template: `
    <div class="min-h-screen flex items-center justify-center bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
      <div class="max-w-md w-full space-y-8">
        <div>
          <img class="mx-auto h-12 w-auto" src="https://tailwindui.com/img/logos/workflow-mark-indigo-600.svg" alt="Abhyasify Logo">
          <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">
            Register First Admin
          </h2>
        </div>
        <app-admin-registration-form></app-admin-registration-form>
      </div>
    </div>
  `,
  // styleUrls: ['./admin-register-page.component.css']
})
export class AdminRegisterPageComponent {}