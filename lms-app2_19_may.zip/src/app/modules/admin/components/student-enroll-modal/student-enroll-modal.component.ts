import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { StudentBasicEnrollInfo } from '../../models/student.model';

@Component({
  selector: 'app-student-enroll-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './student-enroll-modal.component.html',
  // styleUrls: ['./student-enroll-modal.component.css']
})
export class StudentEnrollModalComponent {
  @Output() closeModal = new EventEmitter<void>();
  @Output() studentEnrolled = new EventEmitter<StudentBasicEnrollInfo>();

  enrollForm: FormGroup;
  isLoading = false;

  constructor(private fb: FormBuilder) {
    this.enrollForm = this.fb.group({
      fullName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', [Validators.pattern(/^\+[1-9]\d{1,14}$/)]], // Optional, but validate if provided
    });
  }

  get f() { return this.enrollForm.controls; }

  onSubmit(): void {
    if (this.enrollForm.invalid) {
      this.enrollForm.markAllAsTouched();
      return;
    }
    this.isLoading = true;
    setTimeout(() => { // Simulate delay
      this.studentEnrolled.emit(this.enrollForm.value);
      this.isLoading = false;
    }, 1000);
  }

  onCancel(): void {
    this.closeModal.emit();
  }
}