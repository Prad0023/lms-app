import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';

// Import Standalone Page Components
import { AdminDashboardPageComponent } from './pages/admin-dashboard-page/admin-dashboard-page.component';
// Import other admin page/components as needed
import { TeacherHireModalComponent } from './components/teacher-hire-modal/teacher-hire-modal.component';
import { TeacherManagementPageComponent } from './pages/teacher-management-page/teacher-management-page.component';
import { ReactiveFormsModule } from '@angular/forms'; // For reactive forms in modals
import { TeacherMailPreviewPageComponent } from './pages/teacher-mail-preview-page/teacher-mail-preview-page.component';
import { StudentManagementPageComponent } from './pages/student-management-page/student-management-page.component';
import { StudentEnrollModalComponent } from './components/student-enroll-modal/student-enroll-modal.component';



@NgModule({
  declarations: [
    // Declare non-standalone components here
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    ReactiveFormsModule,
    // Import standalone components routed to by AdminRoutingModule
    AdminDashboardPageComponent, // Assuming it's standalone
    TeacherManagementPageComponent,
    TeacherHireModalComponent,   
    TeacherMailPreviewPageComponent, 
    StudentManagementPageComponent,
    StudentEnrollModalComponent 
  ]
})
export class AdminModule { }