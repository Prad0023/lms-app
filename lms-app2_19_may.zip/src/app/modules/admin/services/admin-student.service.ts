import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { firstValueFrom, Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { environment } from '../../../../environments/environments';
import { EncryptionService } from '../../../core/services/encryption.service';
import { AuthService } from '../../../core/services/auth.service';
import { StudentDetailsBackend, FetchStudentsApiResponse, StudentBasicEnrollInfo } from '../models/student.model';
import { EncryptedListPayload } from '../models/teacher.model'; // Re-using this structure for now

// Interfaces for enrollment initiation (similar to teacher onboarding)
export interface StudentEnrollmentInitiationPayload {
  studentInfo: StudentBasicEnrollInfo;
  onboardingLink?: string; // May or may not send a link initially
  sendInviteEmail: boolean;
  // Other relevant data for backend
}
export interface EncryptedStudentRequest { // Generic for sending encrypted student data
  encryptedAesKeyB64: string;
  encryptedPayloadB64: string;
}
export interface StudentEnrollmentResponse {
  success: boolean;
  message: string;
  data?: any; // e.g., student ID
}

@Injectable({
  providedIn: 'root'
})
export class AdminStudentService {
  private apiUrl = `${environment.apiUrl}/admin/students`; // Base URL for admin student actions

  constructor(
    private http: HttpClient,
    private encryptionService: EncryptionService,
    private authService: AuthService
  ) {}

  // Method to enroll/invite a student (Admin initiates)
  async initiateStudentEnrollment(payload: StudentEnrollmentInitiationPayload): Promise<StudentEnrollmentResponse> {
    const enrollEndpoint = `${this.apiUrl}/initiate-enrollment`; // Example endpoint

    try {
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      const rsaEncryptedAesKeyB64 = await this.encryptionService.encryptAesKeyBase64WithRsa(
        aesKeyBase64ForRsa,
        rsaPublicKeyCryptoKey
      );
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(
        payload,
        aesCryptoKey
      );
      const encryptedRequest: EncryptedStudentRequest = {
        encryptedAesKeyB64: rsaEncryptedAesKeyB64,
        encryptedPayloadB64: aesEncryptedPayloadB64
      };
      const adminToken = this.authService.token;
      if (!adminToken) throw new Error("Admin token not found.");
      const headers = { 'Authorization': `Bearer ${adminToken}` };

      // SIMULATE API CALL for now
      console.log("AdminStudentService: Simulating API call to initiate student enrollment:", encryptedRequest);
      await new Promise(resolve => setTimeout(resolve, 1000));
      return {
        success: true,
        message: payload.sendInviteEmail
          ? `Student enrollment initiated for ${payload.studentInfo.email} and invite (simulated) sent.`
          : `Student ${payload.studentInfo.fullName} registered, awaiting profile completion.`
      };
      // return firstValueFrom(
      //   this.http.post<StudentEnrollmentResponse>(enrollEndpoint, encryptedRequest, { headers })
      // );
    } catch (error) {
      console.error("Error in initiateStudentEnrollment service:", error);
      const httpError = error instanceof HttpErrorResponse ? error : null;
      return Promise.reject({
        success: false,
        message: httpError?.error?.message || (error as Error)?.message || 'Failed to initiate student enrollment.',
        statusCode: httpError?.status || 500
      });
    }
  }

  // --- Fetching Students ---
  async getStudents(filters?: { searchTerm?: string; status?: string }): Promise<StudentDetailsBackend[]> {
    console.log("AdminStudentService: getStudents called with filters:", filters);
    let httpParams = new HttpParams();
    if (filters?.searchTerm) httpParams = httpParams.set('search', filters.searchTerm);
    if (filters?.status) httpParams = httpParams.set('status', filters.status);

    try {
      // const apiResponse = await firstValueFrom(
      //   this.http.get<FetchStudentsApiResponse>(`${this.apiUrl}/view-students`, { params: httpParams, headers: this.getAuthHeaders() })
      // );
      const apiResponse: FetchStudentsApiResponse = await this.simulateFetchStudentsApi(filters); // Using simulation

      if (apiResponse.success && apiResponse.data) {
        const { responseAesKeyB64, encryptedData } = apiResponse.data;
        const decryptedJsonString = await this.encryptionService.decryptAesGcmPayload(
          encryptedData,
          responseAesKeyB64
        );
        const studentsFromBackend: StudentDetailsBackend[] = JSON.parse(decryptedJsonString);
        return studentsFromBackend;
      } else {
        throw new Error(apiResponse.message || "Failed to fetch students: Server indicated failure or no data.");
      }
    } catch (error: any) {
      console.error("AdminStudentService: Error in getStudents:", error);
      const httpError = error instanceof HttpErrorResponse ? error : null;
      throw new Error(httpError?.error?.message || error.message || "Could not fetch or decrypt student data.");
    }
  }

  private getAuthHeaders() {
    const token = this.authService.token;
    if (!token) throw new Error("Authentication token is missing.");
    return { 'Authorization': `Bearer ${token}` };
  }

  // --- SIMULATION FOR /view-students ---
  private async simulateFetchStudentsApi(filters?: { searchTerm?: string; status?: string }): Promise<FetchStudentsApiResponse> {
    console.log("AdminStudentService: SIMULATING API call to /view-students with filters:", filters);
    await new Promise(resolve => setTimeout(resolve, 600));

    const mockRawStudentsList: StudentDetailsBackend[] = this.getMockStudentsData(filters);
    const tempAesKey = await this.encryptionService.generateAesGcmKey();
    const responseAesKeyB64 = await this.encryptionService.exportRawAesKeyAsBase64(tempAesKey);
    const encryptedData = await this.encryptionService.encryptLoginPayloadAesGcm(mockRawStudentsList, tempAesKey);

    return {
      success: true,
      statusCode: 200,
      data: { responseAesKeyB64: responseAesKeyB64, encryptedData: encryptedData },
      message: "Students list retrieved and encrypted (simulated)."
    };
  }

  private getMockStudentsData(filters?: { searchTerm?: string; status?: string }): StudentDetailsBackend[] {
    let students: StudentDetailsBackend[] = [
      { _id: 's001', full_name: 'Sam Student', email: 'sam@student.lms', mobile_number: '+19876543210', email_verified: true, mobile_verified: true, is_active: true, roles: [{role_id:'student'}], created_at: new Date().toISOString(), updated_at: new Date().toISOString(), enrollment_status: 'enrolled', current_grade_level: '10th Grade' },
      { _id: 's002', full_name: 'Penny Learner', email: 'penny@student.lms', mobile_number: '+19876543211', email_verified: true, mobile_verified: false, is_active: true, roles: [{role_id:'student'}], created_at: new Date().toISOString(), updated_at: new Date().toISOString(), enrollment_status: 'pending_payment' },
    ];
    if (filters?.status) {
      students = students.filter(s => s.enrollment_status === filters.status);
    }
    if (filters?.searchTerm) {
      const term = filters.searchTerm.toLowerCase();
      students = students.filter(s => s.full_name.toLowerCase().includes(term) || s.email.toLowerCase().includes(term));
    }
    return students;
  }
}