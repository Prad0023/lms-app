import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError, firstValueFrom } from 'rxjs'; // Keep firstValueFrom for when you use http.get
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../../environments/environments';
import { EncryptionService } from '../../../core/services/encryption.service';
import { AuthService } from '../../../core/services/auth.service';
// Ensure this import is correct and teacher.model.ts exports these
import { TeacherDetails, FetchTeachersApiResponse, EncryptedListPayload, TeacherBasicInfo } from '../models/teacher.model';

// Interfaces for onboarding initiation (can also be in teacher.model.ts if preferred)
export interface TeacherOnboardingInitiationPayload {
  teacherInfo: TeacherBasicInfo;
  onboardingLink: string;
  mailSubject?: string;
  mailBody?: string;
  sendEmail: boolean;
}
export interface EncryptedOnboardingRequest {
  encryptedAesKeyB64: string;
  encryptedPayloadB64: string;
}
export interface OnboardingInitiationResponse {
  success: boolean;
  message: string;
  data?: any;
}


@Injectable({
  providedIn: 'root'
})
export class AdminTeacherService {
  private apiUrl = `${environment.apiUrl}/admin/teachers`;

  constructor(
    private http: HttpClient,
    private encryptionService: EncryptionService,
    private authService: AuthService
  ) {}

  // ... (initiateTeacherHiring method from before) ...
  async initiateTeacherHiring(payload: TeacherOnboardingInitiationPayload): Promise<OnboardingInitiationResponse> {
    const onboardingEndpoint = `${environment.apiUrl}/admin/initiate-teacher-onboarding`;

    try {
      const rsaPublicKeyCryptoKey = await this.encryptionService.getRsaPublicKey();
      const aesCryptoKey = await this.encryptionService.generateAesGcmKey();
      const aesKeyBase64ForRsa = await this.encryptionService.exportRawAesKeyAsBase64(aesCryptoKey);
      const rsaEncryptedAesKeyB64 = await this.encryptionService.encryptAesKeyBase64WithRsa(
        aesKeyBase64ForRsa,
        rsaPublicKeyCryptoKey
      );
      const aesEncryptedPayloadB64 = await this.encryptionService.encryptLoginPayloadAesGcm(
        payload,
        aesCryptoKey
      );
      const encryptedRequest: EncryptedOnboardingRequest = {
        encryptedAesKeyB64: rsaEncryptedAesKeyB64,
        encryptedPayloadB64: aesEncryptedPayloadB64
      };
      const adminToken = this.authService.token;
      if (!adminToken) throw new Error("Admin token not found.");
      const headers = { 'Authorization': `Bearer ${adminToken}` };

      // When backend is ready, you'll replace simulate with this:
      // return firstValueFrom(
      //   this.http.post<OnboardingInitiationResponse>(onboardingEndpoint, encryptedRequest, { headers })
      // );
      // For now, simulating a successful response after a delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      return { success: true, message: payload.sendEmail ? "Teacher onboarding initiated (simulated)." : "Teacher marked for review (simulated)." };

    } catch (error) {
      console.error("Error in initiateTeacherHiring service:", error);
      const httpError = error instanceof HttpErrorResponse ? error : null;
      return Promise.reject({
        success: false,
        message: httpError?.error?.message || (error as Error)?.message || 'Failed to initiate teacher hiring.',
        statusCode: httpError?.status || 500
      });
    }
  }


  // --- Fetching Teachers - REVISED ---
async getTeachers(filters?: { searchTerm?: string; status?: string }): Promise<TeacherDetails[]> { // <<<< Returns Backend structure
    console.log("AdminTeacherService: getTeachers called with filters:", filters);
    // ... (httpParams setup) ...
    try {
      // ... (API call or simulation returning FetchTeachersApiResponse) ...
      // const apiResponse: FetchTeachersApiResponse = await this.http.get... OR await this.simulateFetchTeachersApi...
      const apiResponse: FetchTeachersApiResponse = await this.simulateFetchTeachersApi(filters);


      if (apiResponse.success && apiResponse.data) {
        const { responseAesKeyB64, encryptedData } = apiResponse.data;
        const decryptedJsonString = await this.encryptionService.decryptAesGcmPayload(
          encryptedData,
          responseAesKeyB64
        );
        console.log("AdminTeacherService: RAW Decrypted JSON string:", decryptedJsonString);
        const teachersFromBackend: TeacherDetails[] = JSON.parse(decryptedJsonString); // <<< Parsed as Backend structure
        console.log("AdminTeacherService: Parsed teachersFromBackend:", JSON.stringify(teachersFromBackend, null, 2));
        return teachersFromBackend;
      } else {
        throw new Error(apiResponse.message || "Failed to fetch teachers: Server indicated failure or no data.");
      }
    } catch (error: any) {
      // ... error handling ...
      console.error("AdminTeacherService: Error in getTeachers:", error);
      const httpError = error instanceof HttpErrorResponse ? error : null;
      throw new Error(httpError?.error?.message || error.message || "Could not fetch or decrypt teacher data.");
    }
  }

  // ... (getAuthHeaders, simulateFetchTeachersApi, getMockTeachersData using TeacherDetailsBackend for mocks) ...

  // Ensure getMockTeachersData returns data matching TeacherDetailsBackend
private getMockTeachersData(filters?: { searchTerm?: string; status?: string }): TeacherDetails[] {
    let teachers: TeacherDetails[] = [
      // Example:
      { _id: 't001', full_name: 'Dr. Alice Wonderland', email: 'alice@lms.edu', mobile_number: '+11111111111', designation: 'Physics Professor', status: 'hired', email_verified: true, mobile_verified: true, is_active: true, created_by: 'admin', roles: [{role_id: 'teacher'}], created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
      { _id: 't002', full_name: 'Bob The Builder', email: 'bob@lms.edu', mobile_number: '+12222222222', designation: 'Math Lecturer', status: 'pending_verification', email_verified: false, mobile_verified: false, is_active: true, created_by: 'admin', roles: [{role_id: 'teacher'}], created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
      // Add one that matches your logged data to test missing fields:
      {
        _id: "datafromlog",
        email: "geeksforyou2021@gmail.com",
        mobile_number: "+917350224492",
        full_name: "pradhumn",
        email_verified: false,
        mobile_verified: false,
        is_active: false,
        created_by: "admin123",
        roles: [ { "role_id": "teacher_role_id" } ],
        created_at: "2025-05-19T10:49:24.280Z",
        updated_at: "2025-05-19T10:49:24.280Z",
        // No designation, no status here
      }
    ];
    // ... filter logic ...
    return teachers;
  }


  private getAuthHeaders() {
    const token = this.authService.token;
    if (!token) {
      console.error("AdminTeacherService: Admin token not found for API call.");
      throw new Error("Authentication token is missing. Please log in again.");
    }
    return { 'Authorization': `Bearer ${token}` };
  }

  // --- SIMULATION FOR /view-teachers (REMOVE WHEN BACKEND IS READY) ---
  // This method now correctly declares its return type
  private async simulateFetchTeachersApi(filters?: { searchTerm?: string; status?: string }): Promise<FetchTeachersApiResponse> {
    console.log("AdminTeacherService: SIMULATING API call to /view-teachers with filters:", filters);
    await new Promise(resolve => setTimeout(resolve, 700));

    const mockRawTeachersList: TeacherDetails[] = this.getMockTeachersData(filters);

    const tempAesKey = await this.encryptionService.generateAesGcmKey();
    const responseAesKeyB64 = await this.encryptionService.exportRawAesKeyAsBase64(tempAesKey);
    const encryptedData = await this.encryptionService.encryptLoginPayloadAesGcm(mockRawTeachersList, tempAesKey);

    return { // This object matches FetchTeachersApiResponse
      success: true,
      statusCode: 200,
      data: {
        responseAesKeyB64: responseAesKeyB64,
        encryptedData: encryptedData
      },
      message: "Teachers list retrieved and encrypted (simulated)."
    };
  }

  
}