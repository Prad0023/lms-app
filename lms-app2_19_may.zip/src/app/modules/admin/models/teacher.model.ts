export interface TeacherBasicInfo { // For forms
  fullName: string;
  email: string;
  mobile: string;
  designation: string;
}

export interface TeacherDetailsFE { // Suffix with FE for "FrontEnd" to distinguish from raw backend data
  _id: string;
  fullName: string;    // What your template wants (camelCase)
  email: string;
  mobile: string;      // What your template wants (camelCase)
  designation: string; // What your template wants, will need a default
  status: 'pending_onboarding' | 'pending_verification' | 'hired' | 'marked_for_review' | 'left' | 'unknown' | string; // What your template wants, will need a default
  // Include other fields if your template/component logic needs them
  rawRoles?: { role_id: string }[]; // Optional: if you need to access the original roles structure
  // Add other fields like isActive, emailVerified if needed by the view
  isActive?: boolean;
}

// Interface for the raw data structure coming from the backend after decryption
export interface TeacherDetails {
  _id: string;
  email: string;
  mobile_number: string; // snake_case from backend
  full_name: string;     // snake_case from backend
  email_verified: boolean;
  mobile_verified: boolean;
  is_active: boolean;
  created_by: string;
  roles: { role_id: string }[];
  created_at: string;
  updated_at: string;
  __v?: number;
  // Backend data might NOT have these:
  designation?: string;
  status?: string;
  onboardingLinkSentAt?: string;
  profileCompletedAt?: string;
  hiredAt?: string;
  leftAt?: string;
  assignedBatches?: string[];
}


export interface EncryptedListPayload {
  responseAesKeyB64: string;
  encryptedData: string;
}
export interface FetchTeachersApiResponse {
  success: boolean;
  statusCode: number;
  data?: EncryptedListPayload;
  message: string;
}