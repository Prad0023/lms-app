// Interface for the raw data structure coming from the backend after decryption
export interface StudentDetailsBackend {
  _id: string;
  email: string;
  mobile_number?: string; // Assuming student might not always have mobile
  full_name: string;
  email_verified: boolean;
  mobile_verified?: boolean;
  is_active: boolean;
  created_by?: string; // Admin or system
  roles: { role_id: string }[]; // Should contain a student role_id
  created_at: string;
  updated_at: string;
  __v?: number;
  // Student-specific fields (examples, adjust to your needs)
  enrollment_status?: 'pending_payment' | 'enrolled' | 'suspended' | 'completed_profile' | string;
  date_of_birth?: string;
  parent_guardian_name?: string;
  current_grade_level?: string;
  enrolled_courses?: { course_id: string, course_name: string }[];
}

// Interface for the frontend representation (View Model)
export interface StudentDetailsFE {
  _id: string;
  fullName: string;
  email: string;
  mobile?: string;
  status: 'Pending Payment' | 'Enrolled' | 'Suspended' | 'Profile Complete' | 'Unknown' | string; // Formatted status
  isActive: boolean;
  dateOfBirth?: Date; // Example of type conversion
  enrolledCourseCount?: number;
  // Add other fields as needed for the view
}

export interface StudentBasicEnrollInfo {
  fullName: string;
  email: string;
  mobile?: string;
}

export interface StudentEnrollmentInitiationPayload { // <<< ADD 'export'
  studentInfo: StudentBasicEnrollInfo;
  onboardingLink?: string;
  sendInviteEmail: boolean;
}

export interface FetchStudentsApiResponse { // Or use a generic FetchListApiResponse<T>
  success: boolean;
  statusCode: number;
  data?: { // Assuming EncryptedListPayload structure from teacher.model.ts
    responseAesKeyB64: string;
    encryptedData: string;
  };
  message: string;
}