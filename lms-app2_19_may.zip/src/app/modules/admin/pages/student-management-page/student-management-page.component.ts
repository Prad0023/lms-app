import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';

import { AdminStudentService } from '../../services/admin-student.service';
// import { StudentDetailsFE, StudentDetailsBackend, StudentBasicEnrollInfo } from '../../models/student.model';
import { StudentEnrollModalComponent } from '../../components/student-enroll-modal/student-enroll-modal.component'; // We'll create this
import { StudentDetailsFE, StudentDetailsBackend, StudentBasicEnrollInfo, StudentEnrollmentInitiationPayload } from '../../models/student.model';

@Component({
  selector: 'app-student-management-page',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    StudentEnrollModalComponent // Import modal
  ],
  templateUrl: './student-management-page.component.html',
  // styleUrls: ['./student-management-page.component.css']
})
export class StudentManagementPageComponent implements OnInit {
  isEnrollModalOpen = false;
  students: StudentDetailsFE[] = [];
  isLoadingStudents = false;
  errorMessage: string | null = null;

  filterForm: FormGroup;
  studentStatusOptions = [ // Example statuses
    { value: '', label: 'All Statuses' },
    { value: 'enrolled', label: 'Enrolled' },
    { value: 'pending_payment', label: 'Pending Payment' },
    { value: 'suspended', label: 'Suspended' },
    { value: 'completed_profile', label: 'Profile Complete' },
  ];

  constructor(
    private router: Router,
    private adminStudentService: AdminStudentService,
    private fb: FormBuilder
  ) {
    this.filterForm = this.fb.group({
      searchTerm: [''],
      status: [''] // Corresponds to enrollment_status from backend
    });
  }

  ngOnInit(): void {
    this.loadStudents();
    this.filterForm.valueChanges.subscribe(() => {
      this.loadStudents();
    });
  }

  async loadStudents(): Promise<void> {
    this.isLoadingStudents = true;
    this.errorMessage = null;
    try {
      const filters = {
        searchTerm: this.filterForm.value.searchTerm,
        status: this.filterForm.value.status // This is enrollment_status
      };
      const studentsFromBackend: StudentDetailsBackend[] = await this.adminStudentService.getStudents(filters);

      this.students = studentsFromBackend.map(sBackend => ({
        _id: sBackend._id,
        fullName: sBackend.full_name,
        email: sBackend.email,
        mobile: sBackend.mobile_number || 'N/A',
        status: this.formatStudentStatus(sBackend.enrollment_status), // Format status
        isActive: sBackend.is_active,
        dateOfBirth: sBackend.date_of_birth ? new Date(sBackend.date_of_birth) : undefined,
        enrolledCourseCount: sBackend.enrolled_courses?.length || 0
      }));
    } catch (error: any) {
      this.errorMessage = error.message || 'Failed to load students.';
    } finally {
      this.isLoadingStudents = false;
    }
  }

  openEnrollStudentModal(): void {
    this.isEnrollModalOpen = true;
  }

  closeEnrollStudentModal(): void {
    this.isEnrollModalOpen = false;
  }

  async handleStudentEnrolled(studentData: StudentBasicEnrollInfo): Promise<void> {
    console.log('Admin initiated enrollment for student:', studentData);
    this.closeEnrollStudentModal();

    const payload: StudentEnrollmentInitiationPayload = {
      studentInfo: studentData,
      sendInviteEmail: true // Or based on a checkbox in the modal
    };

    try {
      this.isLoadingStudents = true; // Show general loading for the page perhaps
      const response = await this.adminStudentService.initiateStudentEnrollment(payload);
      if (response.success) {
        alert(response.message);
        this.loadStudents(); // Refresh the list
      } else {
        alert(`Enrollment failed: ${response.message}`);
      }
    } catch (error: any) {
      alert(`Error during enrollment: ${error.message || 'Unknown error'}`);
    } finally {
      this.isLoadingStudents = false;
    }
  }

  formatStudentStatus(statusKey?: string): StudentDetailsFE['status'] {
    if (!statusKey) return 'Unknown';
    switch (statusKey) {
      case 'enrolled': return 'Enrolled';
      case 'pending_payment': return 'Pending Payment';
      case 'suspended': return 'Suspended';
      case 'completed_profile': return 'Profile Complete';
      default: return statusKey.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
    }
  }

  getStatusClass(status: StudentDetailsFE['status']): string {
    // Similar to teacher status class logic
    switch (status.toLowerCase()) {
      case 'enrolled': return 'bg-green-100 text-green-800';
      case 'pending payment': return 'bg-yellow-100 text-yellow-800';
      case 'suspended': return 'bg-red-100 text-red-800';
      case 'profile complete': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  }

  viewStudentDetails(studentId: string): void { /* Placeholder */ }
  editStudent(studentId: string): void { /* Placeholder */ }
}