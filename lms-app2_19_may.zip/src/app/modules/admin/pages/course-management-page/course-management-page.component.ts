import { Component } from '@angular/core';

@Component({
  selector: 'app-course-management-page',
  imports: [],
  templateUrl: './course-management-page.component.html',
  styleUrl: './course-management-page.component.css'
})
export class CourseManagementPageComponent {

}
