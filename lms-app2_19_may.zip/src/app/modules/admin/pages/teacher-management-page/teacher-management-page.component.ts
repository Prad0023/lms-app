import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';

import { TeacherHireModalComponent } from '../../components/teacher-hire-modal/teacher-hire-modal.component';
import { AdminTeacherService } from '../../services/admin-teacher.service';
import { TeacherDetails, TeacherBasicInfo } from '../../models/teacher.model';

@Component({
  selector: 'app-teacher-management-page',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    TeacherHireModalComponent
  ],
  templateUrl: './teacher-management-page.component.html',
})
export class TeacherManagementPageComponent implements OnInit {
  isHireModalOpen = false;
  teachers: TeacherDetails[] = [];
  isLoadingTeachers = false;
  errorMessage: string | null = null;

  filterForm: FormGroup;
  teacherStatusOptions = [
    { value: '', label: 'All Statuses' },
    { value: 'pending_onboarding', label: 'Pending Onboarding' },
    { value: 'pending_verification', label: 'Pending Verification' },
    { value: 'hired', label: 'Hired' },
    { value: 'marked_for_review', label: 'Marked for Review' },
    { value: 'left', label: 'Left' },
  ];

  constructor(
    private router: Router,
    private adminTeacherService: AdminTeacherService,
    private fb: FormBuilder
  ) {
    this.filterForm = this.fb.group({
      searchTerm: [''],
      status: ['']
    });
  }

  ngOnInit(): void {
    this.loadTeachers();
    this.filterForm.valueChanges.subscribe(() => {
        this.loadTeachers();
    });
  }

  async loadTeachers(): Promise<void> {
    this.isLoadingTeachers = true;
    this.errorMessage = null;
    try {
      const filters = this.filterForm.value;
      // adminTeacherService.getTeachers returns TeacherDetailsBackend[]
      // Let's assume TeacherDetails imported is indeed TeacherDetailsBackend
      const teachersFromBackend: TeacherDetails[] = await this.adminTeacherService.getTeachers(filters);

      // Transform backend data: provide defaults for fields that might be missing
      // AND ensure all fields required by TeacherDetails (which is TeacherDetailsBackend here) are present.
      this.teachers = teachersFromBackend.map(backendTeacher => {
        return {
          ...backendTeacher, // Spread all properties from the backend object first
          // Now, provide defaults ONLY for fields that might be missing from backendTeacher
          // BUT ARE DEFINED (even if optional) on the TeacherDetails (TeacherDetailsBackend) interface
          // AND that your view logic relies on (like formatStatus).
          designation: backendTeacher.designation || 'N/A', // If backendTeacher might not have it
          status: (backendTeacher.status as TeacherDetails['status']) || 'unknown', // If backendTeacher might not have it
          // The error says 'isActive' is missing. This implies the object from map is missing it.
          // But your map had 'isActive: backendTeacher.is_active'.
          // This means your `backendTeacher` object itself might sometimes be missing `is_active`.
          // Or, the `TeacherDetails` interface your component is using for `this.teachers`
          // is DIFFERENT from what `adminTeacherService.getTeachers()` is typed to return.

          // Let's be very explicit based on the error message:
          // The object created by map needs to satisfy the 'TeacherDetails' type.
          // The error "missing ... email_verified, mobile_verified, is_active, created_by, and 3 more"
          // means the objects returned by your .map() ARE MISSING THESE.

          // Corrected Map: Ensure ALL fields of TeacherDetails (Backend structure) are present
          _id: backendTeacher._id,
          full_name: backendTeacher.full_name,
          email: backendTeacher.email,
          mobile_number: backendTeacher.mobile_number || 'N/A', // Default if missing
          designation: backendTeacher.designation || 'N/A',   // Default if missing
          status: (backendTeacher.status as TeacherDetails['status']) || 'unknown', // Default if missing
          
          // Fields that were listed as "missing" by the error:
          email_verified: backendTeacher.email_verified,
          mobile_verified: backendTeacher.mobile_verified || false, // Provide default if optional
          is_active: backendTeacher.is_active, // This should be from backendTeacher
          created_by: backendTeacher.created_by,
          roles: backendTeacher.roles,
          created_at: backendTeacher.created_at,
          updated_at: backendTeacher.updated_at,
          __v: backendTeacher.__v, // If these are part of your TeacherDetails interface

          // Also include these if they are part of your TeacherDetails interface and might come from backend
          onboardingLinkSentAt: backendTeacher.onboardingLinkSentAt ? new Date(backendTeacher.onboardingLinkSentAt as string) : undefined,
          profileCompletedAt: backendTeacher.profileCompletedAt ? new Date(backendTeacher.profileCompletedAt as string) : undefined,
          hiredAt: backendTeacher.hiredAt ? new Date(backendTeacher.hiredAt as string) : undefined,
          leftAt: backendTeacher.leftAt ? new Date(backendTeacher.leftAt as string) : undefined,
          assignedBatches: backendTeacher.assignedBatches || [],
        };
      });

      console.log("TeacherManagementPageComponent: MAPPED teachers for template:", JSON.stringify(this.teachers, null, 2));
    } catch (error: any) {
      this.errorMessage = error.message || 'Failed to load teachers.';
      console.error("Error in loadTeachers:", error);
    } finally {
      this.isLoadingTeachers = false;
    }
  }
  

  openHireTeacherModal(): void {
    this.isHireModalOpen = true;
  }

  closeHireTeacherModal(): void {
    this.isHireModalOpen = false;
  }

  async handleTeacherHired(teacherData: TeacherBasicInfo): Promise<void> {
    console.log('Admin initiated hiring for (from modal):', teacherData);
    this.isHireModalOpen = false;
    this.router.navigate(['/admin/teachers/mail-preview'], { state: { teacherData: teacherData } });
  }

  getStatusClass(status: TeacherDetails['status'] | undefined): string {
    if (!status) { return 'bg-gray-100 text-gray-800'; }
    switch (status) {
      case 'hired': return 'bg-green-100 text-green-800';
      case 'pending_onboarding': return 'bg-yellow-100 text-yellow-800';
      case 'pending_verification': return 'bg-blue-100 text-blue-800';
      case 'marked_for_review': return 'bg-purple-100 text-purple-800';
      case 'left': return 'bg-red-100 text-red-800';
      case 'unknown': return 'bg-gray-300 text-gray-700'; // For 'unknown' status
      default: return 'bg-gray-100 text-gray-800';
    }
  }

  formatStatus(status: TeacherDetails['status'] | undefined): string {
    if (!status || status === 'unknown') { return 'N/A'; } // Handle unknown status
    return status.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  }


  
  viewTeacherDetails(teacherId: string): void {
    console.log('View details for teacher:', teacherId);
  }

  editTeacher(teacherId: string): void {
    console.log('Edit teacher:', teacherId);
  }
}