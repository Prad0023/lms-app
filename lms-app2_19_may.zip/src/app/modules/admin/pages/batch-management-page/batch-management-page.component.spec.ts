import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BatchManagementPageComponent } from './batch-management-page.component';

describe('BatchManagementPageComponent', () => {
  let component: BatchManagementPageComponent;
  let fixture: ComponentFixture<BatchManagementPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BatchManagementPageComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BatchManagementPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
