import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AdminDashboardPageComponent } from './pages/admin-dashboard-page/admin-dashboard-page.component';
// Import new page components once created
import { TeacherManagementPageComponent } from './pages/teacher-management-page/teacher-management-page.component';
// import { StudentManagementPageComponent } from './pages/student-management-page/student-management-page.component';
import { BatchManagementPageComponent } from './pages/batch-management-page/batch-management-page.component';
import { CourseManagementPageComponent } from './pages/course-management-page/course-management-page.component';
import { AdminSettingsPageComponent } from './pages/admin-settings-page/admin-settings-page.component';
import { TeacherMailPreviewPageComponent } from './pages/teacher-mail-preview-page/teacher-mail-preview-page.component';

const routes: Routes = [
  {
    path: 'dashboard',
    component: AdminDashboardPageComponent
  },
  {
    path: 'teachers',
    // component: TeacherManagementPageComponent // We'll create this next
    loadComponent: () => import('./pages/teacher-management-page/teacher-management-page.component').then(m => m.TeacherManagementPageComponent)
  },
  { // New route for mail preview, as a child of 'teachers' or a sibling
    path: 'teachers/mail-preview', // Or just 'mail-preview' if you want /admin/mail-preview
    component: TeacherMailPreviewPageComponent
  },
  {
    path: 'students',
    // component: StudentManagementPageComponent
    loadComponent: () => import('./pages/student-management-page/student-management-page.component').then(m => m.StudentManagementPageComponent)
  },
  {
    path: 'batches',
    // component: BatchManagementPageComponent
    loadComponent: () => import('./pages/batch-management-page/batch-management-page.component').then(m => m.BatchManagementPageComponent)

  },
  {
    path: 'courses',
    // component: CourseManagementPageComponent
    loadComponent: () => import('./pages/course-management-page/course-management-page.component').then(m => m.CourseManagementPageComponent)
  },
  {
    path: 'settings',
    // component: AdminSettingsPageComponent
    loadComponent: () => import('./pages/admin-settings-page/admin-settings-page.component').then(m => m.AdminSettingsPageComponent)
  },
  {
    path: '', // Default for /admin
    redirectTo: 'dashboard',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }