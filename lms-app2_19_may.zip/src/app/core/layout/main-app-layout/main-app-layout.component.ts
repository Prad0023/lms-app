import { Component, HostListener, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router'; // For <router-outlet>
import { SidebarComponent } from '../sidebar/sidebar.component'; // Our new sidebar
// Optional: A top navbar component if you have one
// import { TopNavbarComponent } from '../top-navbar/top-navbar.component';

@Component({
  selector: 'app-main-app-layout',
  standalone: true,
  imports: [CommonModule, RouterModule, SidebarComponent /*, TopNavbarComponent */],
  templateUrl: './main-app-layout.component.html',
  styleUrls: ['./main-app-layout.component.css']
})
export class MainAppLayoutComponent implements OnInit {
  isSidebarOpen = true;
  isMobile = false;

  constructor() {}

  ngOnInit(): void {
    this.checkScreenSize();
  }

  @HostListener('window:resize', ['$event'])
  onResize(event?: Event): void {
    this.checkScreenSize();
  }

  private checkScreenSize(): void {
    const screenWidth = window.innerWidth;
    this.isMobile = screenWidth < 768; // Example breakpoint for md
    if (this.isMobile) {
      this.isSidebarOpen = false; // Collapse sidebar on mobile by default
    } else {
      this.isSidebarOpen = true; // Open sidebar on desktop by default
    }
  }

  toggleSidebar(): void {
    this.isSidebarOpen = !this.isSidebarOpen;
  }
}