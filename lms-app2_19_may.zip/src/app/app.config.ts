import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withFetch } from '@angular/common/http'; // << Import withFetch

import { routes } from './app.routes';
// import { provideClientHydration } from '@angular/platform-browser'; // You might have this for hydration

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    // provideClientHydration(), // If using hydration
    provideHttpClient(withFetch()) // << Add withFetch() here
  ]
};